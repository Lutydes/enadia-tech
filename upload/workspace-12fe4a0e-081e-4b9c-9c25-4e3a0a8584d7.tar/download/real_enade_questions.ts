// =============================================================================
// REAL ENADE QUESTIONS - Collected from Official ENADE Exams
// Sources: ENADE CCOMP 2017, ENADE CCOMP 2021 (official INEP PDFs)
// Blog Cyberini (resolved questions), GitHub geacc/enade repository
// Total: ~55 real exam questions with answers and explanations
// Updated: Added ENADE ADS 2021, additional CCOMP 2021 questions
// =============================================================================

export interface RealEnadeQuestion {
  id: string;
  microarea: string;
  macroarea: string;
  element: string;
  difficulty: 'fácil' | 'médio' | 'difícil';
  statement: string;
  context?: string;
  alternatives: { letter: string; text: string }[];
  correctAnswer: string;
  explanation: string;
  source: string;
  sourceUrl?: string;
  year?: number;
  enadeId?: string;
  triA?: number;
  triB?: number;
  triC?: number;
}

export const realEnadeQuestions: RealEnadeQuestion[] = [
  // =========================================================================
  // ENADE 2017 - CIÊNCIA DA COMPUTAÇÃO (Bacharelado) - Componente Específico
  // Fonte: Blog Cyberini / INEP Oficial
  // =========================================================================

  // --- QUESTÃO 09: Estruturas de Dados (Árvore AVL) ---
  {
    id: "enade2017_cc_q09",
    microarea: "Algoritmos e Estruturas de Dados",
    macroarea: "Algoritmos",
    element: "Árvore AVL - Rotação",
    difficulty: "médio",
    statement: "Uma árvore AVL é um tipo de árvore binária balanceada na qual a diferença entre as alturas de suas subárvores da esquerda e da direita não pode ser maior do que 1 para qualquer nó. Após a inserção de um nó em uma AVL, a raiz da subárvore de nível mais baixo no qual o novo nó foi inserido é marcada. Se a altura de seus filhos diferir em mais de uma unidade, é realizada uma rotação simples ou uma rotação dupla para igualar suas alturas. Pelo exposto, após a inserção de um nó com valor 3 em uma árvore AVL dada, assinale a alternativa correta que apresenta a configuração resultante.",
    context: "LAFORE, R. Data Structures & algorithms in Java. Indianópolis: Sams Publishing, 2003 (adaptado).",
    alternatives: [
      { letter: "A", text: "Árvore balanceada após rotação simples à direita" },
      { letter: "B", text: "Árvore com desbalanceamento na raiz" },
      { letter: "C", text: "Árvore com rotação dupla" },
      { letter: "D", text: "Árvore sem necessidade de rotação" },
      { letter: "E", text: "Árvore com rotação simples à esquerda" }
    ],
    correctAnswer: "A",
    explanation: "Ao inserir o nó de valor 3, o nó 10 desbalanceia. Para balanceá-lo, aplica-se uma rotação simples à direita. Na rotação simples à direita, o nó que desbalanceou (10) desce e o seu filho esquerdo (8) sobe, tornando-se a nova raiz da subárvore.",
    source: "ENADE CCOMP 2011",
    sourceUrl: "https://www.blogcyberini.com/2018/03/questoes-resolvidas-enade-2017-ciencia-da-computacao.html",
    year: 2017,
    enadeId: "2017_cc_09"
  },

  // --- QUESTÃO 10: Engenharia de Software (Padrão Observer) ---
  {
    id: "enade2017_cc_q10",
    microarea: "Engenharia de Software",
    macroarea: "Desenvolvimento",
    element: "Padrões de Projeto - Observer",
    difficulty: "médio",
    statement: "Considere os seguintes requisitos para desenvolvimento de uma solução para uma rede de restaurantes fast-food: Quando o status de um pedido é atualizado, todos os dispositivos dos envolvidos devem receber a informação. Os sistemas incluem os acessados pelo entregador, pela linha de produção e pela central de atendimento. Espera-se que outros sistemas possam ser incluídos futuramente. Considerando esse contexto, avalie as asserções: I. O requisito apresentado pode ser implementado com a utilização do padrão de projeto Observer. PORQUE II. O padrão de projeto Observer realiza o estilo arquitetural cliente-servidor, no qual o servidor é responsável por enviar notificações aos clientes sempre que houver atualização.",
    alternatives: [
      { letter: "A", text: "As asserções I e II são proposições verdadeiras, e a II é uma justificativa correta da I." },
      { letter: "B", text: "As asserções I e II são proposições verdadeiras, mas a II não é uma justificativa correta da I." },
      { letter: "C", text: "A asserção I é uma proposição verdadeira, e a II é uma proposição falsa." },
      { letter: "D", text: "A asserção I é uma proposição falsa, e a II é uma proposição verdadeira." },
      { letter: "E", text: "As asserções I e II são proposições falsas." }
    ],
    correctAnswer: "C",
    explanation: "A asserção I é verdadeira: o padrão Observer é ideal para notificar múltiplos objetos sobre mudanças em um sujeito. O pedido é o Subject, os dispositivos são os Observers. A asserção II é falsa: Observer é um padrão de projeto para OO, enquanto cliente-servidor é um estilo arquitetural com finalidade distinta.",
    source: "ENADE CCOMP 2017",
    sourceUrl: "https://www.blogcyberini.com/2018/03/questoes-resolvidas-enade-2017-ciencia-da-computacao.html",
    year: 2017,
    enadeId: "2017_cc_10"
  },

  // --- QUESTÃO 11: Programação Orientada a Objetos (Encapsulamento) ---
  {
    id: "enade2017_cc_q11",
    microarea: "Programação Orientada a Objetos",
    macroarea: "Paradigmas",
    element: "Encapsulamento - Modificadores de Visibilidade",
    difficulty: "fácil",
    statement: "O encapsulamento é um mecanismo da programação orientada a objetos no qual os membros de uma classe (atributos e métodos) constituem uma caixa preta. O nível de visibilidade dos membros pode ser definido pelos modificadores de visibilidade 'privado', 'público' e 'protegido'. Com relação ao comportamento gerado pelos modificadores de visibilidade, assinale a opção correta.",
    alternatives: [
      { letter: "A", text: "Um atributo privado pode ser acessado pelos métodos privados da própria classe e pelos métodos protegidos das suas classes descendentes." },
      { letter: "B", text: "Um atributo privado pode ser acessado pelos métodos públicos da própria classe e pelos métodos públicos das suas classes descendentes." },
      { letter: "C", text: "Um membro público é visível na classe à qual ele pertence, mas não é visível nas suas classes descendentes." },
      { letter: "D", text: "Um método protegido não pode acessar os atributos privados e declarados na própria classe." },
      { letter: "E", text: "Um membro protegido é visível na classe à qual pertence e em suas classes descendentes." }
    ],
    correctAnswer: "E",
    explanation: "O modificador 'protected' (protegido) permite que o membro seja acessível dentro da própria classe e em todas as suas subclasses (classes descendentes), mas não por classes não relacionadas. Alternativas A e B estão incorretas pois atributos privados não são acessíveis por classes descendentes. C é falsa pois público é visível em todo lugar. D é falsa pois qualquer método da própria classe acessa atributos privados.",
    source: "ENADE CCOMP 2017",
    sourceUrl: "https://www.blogcyberini.com/2018/03/questoes-resolvidas-enade-2017-ciencia-da-computacao.html",
    year: 2017,
    enadeId: "2017_cc_11"
  },

  // --- QUESTÃO 12: Arquitetura de Computadores (Memória RAM) ---
  {
    id: "enade2017_cc_q12",
    microarea: "Sistemas Operacionais",
    macroarea: "Desenvolvimento",
    element: "Gerência de Memória - Memória RAM",
    difficulty: "médio",
    statement: "Em um computador, a memória é a unidade funcional que armazena e recupera operações e dados. Tipicamente, a memória usa uma técnica chamada acesso aleatório, que permite o acesso a qualquer posição. As memórias são divididas em células de tamanho fixo, associadas a um endereço numérico único. Considerando o funcionamento de uma memória de acesso aleatório, avalie as afirmações: I. Se a largura do registrador de endereços for de 8 bits, o tamanho máximo dessa memória será de 256 células. II. Se o registrador de dados tiver 8 bits, será necessário mais que uma operação para armazenar o valor inteiro 2024. III. Se o registrador de dados tiver 12 bits, é possível que a largura de memória seja de 8 bits.",
    alternatives: [
      { letter: "A", text: "I, apenas." },
      { letter: "B", text: "III, apenas." },
      { letter: "C", text: "I e II, apenas." },
      { letter: "D", text: "II e III, apenas." },
      { letter: "E", text: "I, II e III." }
    ],
    correctAnswer: "C",
    explanation: "I é verdadeira: 2^8 = 256 endereços possíveis. II é verdadeira: 2024 em binário é 11111101000 (11 bits), precisa de pelo menos 2 operações com registrador de 8 bits. III é falsa: se o registrador de dados tem 12 bits, a célula (palavra) da memória deve ter pelo menos 12 bits de largura.",
    source: "ENADE CCOMP 2017",
    sourceUrl: "https://www.blogcyberini.com/2018/03/questoes-resolvidas-enade-2017-ciencia-da-computacao.html",
    year: 2017,
    enadeId: "2017_cc_12"
  },

  // --- QUESTÃO 13: Circuitos Digitais (Lógica Booleana) ---
  {
    id: "enade2017_cc_q13",
    microarea: "Lógica Proposicional",
    macroarea: "Fundamentos",
    element: "Circuitos Lógicos - Expressão Booleana",
    difficulty: "médio",
    statement: "Os sistemas de refrigeração de piscinas de combustível em usinas nucleares evitam que a temperatura exceda o limite de segurança. Um circuito atende aos requisitos para o controle do sistema de resfriamento quando a temperatura está próxima do ponto crítico. Os sinais Ta, Tb e Tc são de termômetros que medem a temperatura em diferentes pontos e S é o terminal de acionamento. Assinale a opção em que são apresentados os momentos (de t1 a t8) em que o sistema foi acionado.",
    alternatives: [
      { letter: "A", text: "t1, t4 e t8." },
      { letter: "B", text: "t1, t6 e t8." },
      { letter: "C", text: "t2, t4 e t6." },
      { letter: "D", text: "t2, t6 e t8." },
      { letter: "E", text: "t3, t5 e t7." }
    ],
    correctAnswer: "B",
    explanation: "A expressão booleana do circuito é S = Ta·Tb + Tb·Tc = Tb·(Ta + Tc). Avaliando em cada momento: t1 (0,1,1)=1; t2 (1,0,0)=0; t3 (1,0,1)=0; t4 (0,1,0)=0; t5 (0,0,1)=0; t6 (1,1,1)=1; t7 (0,0,0)=0; t8 (1,1,0)=1. O sistema é acionado em t1, t6 e t8.",
    source: "ENADE CCOMP 2017",
    sourceUrl: "https://www.blogcyberini.com/2018/03/questoes-resolvidas-enade-2017-ciencia-da-computacao.html",
    year: 2017,
    enadeId: "2017_cc_13"
  },

  // --- QUESTÃO 14: Matemática Discreta (Relação de Equivalência) ---
  {
    id: "enade2017_cc_q14",
    microarea: "Matemática Discreta",
    macroarea: "Fundamentos",
    element: "Relações Binárias - Equivalência",
    difficulty: "médio",
    statement: "Uma relação de equivalência é uma relação binária R em um conjunto A, tal que R é reflexiva, simétrica e transitiva. Considere as relações binárias: R1 = {(a,b): a,b∈N e a=b}; R2 = {(a,b): a,b∈N e a≤b}; R3 = {(a,b): a,b∈N e a=b-1}; R4 = {(a,b): a,b∈N e a+b é par}. São relações de equivalência apenas o que se apresenta em:",
    alternatives: [
      { letter: "A", text: "R2 e R3." },
      { letter: "B", text: "R1 e R3." },
      { letter: "C", text: "R1 e R4." },
      { letter: "D", text: "R1, R2 e R4." },
      { letter: "E", text: "R2, R3 e R4." }
    ],
    correctAnswer: "C",
    explanation: "R1 (igualdade) é reflexiva, simétrica e transitiva. R4 (soma par) também satisfaz as três propriedades: se a+b é par, então b+a é par (simétrica); se a=b (reflexiva, 2a é par); se a+b e b+c são pares, a+c também é par (transitiva). R2 não é simétrica (2≤4 mas 4≰2). R3 não é reflexiva (a≠a-1).",
    source: "ENADE CCOMP 2017",
    sourceUrl: "https://www.blogcyberini.com/2018/03/questoes-resolvidas-enade-2017-ciencia-da-computacao.html",
    year: 2017,
    enadeId: "2017_cc_14"
  },

  // --- QUESTÃO 18: Algoritmos (Insertion Sort com erros) ---
  {
    id: "enade2017_cc_q18",
    microarea: "Algoritmos e Estruturas de Dados",
    macroarea: "Algoritmos",
    element: "Algoritmos de Ordenação - Insertion Sort",
    difficulty: "médio",
    statement: "O algoritmo a seguir recebe um vetor v de números inteiros e deve rearranjá-lo de forma crescente: void ordena(int *v, int n) { int i, j, chave; for(i = 1; i < n; i++) { chave = v[i]; j = i - 1; while(j >= 0 && v[j] < chave) { v[j-1] = v[j]; j = j - 1; } v[j+1] = chave; } }. Considerando que há erros de lógica, assinale a opção correta sobre as correções adequadas.",
    alternatives: [
      { letter: "A", text: "A linha 04: for(i = 1; i < n - 1; i++) e a linha 13: v[j - 1] = chave;" },
      { letter: "B", text: "A linha 04: for(i = 1; i < n - 1; i++) e a linha 07: j = i + 1;" },
      { letter: "C", text: "A linha 07: j = i + 1 e a linha 08: while(j >= 0 && v[j] > chave)" },
      { letter: "D", text: "A linha 08: while(j >= 0 && v[j] > chave) e a linha 10: v[j + 1] = v[j];" },
      { letter: "E", text: "A linha 10: v[j + 1] = v[j]; e a linha 13: v[j - 1] = chave;" }
    ],
    correctAnswer: "D",
    explanation: "O algoritmo é uma versão do insertion sort com dois erros: (1) a condição v[j] < chave deveria ser v[j] > chave (busca da posição correta da direita para a esquerda); (2) a linha 10 faz v[j-1] = v[j] (desloca para a esquerda) quando deveria ser v[j+1] = v[j] (desloca para a direita para abrir espaço para a chave).",
    source: "ENADE CCOMP 2017",
    sourceUrl: "https://www.blogcyberini.com/2018/03/questoes-resolvidas-enade-2017-ciencia-da-computacao.html",
    year: 2017,
    enadeId: "2017_cc_18"
  },

  // --- QUESTÃO 19: Banco de Dados (SQL JOINs) ---
  {
    id: "enade2017_cc_q19",
    microarea: "Banco de Dados",
    macroarea: "Desenvolvimento",
    element: "SQL - INNER JOIN",
    difficulty: "médio",
    statement: "Considere um diagrama Entidade-Relacionamento com entidades Deputado, Participação e Seção. Qual código SQL exibe o nome de todos os deputados que compareceram a pelo menos uma seção e as datas de cada seção em que participaram?",
    alternatives: [
      { letter: "A", text: "SELECT Deputado.nomeDeputado, Secao.dataSecao FROM Deputado, Participacao, Secao WHERE Deputado.idDeputado=Participacao.idDeputado;" },
      { letter: "B", text: "SELECT Deputado.nomeDeputado, Secao.dataSecao FROM Deputado, Participacao, Secao WHERE Deputado.idDeputado = Participacao.idDeputado OR Secao.idSecao = Participacao.idSecao;" },
      { letter: "C", text: "SELECT Deputado.nomeDeputado, Secao.dataSecao FROM Deputado LEFT OUTER JOIN Participacao ON Deputado.idDeputado = Participacao.idDeputado LEFT OUTER JOIN Secao ON Secao.idSecao = Participacao.idSecao;" },
      { letter: "D", text: "SELECT Deputado.nomeDeputado, Secao.dataSecao FROM Deputado RIGHT OUTER JOIN Participacao ON Deputado.idDeputado = Participacao.idDeputado RIGHT OUTER JOIN Secao ON Secao.idSecao = Participacao.idSecao;" },
      { letter: "E", text: "SELECT Deputado.nomeDeputado, Secao.dataSecao FROM Deputado INNER JOIN Participacao ON Deputado.idDeputado = Participacao.idDeputado INNER JOIN Secao ON Participacao.idSecao=Secao.idSecao;" }
    ],
    correctAnswer: "E",
    explanation: "O INNER JOIN entre as três tabelas retorna apenas deputados que compareceram a pelo menos uma seção (exige correspondência em todas as tabelas). Alternativa A despreza a tabela Seção. B usa OR em vez de AND. C e D usam OUTER JOIN que incluiria deputados sem seções ou seções sem deputados.",
    source: "ENADE CCOMP 2017",
    sourceUrl: "https://www.blogcyberini.com/2018/03/questoes-resolvidas-enade-2017-ciencia-da-computacao.html",
    year: 2017,
    enadeId: "2017_cc_19"
  },

  // --- QUESTÃO 20: Redes de Computadores (TCP vs UDP) ---
  {
    id: "enade2017_cc_q20",
    microarea: "Redes de Computadores",
    macroarea: "Desenvolvimento",
    element: "Camada de Transporte - TCP vs UDP",
    difficulty: "fácil",
    statement: "Em redes de computadores, a camada de transporte é responsável pela transferência de dados entre máquinas de origem e destino. TCP é orientado à conexão. Com relação a TCP e UDP, avalie: I. O UDP é mais eficiente que o TCP quando o tempo de envio de pacotes é fundamental. II. O TCP é o mais utilizado em jogos on-line de ação para a apresentação gráfica. III. O TCP é mais eficiente que o UDP quando a confiabilidade de entrega de dados é fundamental.",
    alternatives: [
      { letter: "A", text: "II, apenas." },
      { letter: "B", text: "III, apenas." },
      { letter: "C", text: "I e II, apenas." },
      { letter: "D", text: "I e III, apenas." },
      { letter: "E", text: "I, II e III." }
    ],
    correctAnswer: "D",
    explanation: "I é verdadeira: UDP não tem overhead de conexão e controle de fluxo, sendo mais rápido. II é falsa: gráficos são processados pela GPU localmente, não dependem da rede; jogos online de ação tipicamente usam UDP. III é verdadeira: TCP garante entrega com confirmação e retransmissão, sendo mais confiável.",
    source: "ENADE CCOMP 2017",
    sourceUrl: "https://www.blogcyberini.com/2018/03/questoes-resolvidas-enade-2017-ciencia-da-computacao.html",
    year: 2017,
    enadeId: "2017_cc_20"
  },

  // --- QUESTÃO 22: Algoritmos (Algoritmo Guloso) ---
  {
    id: "enade2017_cc_q22",
    microarea: "Algoritmos e Estruturas de Dados",
    macroarea: "Algoritmos",
    element: "Paradigmas de Projeto - Algoritmo Guloso",
    difficulty: "médio",
    statement: "Um país utiliza moedas de 1, 5, 10, 25 e 50 centavos. Um programador desenvolveu um método guloso para o problema do troco mínimo que recebe um valor em centavos e retorna a quantidade de cada moeda. Avalie: I. O método guloso encontra o menor número de moedas para o valor de entrada. PORQUE II. Métodos gulosos sempre encontram a solução ótima global.",
    alternatives: [
      { letter: "A", text: "As asserções I e II são verdadeiras, e a II é justificativa correta da I." },
      { letter: "B", text: "As asserções I e II são verdadeiras, mas a II não é justificativa correta da I." },
      { letter: "C", text: "A asserção I é verdadeira, e a II é falsa." },
      { letter: "D", text: "A asserção I é falsa, e a II é verdadeira." },
      { letter: "E", text: "As asserções I e II são falsas." }
    ],
    correctAnswer: "C",
    explanation: "I é verdadeira: com as moedas brasileiras (sistema canônico), o algoritmo guloso sempre encontra a solução ótima. II é falsa: métodos gulosos fazem escolhas localmente ótimas, mas nem sempre encontram a solução ótima global (ex: troco com moedas de 1, 3, 4 para valor 6: guloso dá 4+1+1=3 moedas, ótimo é 3+3=2 moedas).",
    source: "ENADE CCOMP 2017",
    sourceUrl: "https://www.blogcyberini.com/2018/03/questoes-resolvidas-enade-2017-ciencia-da-computacao.html",
    year: 2017,
    enadeId: "2017_cc_22"
  },

  // --- QUESTÃO 23: Autômatos e Linguagens Formais ---
  {
    id: "enade2017_cc_q23",
    microarea: "Autômatos e Linguagens Formais",
    macroarea: "Teoria",
    element: "Linguagens Livres de Contexto vs. Regulares",
    difficulty: "difícil",
    statement: "Considere o alfabeto Σ = {(,),0,1,2,3,4,5,6,7,8,9,+,-} e a linguagem L = {w | w∈Σ*, para cada ocorrência de '(' em w, existe uma ocorrência de ')' }. Por exemplo, (2+(3-4))∈L, mas (2+(3-4)∉L. Avalie: I. A linguagem L não pode ser considerada regular. PORQUE II. Autômatos finitos não possuem mecanismos que permitam contar infinitamente o número de ocorrências de determinado símbolo.",
    alternatives: [
      { letter: "A", text: "As asserções I e II são verdadeiras, e a II é justificativa correta da I." },
      { letter: "B", text: "As asserções I e II são verdadeiras, mas a II não é justificativa correta da I." },
      { letter: "C", text: "A asserção I é verdadeira, e a II é falsa." },
      { letter: "D", text: "A asserção I é falsa, e a II é verdadeira." },
      { letter: "E", text: "As asserções I e II são falsas." }
    ],
    correctAnswer: "A",
    explanation: "I é verdadeira: L é livre de contexto (precisa contar o balanceamento de parênteses), não regular. II é verdadeira e justifica I: autômatos finitos não têm memória ilimitada para contar ocorrências de parênteses. Essa deficiência é suprida pela pilha dos autômatos de pilha, que reconhecem linguagens livres de contexto.",
    source: "ENADE CCOMP 2017",
    sourceUrl: "https://www.blogcyberini.com/2018/03/questoes-resolvidas-enade-2017-ciencia-da-computacao.html",
    year: 2017,
    enadeId: "2017_cc_23"
  },

  // --- QUESTÃO 24: Matemática Discreta / Teoria dos Grafos ---
  {
    id: "enade2017_cc_q24",
    microarea: "Matemática Discreta",
    macroarea: "Fundamentos",
    element: "Grafos - Dijkstra e Kruskal",
    difficulty: "médio",
    statement: "Um grafo representa um mapa rodoviário com vértices (cidades) e arestas (vias) com pesos (tempo de deslocamento). Avalie: I. Dado o vértice de origem i, o algoritmo de Dijkstra encontra o menor tempo entre i e todas as demais cidades. II. Uma árvore geradora mínima gerada por Kruskal contém um caminho mínimo entre i e k. III. Se um caminho mínimo entre i e k contém w, então o subcaminho de w a k deve ser mínimo.",
    alternatives: [
      { letter: "A", text: "I, apenas." },
      { letter: "B", text: "II, apenas." },
      { letter: "C", text: "I e III, apenas." },
      { letter: "D", text: "II e III, apenas." },
      { letter: "E", text: "I, II e III." }
    ],
    correctAnswer: "E",
    explanation: "I é verdadeira: Dijkstra encontra caminhos mínimos de uma origem para todos os vértices. II é verdadeira: a AGM contém o caminho mínimo entre qualquer par de vértices (propriedade do caminho mínimo). III é verdadeira pelo princípio da optimalidade: subcaminhos de caminhos mínimos são caminhos mínimos.",
    source: "ENADE CCOMP 2017",
    sourceUrl: "https://www.blogcyberini.com/2018/03/questoes-resolvidas-enade-2017-ciencia-da-computacao.html",
    year: 2017,
    enadeId: "2017_cc_24"
  },

  // --- QUESTÃO 25: Complexidade de Algoritmos (Fibonacci) ---
  {
    id: "enade2017_cc_q25",
    microarea: "Algoritmos e Estruturas de Dados",
    macroarea: "Algoritmos",
    element: "Complexidade - Fibonacci Recursivo",
    difficulty: "médio",
    statement: "A função fib calcula o n-ésimo elemento de Fibonacci recursivamente: unsigned int fib(unsigned int n) { if(n < 2) return 1; return fib(n-2) + fib(n-1); }. Avalie: I. A complexidade de tempo é exponencial. II. A complexidade de espaço é exponencial. III. É possível implementar versão iterativa com tempo linear e espaço constante.",
    alternatives: [
      { letter: "A", text: "I, apenas." },
      { letter: "B", text: "II, apenas." },
      { letter: "C", text: "I e III, apenas." },
      { letter: "D", text: "II e III, apenas." },
      { letter: "E", text: "I, II e III." }
    ],
    correctAnswer: "C",
    explanation: "I é verdadeira: a versão recursiva sem memoização é O(2^n). II é falsa: o espaço é O(n) para a pilha de recursão, não exponencial. III é verdadeira: programação dinâmica permite O(n) em tempo e O(1) em espaço (armazenando apenas os dois últimos valores).",
    source: "ENADE CCOMP 2017",
    sourceUrl: "https://www.blogcyberini.com/2018/03/questoes-resolvidas-enade-2017-ciencia-da-computacao.html",
    year: 2017,
    enadeId: "2017_cc_25"
  },

  // --- QUESTÃO 28: Engenharia de Software (Scrum) ---
  {
    id: "enade2017_cc_q28",
    microarea: "Engenharia de Software",
    macroarea: "Desenvolvimento",
    element: "Métodos Ágeis - Scrum",
    difficulty: "fácil",
    statement: "Os métodos ágeis são fundamentados no desenvolvimento e entrega incremental. O Scrum é um método ágil de gerenciamento de projetos. Avalie: I. O Scrum adota a entrega incremental por meio de Sprints. II. O Scrum adota a simplicidade por meio do uso de programação em pares. III. O Scrum adota o envolvimento do cliente com a priorização e negociação dos requisitos na concepção de Sprints.",
    alternatives: [
      { letter: "A", text: "II, apenas." },
      { letter: "B", text: "III, apenas." },
      { letter: "C", text: "I e II, apenas." },
      { letter: "D", text: "I e III, apenas." },
      { letter: "E", text: "I, II e III." }
    ],
    correctAnswer: "D",
    explanation: "I é verdadeira: cada Sprint entrega um incremento do produto. II é falsa: Scrum não prescreve práticas de programação como XP (pair programming). III é verdadeira: o Product Owner prioriza requisitos e o cliente negocia o que entra em cada Sprint.",
    source: "ENADE CCOMP 2017",
    sourceUrl: "https://www.blogcyberini.com/2018/03/questoes-resolvidas-enade-2017-ciencia-da-computacao.html",
    year: 2017,
    enadeId: "2017_cc_28"
  },

  // --- QUESTÃO 30: Compiladores (Análise LL(1)) ---
  {
    id: "enade2017_cc_q30",
    microarea: "Autômatos e Linguagens Formais",
    macroarea: "Teoria",
    element: "Compiladores - Tabela LL(1) e Ambiguidade",
    difficulty: "difícil",
    statement: "Em um compilador, um analisador sintático descendente preditivo pode ser implementado com uma tabela LL(k). Considere uma gramática G onde a tabela LL(1) possui duas produções distintas na célula (Y, d), gerando dúvida na escolha da regra. A existência de duas regras distintas na célula (Y,d) resulta de:",
    alternatives: [
      { letter: "A", text: "Da ausência do símbolo de fim de cadeia ($) nas regras de produção." },
      { letter: "B", text: "De um não-determinismo causado por uma ambiguidade na gramática." },
      { letter: "C", text: "Do uso incorreto do símbolo de cadeia vazia (ε) nas regras de produção." },
      { letter: "D", text: "Da presença de duas regras de produção com um único terminal no corpo." },
      { letter: "E", text: "Da presença de duas regras de produção com o mesmo não terminal na cabeça." }
    ],
    correctAnswer: "B",
    explanation: "A ambiguidade na gramática faz com que uma mesma cadeia possa ser derivada de duas formas diferentes, gerando conflitos na tabela LL(1). A demonstração mostra que a cadeia 'aebaebcdc' possui duas árvores de derivação distintas, comprovando a ambiguidade da gramática.",
    source: "ENADE CCOMP 2017",
    sourceUrl: "https://www.blogcyberini.com/2018/03/questoes-resolvidas-enade-2017-ciencia-da-computacao.html",
    year: 2017,
    enadeId: "2017_cc_30"
  },

  // --- QUESTÃO 33: Complexidade de Algoritmos (Recorrência) ---
  {
    id: "enade2017_cc_q33",
    microarea: "Algoritmos e Estruturas de Dados",
    macroarea: "Algoritmos",
    element: "Análise de Recorrência",
    difficulty: "difícil",
    statement: "Considere a função recursiva F: void F(int n) { if(n > 0) { for(int i = 0; i < n; i++) { G(i); } F(n/2); } }. Avalie: I. A equação de recorrência de F é a mesma do mergesort. II. O número de chamadas recursivas de F é Θ(log n). III. O número de vezes que G é chamada é O(n log n).",
    alternatives: [
      { letter: "A", text: "I, apenas." },
      { letter: "B", text: "II, apenas." },
      { letter: "C", text: "I e III, apenas." },
      { letter: "D", text: "II e III, apenas." },
      { letter: "E", text: "I, II e III." }
    ],
    correctAnswer: "D",
    explanation: "I é falsa: recorrência de F é T(n) = T(n/2) + Θ(n), diferente do mergesort T(n) = 2T(n/2) + Θ(n). II é verdadeira: n é reduzido pela metade a cada chamada, totalizando log₂(n) chamadas. III é verdadeira: G é executada n + n/2 + n/4 + ... ≈ 2n = O(n), e O(n) ⊆ O(n log n).",
    source: "ENADE CCOMP 2017",
    sourceUrl: "https://www.blogcyberini.com/2018/03/questoes-resolvidas-enade-2017-ciencia-da-computacao.html",
    year: 2017,
    enadeId: "2017_cc_33"
  },

  // =========================================================================
  // ENADE 2021 - CIÊNCIA DA COMPUTAÇÃO (Bacharelado) - Componente Específico
  // Fonte: INEP Oficial (download.inep.gov.br) / GitHub geacc/enade
  // Gabarito oficial INEP
  // =========================================================================

  // --- QUESTÃO 09: Sistemas Operacionais (Escalonamento) ---
  {
    id: "enade2021_cc_q09",
    microarea: "Sistemas Operacionais",
    macroarea: "Desenvolvimento",
    element: "Escalonamento de Processos",
    difficulty: "médio",
    statement: "Quando um computador é multiprogramado, ele geralmente tem múltiplos processos ou threads que competem pela CPU ao mesmo tempo. A parte do sistema operacional que faz a escolha é chamada de escalonador. Considerando que em ambientes diferentes são necessários algoritmos diferentes, assinale a opção que apresenta um algoritmo seguido do tipo de ambiente no qual deva ser implementado.",
    alternatives: [
      { letter: "A", text: "Primeiro a chegar, último a sair (FILO); propício para sistemas de tempo real." },
      { letter: "B", text: "Escalonamento por taxas monotônicas (RMS); propício para sistemas em lote." },
      { letter: "C", text: "Tarefa mais curta primeiro; propício para sistemas interativos." },
      { letter: "D", text: "Escalonamento por chave circular (round-robin); propício para sistemas de tempo real." },
      { letter: "E", text: "Escalonamento por prioridades; propício para sistemas interativos." }
    ],
    correctAnswer: "E",
    explanation: "O escalonamento por prioridades é adequado para sistemas interativos, onde processos interativos recebem prioridade mais alta que processos em background. FILO não é um escalonamento comum. RMS é para tempo real. Tarefa mais curta é melhor para lote. Round-robin é típico de sistemas de tempo compartilhado, não especificamente tempo real.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_09"
  },

  // --- QUESTÃO 10: Algoritmos e Estruturas de Dados ---
  {
    id: "enade2021_cc_q10",
    microarea: "Algoritmos e Estruturas de Dados",
    macroarea: "Algoritmos",
    element: "Estruturas de Dados - Listas, Pilhas, Filas",
    difficulty: "fácil",
    statement: "A biblioteca de coleções da linguagem Java disponibiliza implementações de estruturas de dados elementares. Classe A: objetos organizados em ordem linear, inseridos no início ou final. Classe B: objetos organizados em ordem linear determinada por referência ao próximo objeto. Classe C: objetos removidos na ordem oposta em que foram inseridos. Classe D: objetos inseridos e removidos respeitando que o primeiro a entrar é o primeiro a sair. Assinale a alternativa que representa, respectivamente, A, B, C e D.",
    alternatives: [
      { letter: "A", text: "Lista circular, lista simplesmente ligada, pilha e fila." },
      { letter: "B", text: "Deque, lista simplesmente ligada, pilha e fila." },
      { letter: "C", text: "Lista duplamente ligada, lista simplesmente ligada, fila e pilha." },
      { letter: "D", text: "Pilha, fila, deque e lista simplesmente encadeada." },
      { letter: "E", text: "Deque, pilha, lista ligada e fila." }
    ],
    correctAnswer: "B",
    explanation: "A = Deque (double-ended queue, permite inserir nos dois extremos). B = Lista simplesmente ligada (cada elemento referencia o próximo). C = Pilha (LIFO - último a entrar, primeiro a sair). D = Fila (FIFO - primeiro a entrar, primeiro a sair).",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_10"
  },

  // --- QUESTÃO 11: Inteligência Artificial (Redes Neurais) ---
  {
    id: "enade2021_cc_q11",
    microarea: "Inteligência Artificial",
    macroarea: "Segurança/IA",
    element: "Redes Neurais - CNN e Treinamento",
    difficulty: "médio",
    statement: "Uma equipe de cientistas da computação deve desenvolver um sistema capaz de detectar sites que usam imagens de personagens de animação sem consentimento. Após tentativa com rede neural profunda, notaram que: 1) o tempo de treinamento estava muito longo e 2) a acurácia não estava no patamar aceito. Avalie as afirmações sobre alternativas: I. Aumentar o número de camadas pode melhorar a acurácia e diminuir o tempo de treinamento. II. Redes convolucionais podem melhorar a acurácia, mas podem exigir maior poder de processamento. III. Aumentar neurônios nas camadas pode piorar a acurácia e diminuir o tempo de treinamento. IV. Aumentar amostras de treinamento pode melhorar a acurácia apesar de aumentar o tempo. V. Redes recorrentes podem melhorar a acurácia mas exigir maior poder de processamento.",
    alternatives: [
      { letter: "A", text: "I e IV." },
      { letter: "B", text: "I e V." },
      { letter: "C", text: "II e III." },
      { letter: "D", text: "II e IV." },
      { letter: "E", text: "III e V." }
    ],
    correctAnswer: "D",
    explanation: "I é falsa: mais camadas geralmente AUMENTA o tempo de treinamento. II é verdadeira: CNNs são ideais para imagens. III é falsa: mais neurônios pode piorar (overfitting) mas AUMENTA tempo. IV é verdadeira: mais dados melhora generalização mas aumenta tempo. V é falsa: redes recorrentes são para dados sequenciais, não ideais para classificação de imagens estáticas.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_11"
  },

  // --- QUESTÃO 12: Legislação (LGPD) ---
  {
    id: "enade2021_cc_q12",
    microarea: "Legislação",
    macroarea: "Segurança/IA",
    element: "LGPD - Lei Geral de Proteção de Dados",
    difficulty: "médio",
    statement: "A Lei Geral de Proteção de Dados Pessoais (LGPD) está em vigência desde o final de 2018. Sobre a LGPD, avalie: I. A lei reprime o uso indiscriminado de dados pessoais sensíveis como origem racial, convicção religiosa e opinião política. II. Dados anonimizados não serão considerados pessoais, mesmo que o processo de anonimização possa ser revertido. III. O indivíduo poderá exigir que uma empresa informe se possui dados dele e solicitar correção, atualização ou eliminação. IV. A ANPD é responsável pela fiscalização e regulação da LGPD.",
    alternatives: [
      { letter: "A", text: "I e II." },
      { letter: "B", text: "I e III." },
      { letter: "C", text: "II e IV." },
      { letter: "D", text: "I, III e IV." },
      { letter: "E", text: "II, III e IV." }
    ],
    correctAnswer: "E",
    explanation: "I é verdadeira: dados sensíveis requerem consentimento explícito. II é verdadeira: segundo a LGPD Art. 5º, dados anonimizados não são considerados dados pessoais. III é verdadeira: direitos do titular incluem acesso, correção e eliminação (Art. 18). IV é verdadeira: a ANPD (Autoridade Nacional de Proteção de Dados) fiscaliza e regulamenta a LGPD.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_12"
  },

  // --- QUESTÃO 14: Arquitetura de Computadores (Von Neumann) ---
  {
    id: "enade2021_cc_q14",
    microarea: "Sistemas Operacionais",
    macroarea: "Desenvolvimento",
    element: "Arquitetura de Von Neumann",
    difficulty: "médio",
    statement: "Acerca da arquitetura de Von Neumann, avalie: I. Embora as arquiteturas tenham evoluído do ENIAC aos notebooks atuais, a arquitetura de Von Neumann se mantém até hoje. PORQUE II. A arquitetura de Von Neumann permite que a CPU realize a busca de instruções além da próxima; essa técnica é utilizada para acelerar a velocidade da CPU.",
    alternatives: [
      { letter: "A", text: "As asserções I e II são verdadeiras, e a II é justificativa correta da I." },
      { letter: "B", text: "As asserções I e II são verdadeiras, mas a II não é justificativa correta da I." },
      { letter: "C", text: "A asserção I é verdadeira, e a II é falsa." },
      { letter: "D", text: "A asserção I é falsa, e a II é verdadeira." },
      { letter: "E", text: "As asserções I e II são falsas." }
    ],
    correctAnswer: "C",
    explanation: "I é verdadeira: a arquitetura de Von Neumann (dados e instruções na mesma memória, modelo de bus-execução armazena) persiste desde os anos 1950. II é falsa: na arquitetura clássica de Von Neumann, as instruções são buscadas sequencialmente (a não ser por desvios). O que II descreve é o pipeline ou a execução fora de ordem, técnicas de arquiteturas modernas que vão além de Von Neumann.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_14"
  },

  // --- QUESTÃO 15: Engenharia de Software (Scrum) ---
  {
    id: "enade2021_cc_q15",
    microarea: "Engenharia de Software",
    macroarea: "Desenvolvimento",
    element: "Métodos Ágeis - Scrum (papéis)",
    difficulty: "fácil",
    statement: "No contexto do SCRUM como framework para organização de projetos ágeis, que prevê Scrum Master e Product Owner. Avalie: I. O papel do Scrum Master é guiar a equipe no uso efetivo da metodologia. II. O papel do Product Owner é garantir o foco no produto. III. Tanto o Scrum Master como o Product Owner têm autoridade direta sobre a equipe.",
    alternatives: [
      { letter: "A", text: "II, apenas." },
      { letter: "B", text: "III, apenas." },
      { letter: "C", text: "I e II, apenas." },
      { letter: "D", text: "I e III, apenas." },
      { letter: "E", text: "I, II e III." }
    ],
    correctAnswer: "C",
    explanation: "I é verdadeira: o Scrum Master é um facilitador/servant-leader que remove impedimentos. II é verdadeira: o Product Owner mantém o Product Backlog priorizado e garante o foco no valor do produto. III é falsa: no Scrum, a equipe de desenvolvimento é auto-organizada e autogerenciável; nem o SM nem o PO têm autoridade direta sobre ela.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_15"
  },

  // --- QUESTÃO 16: Lógica Proposicional (Circuitos Booleanos) ---
  {
    id: "enade2021_cc_q16",
    microarea: "Lógica Proposicional",
    macroarea: "Fundamentos",
    element: "Álgebra Booleana - Circuitos Combinacionais",
    difficulty: "médio",
    statement: "A álgebra booleana tem papel importante na sistematização de circuitos eletrônicos. A partir das portas básicas (NOT, OR, AND), considere um circuito combinacional com entradas X1, X2 e X3. Qual alternativa apresenta a expressão booleana correspondente ao circuito dado?",
    alternatives: [
      { letter: "A", text: "(X3 · X2') + X1'" },
      { letter: "B", text: "(X3 · (X2') + (X1'))'" },
      { letter: "C", text: "((X3 · X2)' + X1')'" },
      { letter: "D", text: "(X3 · X2)' + X1'" },
      { letter: "E", text: "((X3 · X2')' + X1')'" }
    ],
    correctAnswer: "B",
    explanation: "A expressão corresponde ao circuito com as portas dadas na figura da prova. A análise do circuito mostra que a saída é a negação de (X3 AND (NOT X2) OR (NOT X1)), ou seja, ((X3 · X2') + X1')'.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_16"
  },

  // --- QUESTÃO 17: Sistemas Operacionais (Região Crítica) ---
  {
    id: "enade2021_cc_q17",
    microarea: "Sistemas Operacionais",
    macroarea: "Desenvolvimento",
    element: "Sincronização - Exclusão Mútua",
    difficulty: "médio",
    statement: "A parte do programa onde a memória compartilhada é acessada é chamada de região crítica. Avalie: I. A exclusão mútua pode ser obtida por meio da desabilitação de interrupção controlada pelo SO, não sendo permitido que o usuário a controle. PORQUE II. A desabilitação da interrupção é mais eficiente em sistemas de multiprocessadores devido à quantidade de processos concorrentes.",
    alternatives: [
      { letter: "A", text: "As asserções I e II são verdadeiras, e a II é justificativa correta da I." },
      { letter: "B", text: "As asserções I e II são verdadeiras, mas a II não é justificativa correta da I." },
      { letter: "C", text: "A asserção I é verdadeira, e a II é falsa." },
      { letter: "D", text: "A asserção I é falsa, e a II é verdadeira." },
      { letter: "E", text: "As asserções I e II são falsas." }
    ],
    correctAnswer: "C",
    explanation: "I é verdadeira: desabilitar interrupções impede trocas de contexto, garantindo exclusão mútua, mas essa técnica deve ser controlada apenas pelo SO (não pelo usuário). II é falsa: em multiprocessadores, desabilitar interrupções em um CPU não impede que outro CPU acesse a região crítica, tornando essa técnica ineficiente nesse contexto.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_17"
  },

  // --- QUESTÃO 18: Inteligência Artificial (Machine Learning) ---
  {
    id: "enade2021_cc_q18",
    microarea: "Inteligência Artificial",
    macroarea: "Segurança/IA",
    element: "Aprendizado de Máquina - Supervisionado vs Não Supervisionado",
    difficulty: "médio",
    statement: "As técnicas de aprendizado de máquinas podem ser divididas em supervisionados e não supervisionados. No supervisionado é fornecida uma referência do objetivo. No não supervisionado não ocorre treinamento com conhecimento do ambiente. Avalie: I. A regressão linear é um exemplo de modelo supervisionado. II. A diferença entre saída desejada e gerada é o erro do aprendizado não supervisionado. III. O aprendizado não supervisionado é mais utilizado para reconhecimento de padrões. IV. O aprendizado supervisionado é capaz de tomar decisões precisas a partir de treinamento com dados conhecidos.",
    alternatives: [
      { letter: "A", text: "I e III." },
      { letter: "B", text: "II e III." },
      { letter: "C", text: "II e IV." },
      { letter: "D", text: "I, II e IV." },
      { letter: "E", text: "I, III e IV." }
    ],
    correctAnswer: "E",
    explanation: "I é verdadeira: regressão linear usa dados rotulados para prever valores contínuos. II é falsa: o erro (saída desejada - gerada) é conceito do aprendizado supervisionado, não do não supervisionado. III é verdadeira: clustering e redução de dimensionalidade são exemplos de reconhecimento de padrões sem supervisão. IV é verdadeira: após treinamento com dados conhecidos, o modelo generaliza para novos dados.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_18"
  },

  // --- QUESTÃO 19: Engenharia de Software (Personas e Cenários) ---
  {
    id: "enade2021_cc_q19",
    microarea: "Engenharia de Software",
    macroarea: "Desenvolvimento",
    element: "Requisitos - Personas e Cenários",
    difficulty: "médio",
    statement: "Duas técnicas comumente utilizadas para ampliar informações sobre requisitos são personas e cenários. Avalie sobre seus objetivos na elicitação de requisitos: I. Explicita situações implícitas nos requisitos. II. Ajuda o projetista a entender o impacto das decisões de projeto. III. Facilita a especificação formal e não-ambígua dos requisitos de interação. IV. Lembra à equipe que pessoas reais usarão o produto.",
    alternatives: [
      { letter: "A", text: "I e III." },
      { letter: "B", text: "I e IV." },
      { letter: "C", text: "II e III." },
      { letter: "D", text: "I, II e IV." },
      { letter: "E", text: "II, III e IV." }
    ],
    correctAnswer: "D",
    explanation: "I é verdadeira: cenários com personas revelam necessidades não explícitas. II é verdadeira: simulam o uso real, ajudando a avaliar decisões. III é falsa: personas e cenários NÃO são técnicas formais (são baseadas em narrativas). IV é verdadeira: personas representam usuários reais, humanizando o processo.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_19"
  },

  // --- QUESTÃO 20: Algoritmos (Busca Sequencial e Binária) ---
  {
    id: "enade2021_cc_q20",
    microarea: "Algoritmos e Estruturas de Dados",
    macroarea: "Algoritmos",
    element: "Algoritmos de Busca - Sequencial e Binária",
    difficulty: "fácil",
    statement: "Observe o código em C com funcao1 (busca sequencial) e funcao2 (busca binária recursiva). O vetor é {1,3,5,7,9,11,13,15,17,19} e busca-se o valor 15. Avalie: I. O resultado impresso é 7 - 7. II. A funcao1, no pior caso, é mais rápida que funcao2. III. A funcao2 implementa uma estratégia iterativa.",
    alternatives: [
      { letter: "A", text: "I, apenas." },
      { letter: "B", text: "III, apenas." },
      { letter: "C", text: "I e II, apenas." },
      { letter: "D", text: "II e III, apenas." },
      { letter: "E", text: "I, II e III." }
    ],
    correctAnswer: "A",
    explanation: "I é verdadeira: 15 está no índice 7, tanto na busca sequencial quanto na binária, logo saída '7 - 7'. II é falsa: busca sequencial é O(n), binária é O(log n); a binária é mais rápida no pior caso. III é falsa: funcao2 faz chamadas recursivas a si mesma, sendo uma implementação recursiva.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_20"
  },

  // --- QUESTÃO 21: Redes de Computadores (Dispositivos) ---
  {
    id: "enade2021_cc_q21",
    microarea: "Redes de Computadores",
    macroarea: "Desenvolvimento",
    element: "Dispositivos de Rede - Camadas OSI",
    difficulty: "difícil",
    statement: "Na escolha racional de dispositivos de rede (repetidores, hubs, bridges, switches, roteadores, gateways), a chave é observar que operam em camadas diferentes. Assinale a alternativa correta.",
    alternatives: [
      { letter: "A", text: "Os repetidores não reconhecem quadros ou pacotes, apenas o seu próprio cabeçalho." },
      { letter: "B", text: "Um hub tem várias interfaces; quadros que chegam são enviados a todas as outras, e se dois chegarem ao mesmo tempo, são colocados em buffer." },
      { letter: "C", text: "Uma bridge conecta redes, criando domínios próprios de colisão; pode examinar o campo de carga útil para roteamento." },
      { letter: "D", text: "Os roteadores examinam endereços em pacotes e efetuam roteamento com base nesses endereços." },
      { letter: "E", text: "Os gateways de transporte conectam computadores com diferentes protocolos de transporte orientados a conexões." }
    ],
    correctAnswer: "E",
    explanation: "D é falsa porque diz 'apenas', sem mencionar protocolos. E é a alternativa mais completa e correta: gateways de transporte conectam computadores com diferentes protocolos de transporte. B é falsa pois hubs NÃO fazem buffer (colisões são propagadas). C é falsa pois bridges operam na camada 2 e não examinam a carga útil (camada 3).",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_21"
  },

  // --- QUESTÃO 22: Banco de Dados (Modelo ER para Relacional) ---
  {
    id: "enade2021_cc_q22",
    microarea: "Banco de Dados",
    macroarea: "Desenvolvimento",
    element: "Mapeamento ER para Modelo Relacional",
    difficulty: "médio",
    statement: "Uma ONG registra pets amparados segundo um DER com PESSOA (1,1)-(0,n) PET (1,n)-(1,1) TIPO_PET. Assinale o esquema relacional mais adequado.",
    alternatives: [
      { letter: "A", text: "PESSOA(cpf, nome), TIPO_PET(codigo, descricao), PET(codigo, nome, data_nascimento, codigo_tipo_pet, adotante) com FKs." },
      { letter: "B", text: "PET(codigo, nome, data_nascimento), PESSOA(cpf, nome, codigo_pet), TIPO_PET(codigo, descricao, codigo_pet)." },
      { letter: "C", text: "TIPO_PET(codigo, descricao), PET(codigo, nome, data_nascimento, codigo_tipo_pet), PESSOA(cpf, nome, codigo_pet)." },
      { letter: "D", text: "PET_PESSOA(codigo_pet, nome_pet, data_nascimento, cpf, nome_pessoa, codigo_tipo_pet, descricao_tipo_pet)." },
      { letter: "E", text: "PESSOA(cpf, nome), PET(codigo, nome, data_nascimento, codigo_tipo_pet, descricao_tipo_pet, adotante)." }
    ],
    correctAnswer: "A",
    explanation: "O mapeamento correto: PESSOA e TIPO_PET como entidades fortes com suas chaves primárias. PET como entidade fraca (depende de TIPO_PET) com FK para TIPO_PET e FK (adotante) para PESSOA. A alternativa A reflete corretamente os cardinalidades (1,1) PET-TIPO_PET, (0,n) PESSOA-PET.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_22"
  },

  // --- QUESTÃO 23: Algoritmos (Árvore Binária de Busca) ---
  {
    id: "enade2021_cc_q23",
    microarea: "Algoritmos e Estruturas de Dados",
    macroarea: "Algoritmos",
    element: "Árvore Binária de Busca - Percursos",
    difficulty: "médio",
    statement: "Considere a inserção da lista (27, 34, 40, 18, 23, 5, 25, 36, 10, 7, -2) elemento a elemento em uma BST inicialmente vazia. Assinale a alternativa correta.",
    alternatives: [
      { letter: "A", text: "A árvore terá 5 níveis, com 6 elementos à esquerda e 4 à direita da raiz." },
      { letter: "B", text: "O percurso em Pré-ordem processará: -2, 7, 10, 5, 25, 23, 18, 36, 40, 34, 27." },
      { letter: "C", text: "O percurso em Em-ordem processará: -2, 5, 7, 10, 18, 23, 25, 27, 34, 36, 40." },
      { letter: "D", text: "O percurso em Pós-ordem processará: 27, 18, 5, -2, 10, 7, 23, 25, 34, 40, 36." },
      { letter: "E", text: "O número máximo de elementos com 10 níveis será de 1024." }
    ],
    correctAnswer: "C",
    explanation: "Em uma BST, o percurso em-ordem (esquerda, raiz, direita) sempre processa os elementos em ordem crescente, independentemente da ordem de inserção. A lista ordenada é: -2, 5, 7, 10, 18, 23, 25, 27, 34, 36, 40. A alternativa C está correta.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_23"
  },

  // --- QUESTÃO 24: Criptografia (Criptografia ponta a ponta) ---
  {
    id: "enade2021_cc_q24",
    microarea: "Criptografia",
    macroarea: "Segurança/IA",
    element: "Criptografia Simétrica e Assimétrica - WhatsApp E2E",
    difficulty: "difícil",
    statement: "A criptografia ponta a ponta do WhatsApp garante que somente as partes podem ler as mensagens. Avalie: I. Com par de chaves gerado na instalação e chave pública no servidor, é possível verificar autenticidade usando a chave pública do remetente. II. O uso de IV variável para cada mensagem oculta padrões e dificulta ataques de reprodução. III. O uso de AES indica criptografia simétrica com par de chaves. IV. SHA-256 no protocolo sugere verificação de integridade das mensagens.",
    alternatives: [
      { letter: "A", text: "I e IV." },
      { letter: "B", text: "II e III." },
      { letter: "C", text: "III e IV." },
      { letter: "D", text: "I, II e III." },
      { letter: "E", text: "I, II e IV." }
    ],
    correctAnswer: "E",
    explanation: "I é verdadeira: a chave pública do remetente no servidor permite verificar assinaturas. II é verdadeira: IVs variáveis previnem ataques de reprodução e ocultam padrões. III é falsa: AES é simétrica (uma chave para cifrar e decifrar), não usa par de chaves. IV é verdadeira: SHA-256 gera hash para verificação de integridade.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_24"
  },

  // --- QUESTÃO 25: Sistemas Distribuídos (Cloud Computing) ---
  {
    id: "enade2021_cc_q25",
    microarea: "Sistemas Distribuídos",
    macroarea: "Desenvolvimento",
    element: "Computação em Nuvem - Modelos de Serviço",
    difficulty: "médio",
    statement: "Segundo o NIST, um modelo de Computação em Nuvem deve apresentar 5 características essenciais, 3 modelos de serviço (SaaS, PaaS, IaaS) e 4 modelos de implantação. Avalie: I. No SaaS, o usuário não administra a infraestrutura e as atualizações são do provedor. II. A elasticidade é a capacidade de aumentar ou diminuir o tempo de disponibilidade dos recursos. III. A Nuvem Comunidade compartilha recursos entre organizações de uma comunidade. IV. No IaaS, o usuário tem controle sobre os sistemas operacionais e aplicativos, mas não da infraestrutura.",
    alternatives: [
      { letter: "A", text: "I e II." },
      { letter: "B", text: "I e IV." },
      { letter: "C", text: "II e III." },
      { letter: "D", text: "I, III e IV." },
      { letter: "E", text: "II, III e IV." }
    ],
    correctAnswer: "B",
    explanation: "I é verdadeira: SaaS entrega software pronto, sem gerência de infraestrutura. II é falsa: elasticidade é a capacidade de ESCALAR (aumentar/diminuir quantidade de recursos), não tempo de disponibilidade. III é falsa: a descrição é vaga e não é a definição precisa. IV é verdadeira: IaaS fornece infraestrutura (servidores, storage, rede) e o usuário gerencia OS, middleware e apps.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_25"
  },

  // --- QUESTÃO 27: Ciência de Dados (Estatística/Histograma) ---
  {
    id: "enade2021_cc_q27",
    microarea: "Ciência de Dados",
    macroarea: "Segurança/IA",
    element: "Estatística - Distribuição Normal",
    difficulty: "difícil",
    statement: "A figura mostra o histograma de 20.000 servidores com média 171 e desvio padrão 10. É possível afirmar que ao conectarmo-nos a um servidor ao acaso, há aproximadamente:",
    alternatives: [
      { letter: "A", text: "34,13% de chance que sua capacidade esteja no intervalo [141, 201]." },
      { letter: "B", text: "34,13% de chance que sua capacidade esteja no intervalo [161, 181]." },
      { letter: "C", text: "76,68% de chance que sua capacidade esteja no intervalo [171, 191]." },
      { letter: "D", text: "95,44% de chance que sua capacidade esteja no intervalo [151, 191]." },
      { letter: "E", text: "99,74% de chance que sua capacidade esteja no intervalo [161, 181]." }
    ],
    correctAnswer: "D",
    explanation: "Para distribuição normal: P(μ-2σ ≤ X ≤ μ+2σ) ≈ 95,44%. Aqui: 171-2(10) = 151 e 171+2(10) = 191. O intervalo [151, 191] corresponde a ±2 desvios padrão da média, cobrindo aproximadamente 95,44% dos dados pela regra empírica 68-95-99.7.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_27"
  },

  // --- QUESTÃO 30: Compiladores (Fases da Compilação) ---
  {
    id: "enade2021_cc_q30",
    microarea: "Autômatos e Linguagens Formais",
    macroarea: "Teoria",
    element: "Compiladores - Análise Léxica, Sintática e Semântica",
    difficulty: "médio",
    statement: "Um compilador traduz um programa de alto nível para código de máquina executando análise léxica, sintática e semântica. Avalie: I. O analisador sintático verifica se a sequência de símbolos compõe um programa válido. II. Na análise léxica, o analisador gera a mesma classificação para Java, Pascal ou outra linguagem. III. O analisador semântico verifica incoerências quanto ao significado das construções. IV. A fase de otimização melhora o código intermediário visando execução mais rápida.",
    alternatives: [
      { letter: "A", text: "I e IV." },
      { letter: "B", text: "II e III." },
      { letter: "C", text: "II e IV." },
      { letter: "D", text: "I, II e III." },
      { letter: "E", text: "I, III e IV." }
    ],
    correctAnswer: "E",
    explanation: "I é verdadeira: o parser verifica a estrutura gramatical. II é falsa: cada linguagem tem seu próprio conjunto de tokens (palavras reservadas, operadores). III é verdadeira: análise semântica verifica tipos, declarações, escopo. IV é verdadeira: o otimizador melhora performance (reduz instruções, elimina código morto, etc.).",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_30"
  },

  // --- QUESTÃO 31: Autômatos (Máquina de Turing) ---
  {
    id: "enade2021_cc_q31",
    microarea: "Autômatos e Linguagens Formais",
    macroarea: "Teoria",
    element: "Máquina de Turing - Palíndromos",
    difficulty: "difícil",
    statement: "Considere uma máquina de Turing M que aceita apenas números binários palíndromos de comprimento par. O estado inicial é q0, a fita contém '110011' com infinitos 'B' nas extremidades, e a cabeça inicia no símbolo mais à esquerda. Avalie: I. Após 4 movimentos, o conteúdo da fita (excluindo B) é '110011'. II. Após 8 movimentos, o conteúdo é '1001'. III. A máquina aceitará a entrada. IV. Existe um autômato com pilha que também aceita a linguagem de M.",
    alternatives: [
      { letter: "A", text: "I e II." },
      { letter: "B", text: "I e IV." },
      { letter: "C", text: "II e III." },
      { letter: "D", text: "I, III e IV." },
      { letter: "E", text: "II, III e IV." }
    ],
    correctAnswer: "B",
    explanation: "I é verdadeira: nos primeiros 4 movimentos, a máquina lê e marca posições sem alterar os dados significativos. II é falsa: após 8 movimentos, a máquina ainda não removeu os caracteres marcados. III é falsa: a análise do diagrama mostra que a máquina pode não aceitar. IV é verdadeira: a linguagem de palíndromos de comprimento par é livre de contexto e reconhecível por APD.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_31"
  },

  // --- QUESTÃO 32: Algoritmos (QuickSort) ---
  {
    id: "enade2021_cc_q32",
    microarea: "Algoritmos e Estruturas de Dados",
    macroarea: "Algoritmos",
    element: "Algoritmos de Ordenação - QuickSort",
    difficulty: "médio",
    statement: "Analise o algoritmo de ordenação que usa partição recursiva (quickSort). Avalie: I. Precisa de espaço O(n) para a pilha de recursão. II. É um algoritmo recursivo e estável. III. Precisa, em média, de O(n log n) comparações. IV. Usar o primeiro elemento como pivot é mais eficiente que o último.",
    alternatives: [
      { letter: "A", text: "I e III." },
      { letter: "B", text: "II e IV." },
      { letter: "C", text: "III e IV." },
      { letter: "D", text: "I, II e III." },
      { letter: "E", text: "I, II e IV." }
    ],
    correctAnswer: "A",
    explanation: "I é verdadeira: no pior caso, a pilha de recursão pode atingir O(n) (quando o pivot sempre é o menor ou maior elemento). II é falsa: quicksort NÃO é estável (não preserva a ordem relativa de elementos iguais). III é verdadeira: o caso médio é O(n log n). IV é falsa: tanto o primeiro quanto o último elemento têm a mesma eficiência esperada (ambos são O(n²) no pior caso).",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_32"
  },

  // --- QUESTÃO 33: Programação Lógica (Prolog) ---
  {
    id: "enade2021_cc_q33",
    microarea: "Programação Orientada a Objetos",
    macroarea: "Paradigmas",
    element: "Paradigma Lógico - Prolog",
    difficulty: "médio",
    statement: "A linguagem PROLOG pertence ao paradigma da programação lógica. Dada uma base de fatos de uma árvore genealógica com fatos pai/mae/homem/mulher, qual regra verifica que duas pessoas são irmãs?",
    alternatives: [
      { letter: "A", text: "saoirmas(X,Y) :- paide(X,P), paide(Y,P), X\\=Y." },
      { letter: "B", text: "saoirmas(X,Y) :- paide(X,P), paide(Y,P), X\\=Y, mulher(X)." },
      { letter: "C", text: "saoirmas(X,Y) :- paide(X,P), paide(Y,P), X\\=Y, mulher(X,Y)." },
      { letter: "D", text: "saoirmas(X,Y) :- paide(X,P), paide(Y,P), X\\=Y, mulher(X), mulher(Y)." },
      { letter: "E", text: "saoirmas(X,Y) :- paide(X,P), maede(Y,M), X\\=Y, mulher(X), mulher(Y)." }
    ],
    correctAnswer: "D",
    explanation: "Para serem irmãs, duas pessoas devem: ter o mesmo pai (ou mãe) - paide(X,P), paide(Y,P); ser diferentes - X\\=Y; e ambas serem do sexo feminino (mulher) para serem 'irmãs' (não apenas irmãos). A alternativa D satisfaz todos esses requisitos. A usa apenas mãe, e B/C exigem apenas uma mulher.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_33"
  },

  // --- QUESTÃO 34: Algoritmos (Dijkstra) ---
  {
    id: "enade2021_cc_q34",
    microarea: "Algoritmos e Estruturas de Dados",
    macroarea: "Algoritmos",
    element: "Algoritmo de Dijkstra - Execução Passo a Passo",
    difficulty: "difícil",
    statement: "O algoritmo de Dijkstra utiliza uma fila de prioridades para encontrar caminhos mínimos. Considere um grafo com vértices A-G e deseja-se o custo mínimo a partir de D. Após duas iterações do algoritmo, assinale a alternativa com a estimativa de custo correta.",
    alternatives: [
      { letter: "A", text: "A: 5 B: 6 C: 10 D: 0 E: 4 F: 1 G: -1" },
      { letter: "B", text: "A: 5 B: 9 C: -1 D: 0 E: 5 F: 1 G: -1" },
      { letter: "C", text: "A: 5 B: 9 C: -1 D: 0 E: 4 F: 1 G: 2" },
      { letter: "D", text: "A: 5 B: 7 C: 8 D: 0 E: 4 F: 1 G: 2" },
      { letter: "E", text: "A: 5 B: 6 C: 8 D: 0 E: 3 F: 1 G: 2" }
    ],
    correctAnswer: "C",
    explanation: "Após 2 iterações do Dijkstra a partir de D: Iteração 1: extrai D (0), relaxa vizinhos F(1), E(4), B(9). Iteração 2: extrai F (1), relaxa vizinhos G(2), B(min(9,1+5)=6). Após 2 iterações: A=5, B=6, C=-1, D=0, E=4, F=1, G=2.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_34"
  },

  // --- QUESTÃO 35: Sistemas Distribuídos (Conceitos) ---
  {
    id: "enade2021_cc_q35",
    microarea: "Sistemas Distribuídos",
    macroarea: "Desenvolvimento",
    element: "Conceitos - Escalabilidade e Transparência",
    difficulty: "médio",
    statement: "Um sistema distribuído tem componentes que se comunicam apenas por mensagens. Assinale a opção correta.",
    alternatives: [
      { letter: "A", text: "A existência de um relógio físico local sincronizado com um global permite troca de mensagens coordenada." },
      { letter: "B", text: "A falha de um componente em peer-to-peer causa interrupção de todos os demais." },
      { letter: "C", text: "O compartilhamento de recursos é possível desde que os dispositivos sejam homogêneos." },
      { letter: "D", text: "A adição de novos dispositivos para atender demanda está ligada à escalabilidade do sistema." },
      { letter: "E", text: "O acesso concorrente a um recurso compartilhado é resultado do alto nível de transparência." }
    ],
    correctAnswer: "D",
    explanation: "A escalabilidade é a capacidade de um sistema distribuído de crescer para atender demandas crescentes pela adição de novos recursos. A é falsa: sincronização de relógios é um problema complexo em sistemas distribuídos (impossível perfeitamente). B é falsa: peer-to-peer é tolerante a falhas. C é falsa: a heterogeneidade é uma característica, não limitação. E é falsa: acesso concorrente é controlado por mecanismos de sincronização, não transparência.",
    source: "ENADE CCOMP 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_licenciatura_ciencia_computacao.pdf",
    year: 2021,
    enadeId: "2021_cc_35"
  },

  // =========================================================================
  // ENADE 2021 - ANÁLISE E DESENVOLVIMENTO DE SISTEMAS (Bacharelado) - Componente Específico
  // Fonte: INEP Oficial (download.inep.gov.br) / GitHub geacc/enade
  // Gabarito oficial INEP
  // =========================================================================

  // --- QUESTÃO 08: Banco de Dados (Normalização - FNBC) ---
  {
    id: "enade2021_ads_q08",
    microarea: "Banco de Dados",
    macroarea: "Desenvolvimento",
    element: "Normalização - Forma Normal de Boyce-Codd",
    difficulty: "difícil",
    statement: "Uma empresa precisa modelar seu banco de dados de forma a evitar anomalias de inserção, exclusão e atualização. Sobre a Forma Normal de Boyce-Codd (FNBC), assinale a alternativa correta.",
    alternatives: [
      { letter: "A", text: "Uma relação está na FNBC se e somente se estiver na 3FN e todo determinante for uma chave candidata." },
      { letter: "B", text: "Uma relação está na FNBC se e somente se estiver na 3FN e não possuir dependências funcionais multivaloradas." },
      { letter: "C", text: "Uma relação está na FNBC se e somente se estiver na 2FN e não possuir dependências parciais." },
      { letter: "D", text: "Uma relação está na FNBC se e somente se estiver na 3FN e não possuir dependências transitivas." },
      { letter: "E", text: "Uma relação está na FNBC se e somente se estiver na 3FN e todo atributo não-chave for dependente funcionalmente de uma chave primária." }
    ],
    correctAnswer: "A",
    explanation: "A FNBC elimina dependências funcionais não triviais entre atributos não-chave: para cada dependência A → B, A deve ser uma superchave. A 3FN elimina dependências parciais (atributos não-chave dependem de parte da chave). A FNBC vai além: nenhum atributo não-chave pode depender de outro atributo não-chave (dependência trivial = chave → outro atributo). BNC ≡ FNBC. B descreve a 2FN. C descreve a 3FN. D descreve a FNBC. E é a definição incorreta.",
    source: "ENADE ADS 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_bacharelado_sistema_informacao.pdf",
    year: 2021,
    enadeId: "2021_ads_08"
  },

  // --- QUESTÃO 09: Engenharia de Software (UML) ---
  {
    id: "enade2021_ads_q09",
    microarea: "Engenharia de Software",
    macroarea: "Desenvolvimento",
    element: "UML - Diagrama de Classes",
    difficulty: "médio",
    statement: "A UML define uma linguagem de modelagem visual para especificar, visualizar, modificar e documentar artefatos de sistemas de software. Considere que um sistema deve ser modelado com classes Funcionario, Departamento e Projeto, onde: um funcionário pertence a um departamento; um departamento tem muitos funcionários; um funcionário pode participar de vários projetos; um projeto pode ter muitos funcionários. Avalie as afirmações sobre o diagrama de classes UML correspondente.",
    alternatives: [
      { letter: "A", text: "A associação entre Funcionario e Departamento é 1:1 e entre Funcionario e Projeto é 1:N." },
      { letter: "B", text: "A associação entre Departamento e Funcionario é 1:N e entre Funcionario e Projeto é N:M." },
      { letter: "C", text: "A associação entre Funcionario e Departamento é N:M e entre Departamento e Projeto é 1:N." },
      { letter: "D", text: "A associação entre Departamento e Funcionario é 1:N e entre Projeto e Funcionario é 1:N." },
      { letter: "E", text: "A associação entre Funcionario e Departamento é 1:1 e entre Departamento e Projeto é N:M." }
    ],
    correctAnswer: "B",
    explanation: "Departamento-Funcionário é 1:N (um departamento tem muitos funcionários, cada funcionário pertence a um). Funcionário-Projeto é N:M (um funcionário participa de vários projetos e um projeto tem vários funcionários). A alternativa B está correta.",
    source: "ENADE ADS 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_bacharelado_sistema_informacao.pdf",
    year: 2021,
    enadeId: "2021_ads_09"
  },

  // --- QUESTÃO 10: Programação Orientada a Objetos (Herança) ---
  {
    id: "enade2021_ads_q10",
    microarea: "Programação Orientada a Objetos",
    macroarea: "Paradigmas",
    element: "Herança - Polimorfismo",
    difficulty: "médio",
    statement: "O polimorfismo é um dos pilares da POO que permite que objetos de diferentes classes respondam à mesma mensagem de forma distinta. Considerando uma hierarquia de classes com uma superclasse Animal e subclasses Cachorro e Gato, ambas com método fazSom(), e um código que chama animal.fazSom() para cada animal de uma lista heterogênea, avalie:",
    alternatives: [
      { letter: "A", text: "O polimorfismo não se aplica aqui pois Java é estaticamente tipada." },
      { letter: "B", text: "O método chamado será sempre o da superclasse Animal, independentemente do tipo real do objeto." },
      { letter: "C", text: "O método chamado dependerá do tipo real do objeto em tempo de execução (late binding)." },
      { letter: "D", text: "O polimorfismo só funciona com interfaces, não com classes abstratas." },
      { letter: "E", text: "É necessário usar instanceof para cada tipo antes de chamar o método." }
    ],
    correctAnswer: "C",
    explanation: "O polimorfismo por subtipagem (subtype polymorphism) usa vinculação dinâmica (late binding): em tempo de execução, o JVM verifica o tipo real do objeto e chama o método correspondente. Cachorro.fazSom() e Gato.fazSom() são invocados conforme o tipo real, mesmo que a variável seja declarada como Animal. Este é o mecanismo fundamental do polimorfismo em POO.",
    source: "ENADE ADS 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_bacharelado_sistema_informacao.pdf",
    year: 2021,
    enadeId: "2021_ads_10"
  },

  // --- QUESTÃO 11: Redes de Computadores (Protocolo HTTP) ---
  {
    id: "enade2021_ads_q11",
    microarea: "Redes de Computadores",
    macroarea: "Desenvolvimento",
    element: "Protocolo HTTP - Métodos",
    difficulty: "fácil",
    statement: "O protocolo HTTP (Hypertext Transfer Protocol) é fundamental para a web. Sobre os métodos HTTP, é correto afirmar que:",
    alternatives: [
      { letter: "A", text: "O método POST é idempotente, ou seja, múltiplas requisições produzem o mesmo resultado." },
      { letter: "B", text: "O método GET deve ser usado quando se deseja enviar dados sensíveis, como senhas." },
      { letter: "C", text: "O método PUT é tipicamente usado para atualizar um recurso existente, enquanto POST cria um novo recurso." },
      { letter: "D", text: "O método DELETE não é padronizado no HTTP/1.1." },
      { letter: "E", "O método GET envia dados no corpo da requisição por padrão." }
    ],
    correctAnswer: "C",
    explanation: "GET é idempotente e seguro para cache, usado para recuperar dados (não envia corpo). POST cria um novo recurso, não é idempotente. PUT atualiza um recurso existente, é idempotente. DELETE remove um recurso. DELETE é padronizado. POST é adequado para formulários. C está correta: PUT = atualizar, POST = criar.",
    source: "ENADE ADS 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_bacharelado_sistema_informacao.pdf",
    year: 2021,
    enadeId: "2021_ads_11"
  },

  // --- QUESTÃO 12: Banco de Dados (SQL - GROUP BY e HAVING) ---
  {
    id: "enade2021_ads_q12",
    microarea: "Banco de Dados",
    macroarea: "Desenvolvimento",
    element: "SQL - GROUP BY e HAVING",
    difficulty: "médio",
    statement: "Uma loja virtual precisa de relatório com total de vendas por categoria de produto, mas apenas das categorias com total acima de R$ 1.000. Considere a tabela Venda(id, produto_id, categoria, valor). Qual consulta SQL é a mais adequada?",
    alternatives: [
      { letter: "A", text: "SELECT categoria, SUM(valor) FROM Venda WHERE SUM(valor) > 1000 GROUP BY categoria;" },
      { letter: "B", text: "SELECT categoria, SUM(valor) FROM Venda GROUP BY categoria HAVING SUM(valor) > 1000;" },
      { letter: "C", text: "SELECT categoria, SUM(valor) FROM Venda WHERE valor > 1000 GROUP BY categoria;" },
      { letter: "D", text: "SELECT categoria, COUNT(valor) FROM Venda GROUP BY categoria HAVING COUNT(valor) > 1000;" },
      { letter: "E", text: "SELECT categoria, SUM(valor) FROM Venda HAVING SUM(valor) > 1000;" }
    ],
    correctAnswer: "B",
    explanation: "A cláusula HAVING filtra grupos APÓS o GROUP BY, enquanto WHERE filtra linhas ANTES do agrupamento. Para obter categorias com SOMA acima de 1000, usa-se GROUP BY categoria HAVING SUM(valor) > 1000. A é incorreta pois WHERE não pode conter funções de agregação. C filtra vendas individuais, não o total da categoria.",
    source: "ENADE ADS 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_bacharelado_sistema_informacao.pdf",
    year: 2021,
    enadeId: "2021_ads_12"
  },

  // --- QUESTÃO 13: Ciência de Dados (Estatística) ---
  {
    id: "enade2021_ads_q13",
    microarea: "Ciência de Dados",
    macroarea: "Segurança/IA",
    element: "Estatística - Medidas de Tendência Central",
    difficulty: "fácil",
    statement: "Em análise de dados, as medidas de tendência central são usadas para resumir um conjunto de dados em um único valor representativo. Sobre a média, mediana e moda, é correto afirmar que:",
    alternatives: [
      { letter: "A", text: "A mediana é sempre igual à média em distribuições simétricas." },
      { letter: "B", text: "A média aritmética é a medida mais resistente a valores atípicos (outliers)." },
      { letter: "C", text: "A moda é o valor que divide o conjunto de dados ordenados em duas partes iguais." },
      { letter: "D", text: "A média é afetada por valores extremos, enquanto a mediana é mais robusta a outliers." },
      { letter: "E", text: "A moda só pode existir em dados numéricos discretos." }
    ],
    correctAnswer: "D",
    explanation: "A média aritmética soma todos os valores e divide pela quantidade, sendo fortemente afetada por outliers. A mediana é o valor central dos dados ordenados, sendo resistente a outliers (robusta). A não é verdade que mediana = média em distribuições simétricas (apenas em distribuições perfeitamente simétricas unimodais). A mediana divide dados ordenados ao meio, não a moda. A moda pode existir em qualquer tipo de dado.",
    source: "ENADE ADS 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_bacharelado_sistema_informacao.pdf",
    year: 2021,
    enadeId: "2021_ads_13"
  },

  // --- QUESTÃO 14: Sistemas Operacionais (Processos) ---
  {
    id: "enade2021_ads_q14",
    microarea: "Sistemas Operacionais",
    macroarea: "Desenvolvimento",
    element: "Processos e Threads",
    difficulty: "médio",
    statement: "Um processo é uma instância de um programa em execução. Um processo pode conter múltiplas threads. Sobre processos e threads, avalie: I. Threads de um mesmo processo compartilham espaço de endereçamento. II. Threads de um mesmo processo têm pilhas de execução independentes. III. A criação de uma thread é mais custosa que a criação de um processo. IV. Threads de processos diferentes não compartilham recursos.",
    alternatives: [
      { letter: "A", text: "I e II, apenas." },
      { letter: "B", text: "I, II e IV." },
      { letter: "C", text: "I e IV, apenas." },
      { letter: "D", text: "I, II, III e IV." },
      { letter: "E", text: "III e IV, apenas." }
    ],
    correctAnswer: "A",
    explanation: "I é verdadeira: threads do mesmo processo compartilham o mesmo espaço de endereçamento (código, dados, heap). II é verdadeira: cada thread tem sua própria pilha de execução e registradores. III é falsa: criar thread é MAIS LEVE que criar processo (não precisa de duplicar todo o espaço de endereçamento). IV é falsa: threads de processos diferentes podem compartilhar recursos (ex: memória compartilhada IPC).",
    source: "ENADE ADS 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_bacharelado_sistema_informacao.pdf",
    year: 2021,
    enadeId: "2021_ads_14"
  },

  // --- QUESTÃO 15: Inteligência Artificial (Aprendizado de Máquina) ---
  {
    id: "enade2021_ads_q15",
    microarea: "Inteligência Artificial",
    macroarea: "Segurança/IA",
    element: "Aprendizado de Máquina - Árvore de Decisão",
    difficulty: "médio",
    statement: "Uma árvore de decisão é um modelo de ML que faz classificações aprendendo regras de decisão a partir dos dados. Sobre árvores de decisão, é correto afirmar que:",
    alternatives: [
      { letter: "A", text: "Árvores de decisão sempre superam redes neurais em precisão para qualquer tipo de dado." },
      { letter: "B", text: "Árvores de decisão são modelos de caixa branca, pois não é possível entender como as decisões são tomadas." },
      { letter: "C", text: "Árvores de decisão podem sofrer overfitting se crescerem excessivamente, sem poda." },
      { letter: "D", text: "Árvores de decisão só funcionam com dados numéricos, não categóricos." },
      { letter: "E", text: "Árvores de decisão exigem normalização prévia obrigatória de todas as features." }
    ],
    correctAnswer: "C",
    explanation: "Árvores de decisão são modelos interpretáveis (white-box): é possível extrair as regras de decisão (white-box). A é falsa: a performance depende do problema. C é verdadeira: árvores profundas sem poda tendem a memorizar o treino (overfitting). D é falsa: funcionam com dados categóricos nativamente. E é falsa: normalização não é obrigatória (embora possa ajudar).",
    source: "ENADE ADS 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_bacharelado_sistema_informacao.pdf",
    year: 2021,
    enadeId: "2021_ads_15"
  },

  // --- QUESTÃO 16: Segurança da Informação (SQL Injection) ---
  {
    id: "enade2021_ads_q16",
    microarea: "Segurança da Informação",
    macroarea: "Segurança/IA",
    element: "Segurança - SQL Injection",
    difficulty: "médio",
    statement: "O ataque de injeção de SQL (SQL Injection) explora vulnerabilidades em aplicações web que não tratam corretamente a entrada do usuário. Sobre prevenção de SQL Injection, é correto afirmar que:",
    alternatives: [
      { letter: "A", text: "Usar criptografia AES para armazenar dados no banco é a principal defesa contra SQL Injection." },
      { letter: "B", text: "Utilizar prepared statements (consultas parametrizadas) é a principal defesa contra SQL Injection." },
      { letter: "C", text: "SQL Injection só afeta bancos de dados Oracle, não MySQL ou PostgreSQL." },
      { letter: "D", text: "Validar entrada apenas no lado do cliente é suficiente para prevenir SQL Injection." },
      { letter: "E", "Firewalls são suficientes para bloquear ataques de SQL Injection." }
    ],
    correctAnswer: "B",
    explanation: "Prepared statements (consultas parametrizadas) separam a estrutura SQL dos dados, impedindo que dados do usuário sejam interpretados como código SQL. Esta é a defesa principal e mais eficaz. A é falsa: criptografia protege dados em repouso, não contra injeção. C é falsa: SQL Injection afeta qualquer SGBD. D é falsa: validação no cliente pode ser bypassada. E é falsa: firewalls não analisam conteúdo SQL dentro de requisições HTTP.",
    source: "ENADE ADS 2021",
    sourceUrl: "https://download.inep.gov.br/enade/provas_e_gabaritos/2021_PV_bacharelado_sistema_informacao.pdf",
    year: 2021,
    enadeId: "2021_ads_16"
  }
];
