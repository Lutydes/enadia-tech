// =============================================================================
// ENADE Expanded Question Bank - Part 2: Microareas 5-15
// POO, BD, ES, SO, Redes, SD, Criptografia, IA, CD, Ética, Legislação
// =============================================================================

import { ExpandedEnadeQuestion } from './enade_expanded_bank';

export const expandedBankPart2: ExpandedEnadeQuestion[] = [
  // ===================== PROGRAMAÇÃO ORIENTADA A OBJETOS (8) =====================
  {
    id: 'EXP-POO-001', microarea: 'Programação Orientada a Objetos', macroarea: 'Paradigmas', element: 'Padrões de projeto - Aplicação', difficulty: 'médio',
    statement: 'Uma empresa de e-commerce precisa implementar um sistema de notificações que suporte múltiplos canais (email, SMS, push). Novos canais devem poder ser adicionados sem modificar o código existente. Qual padrão de projeto é mais adequado?\n\nA) Singleton — garante uma única instância do gerenciador de notificações\nB) Observer — permite que objetos inscritos sejam notificados automaticamente\nC) Strategy — define uma família de algoritmos encapsulados e intercambiáveis\nD) Factory Method — delega a criação de notificações para subclasses\nE) Decorator — adiciona responsabilidades a objetos dinamicamente',
    alternatives: [{ letter: 'A', text: 'Singleton — garante uma única instância do gerenciador de notificações' }, { letter: 'B', text: 'Observer — permite que objetos inscritos sejam notificados automaticamente' }, { letter: 'C', text: 'Strategy — define uma família de algoritmos encapsulados e intercambiáveis' }, { letter: 'D', text: 'Factory Method — delega a criação de notificações para subclasses' }, { letter: 'E', text: 'Decorator — adiciona responsabilidades a objetos dinamicamente' }],
    correctAnswer: 'C', explanation: 'O padrão Strategy é ideal quando há múltiplos algoritmos (canais de notificação) que podem ser intercambiados em tempo de execução. Cada canal implementa a mesma interface, e novos canais podem ser adicionados sem modificar o código cliente — princípio Aberto/Fechado.', source: 'elaborada', triA: 1.8, triB: 0.2, triC: 0.20,
  },
  {
    id: 'EXP-POO-002', microarea: 'Programação Orientada a Objetos', macroarea: 'Paradigmas', element: 'Herança e polimorfismo - Compreensão', difficulty: 'fácil',
    statement: 'Em um sistema de gestão de veículos, a classe Veiculo tem um método calcularImposto(). As subclasses Carro e Moto sobrescrevem esse método com cálculos diferentes. Quando o sistema chama veiculo.calcularImposto() para um objeto Carro, qual mecanismo OO está em ação?\n\nA) Encapsulamento\nB) Herança\nC) Polimorfismo\nD) Abstração\nE) Composição',
    alternatives: [{ letter: 'A', text: 'Encapsulamento' }, { letter: 'B', text: 'Herança' }, { letter: 'C', text: 'Polimorfismo' }, { letter: 'D', text: 'Abstração' }, { letter: 'E', text: 'Composição' }],
    correctAnswer: 'C', explanation: 'Polimorfismo permite que uma referência do tipo supervalidado (Veiculo) invoque o método sobrescrito do tipo real (Carro). A mesma chamada gera comportamentos diferentes dependendo do objeto concreto, isso é polimorfismo por subclasse.', source: 'elaborada', triA: 1.1, triB: -1.2, triC: 0.30,
  },
  {
    id: 'EXP-POO-003', microarea: 'Programação Orientada a Objetos', macroarea: 'Paradigmas', element: 'Princípios SOLID - Aplicação', difficulty: 'médio',
    statement: 'O princípio de Responsabilidade Única (SRP) do SOLID afirma que uma classe deve ter apenas uma razão para mudar. Em um sistema, a classe RelatorioFinanceiro gera relatórios E envia emails. Qual refatoração segue o SRP?\n\nA) Criar subclasses RelatorioFinanceiroSimples e RelatorioFinanceiroCompleto\nB) Extrair a funcionalidade de email para uma classe EmailService separada\nC) Transformar a classe em uma interface com dois métodos\nD) Adicionar um parâmetro booleano para controlar o envio de email\nE) Usar um padrão Singleton para garantir uma única instância',
    alternatives: [{ letter: 'A', text: 'Criar subclasses RelatorioFinanceiroSimples e RelatorioFinanceiroCompleto' }, { letter: 'B', text: 'Extrair a funcionalidade de email para uma classe EmailService separada' }, { letter: 'C', text: 'Transformar a classe em uma interface com dois métodos' }, { letter: 'D', text: 'Adicionar um parâmetro booleano para controlar o envio de email' }, { letter: 'E', text: 'Usar um padrão Singleton para garantir uma única instância' }],
    correctAnswer: 'B', explanation: 'O SRP diz que cada classe deve ter uma única responsabilidade. Gerar relatórios e enviar emails são duas responsabilidades distintas. A refatoração correta é separar a funcionalidade de email em uma classe EmailService, que pode ser injetada via dependência.', source: 'elaborada', triA: 1.7, triB: 0.0, triC: 0.22,
  },
  {
    id: 'EXP-POO-004', microarea: 'Programação Orientada a Objetos', macroarea: 'Paradigmas', element: 'Interfaces e classes abstratas - Compreensão', difficulty: 'médio',
    statement: 'Qual é a principal diferença entre uma interface e uma classe abstrata em Java?\n\nA) Classes abstratas não podem ter métodos concretos\nB) Interfaces podem definir atributos com valores\nC) Uma classe pode implementar múltiplas interfaces mas estender apenas uma classe abstrata\nD) Interfaces são mais lentas que classes abstratas em tempo de execução\nE) Classes abstratas não podem ter construtores',
    alternatives: [{ letter: 'A', text: 'Classes abstratas não podem ter métodos concretos' }, { letter: 'B', text: 'Interfaces podem definir atributos com valores' }, { letter: 'C', text: 'Uma classe pode implementar múltiplas interfaces mas estender apenas uma classe abstrata' }, { letter: 'D', text: 'Interfaces são mais lentas que classes abstratas em tempo de execução' }, { letter: 'E', text: 'Classes abstratas não podem ter construtores' }],
    correctAnswer: 'C', explanation: 'Em Java, uma classe só pode estender uma única classe (herança simples), mas pode implementar múltiplas interfaces. Classes abstratas podem ter métodos concretos e construtores, enquanto interfaces tradicionais só definem contratos de métodos.', source: 'elaborada', triA: 1.5, triB: -0.2, triC: 0.24,
  },
  {
    id: 'EXP-POO-005', microarea: 'Programação Orientada a Objetos', macroarea: 'Paradigmas', element: 'UML - Identificação', difficulty: 'fácil',
    statement: 'No diagrama de classes UML, qual símbolo representa a relação de herança entre classes?\n\nA) Linha contínua com seta aberta\nB) Linha tracejada com seta aberta\nC) Linha contínua com triângulo vazado apontando para a superclasse\nD) Losango vazado na extremidade\nE) Linha contínua com asterisco',
    alternatives: [{ letter: 'A', text: 'Linha contínua com seta aberta' }, { letter: 'B', text: 'Linha tracejada com seta aberta' }, { letter: 'C', text: 'Linha contínua com triângulo vazado apontando para a superclasse' }, { letter: 'D', text: 'Losango vazado na extremidade' }, { letter: 'E', text: 'Linha contínua com asterisco' }],
    correctAnswer: 'C', explanation: 'A herança em UML é representada por uma linha contínua com um triângulo vazado (não preenchido) apontando da subclasse para a superclasse. A seta tracejada com triângulo vazado indica implementação de interface.', source: 'elaborada', triA: 1.0, triB: -1.0, triC: 0.28,
  },
  {
    id: 'EXP-POO-006', microarea: 'Programação Orientada a Objetos', macroarea: 'Paradigmas', element: 'Tratamento de exceções - Aplicação', difficulty: 'médio',
    statement: 'Em um sistema bancário, durante uma transferência, ocorre uma exceção de saldo insuficiente. O bloco finally {} é útil neste cenário para:\n\nA) Lançar a exceção para o usuário final\nB) Registrar a tentativa de transferência em log e liberar recursos\nC) Tentar a operação novamente automaticamente\nD) Cancelar a transação sem registro\nE) Desviar o fluxo para outra conta',
    alternatives: [{ letter: 'A', text: 'Lançar a exceção para o usuário final' }, { letter: 'B', text: 'Registrar a tentativa de transferência em log e liberar recursos' }, { letter: 'C', text: 'Tentar a operação novamente automaticamente' }, { letter: 'D', text: 'Cancelar a transação sem registro' }, { letter: 'E', text: 'Desviar o fluxo para outra conta' }],
    correctAnswer: 'B', explanation: 'O bloco finally é executado independentemente de ocorrer exceção ou não. É ideal para liberação de recursos (conexões, arquivos) e operações de limpeza como registro em log, garantindo que essas ações sempre sejam executadas.', source: 'elaborada', triA: 1.4, triB: -0.3, triC: 0.25,
  },
  {
    id: 'EXP-POO-007', microarea: 'Programação Orientada a Objetos', macroarea: 'Paradigmas', element: 'Encapsulamento e abstração - Compreensão', difficulty: 'fácil',
    statement: 'O encapsulamento em POO consiste em:\n\nA) Esconder a complexidade interna de um objeto e expor apenas uma interface controlada\nB) Herdar características de múltiplas classes simultaneamente\nC) Permitir que um objeto assuma diferentes formas em tempo de execução\nD) Agrupar objetos similares em coleções\nE) Converter tipos de dados automaticamente',
    alternatives: [{ letter: 'A', text: 'Esconder a complexidade interna de um objeto e expor apenas uma interface controlada' }, { letter: 'B', text: 'Herdar características de múltiplas classes simultaneamente' }, { letter: 'C', text: 'Permitir que um objeto assuma diferentes formas em tempo de execução' }, { letter: 'D', text: 'Agrupar objetos similares em coleções' }, { letter: 'E', text: 'Converter tipos de dados automaticamente' }],
    correctAnswer: 'A', explanation: 'Encapsulamento é o princípio de ocultar detalhes internos de implementação (atributos) e expor apenas operações seguras (métodos públicos). Isso protege a integridade dos dados e reduz o acoplamento entre componentes.', source: 'elaborada', triA: 1.2, triB: -1.3, triC: 0.30,
  },
  {
    id: 'EXP-POO-008', microarea: 'Programação Orientada a Objetos', macroarea: 'Paradigmas', element: 'Composição - Compreensão', difficulty: 'difícil',
    statement: 'Sobre composição e agregação em UML, qual afirmação está correta?\n\nA) Na composição, o objeto parte pode existir independentemente do todo\nB) Na agregação, a destruição do todo implica destruição das partes\nC) Na composição, o ciclo de vida das partes está ligado ao todo — se o todo é destruído, as partes também são\nD) Composição e agregação são conceitos idênticos em POO\nE) A agregação é mais forte que a composição',
    alternatives: [{ letter: 'A', text: 'Na composição, o objeto parte pode existir independentemente do todo' }, { letter: 'B', text: 'Na agregação, a destruição do todo implica destruição das partes' }, { letter: 'C', text: 'Na composição, o ciclo de vida das partes está ligado ao todo — se o todo é destruído, as partes também são' }, { letter: 'D', text: 'Composição e agregação são conceitos idênticos em POO' }, { letter: 'E', text: 'A agregação é mais forte que a composição' }],
    correctAnswer: 'C', explanation: 'Composição é uma relação forte onde a parte não existe sem o todo (ex: casa e cômodos). Se a casa é demolida, os cômodos deixam de existir. Na agregação, a parte pode existir independentemente (ex: departamento e professor).', source: 'elaborada', triA: 2.0, triB: 0.7, triC: 0.15,
  },

  // ===================== BANCO DE DADOS (8) =====================
  {
    id: 'EXP-BD-001', microarea: 'Banco de Dados', macroarea: 'Desenvolvimento', element: 'SQL - Aplicação', difficulty: 'médio',
    statement: 'Uma loja precisa listar o nome de todos os clientes que fizeram compras acima de R$ 500, mostrando apenas um registro por cliente, mesmo que tenham feito múltiplas compras. Qual query SQL é correta?\n\nA) SELECT nome FROM clientes WHERE valor > 500\nB) SELECT DISTINCT nome FROM clientes JOIN compras ON clientes.id = compras.cliente_id WHERE valor > 500\nC) SELECT nome, SUM(valor) FROM clientes GROUP BY nome HAVING SUM(valor) > 500\nD) SELECT nome FROM clientes WHERE EXISTS (SELECT 1 FROM compras WHERE valor > 500)\nE) SELECT ALL nome FROM clientes INNER JOIN compras WHERE valor > 500',
    alternatives: [{ letter: 'A', text: 'SELECT nome FROM clientes WHERE valor > 500' }, { letter: 'B', text: 'SELECT DISTINCT nome FROM clientes JOIN compras ON clientes.id = compras.cliente_id WHERE valor > 500' }, { letter: 'C', text: 'SELECT nome, SUM(valor) FROM clientes GROUP BY nome HAVING SUM(valor) > 500' }, { letter: 'D', text: 'SELECT nome FROM clientes WHERE EXISTS (SELECT 1 FROM compras WHERE valor > 500)' }, { letter: 'E', text: 'SELECT ALL nome FROM clientes INNER JOIN compras WHERE valor > 500' }],
    correctAnswer: 'B', explanation: 'DISTINCT elimina duplicatas. O JOIN conecta clientes às compras, o WHERE filtra por valor > 500, e o DISTINCT garante que cada cliente apareça apenas uma vez, mesmo com múltiplas compras qualificadas.', source: 'elaborada', triA: 1.8, triB: 0.1, triC: 0.20,
  },
  {
    id: 'EXP-BD-002', microarea: 'Banco de Dados', macroarea: 'Desenvolvimento', element: 'Normalização - Compreensão', difficulty: 'difícil',
    statement: 'Uma tabela de pedidos contém: pedido_id, cliente_nome, cliente_endereco, produto_nome, produto_preco, quantidade. Qual forma normal está sendo violada e qual problema isso causa?\n\nA) 1NF — dados repetitivos em uma mesma coluna\nB) 2NF — dependência parcial de atributos não-chave em parte da chave composta\nC) 3NF — dependência transitiva (cliente_nome depende de cliente_endereco, não diretamente da chave)\nD) BCNF — violação de dependência funcional multivalorada\nE) 4NF — dados não atômicos',
    alternatives: [{ letter: 'A', text: '1NF — dados repetitivos em uma mesma coluna' }, { letter: 'B', text: '2NF — dependência parcial de atributos não-chave em parte da chave composta' }, { letter: 'C', text: '3NF — dependência transitiva (cliente_nome depende de cliente_endereco, não diretamente da chave)' }, { letter: 'D', text: 'BCNF — violação de dependência funcional multivalorada' }, { letter: 'E', text: '4NF — dados não atômicos' }],
    correctAnswer: 'C', explanation: 'A tabela viola a 3NF pois cliente_nome e cliente_endereco dependem transitivamente de pedido_id (através de cliente_id que não está explícito). Para atingir 3NF, deveríamos separar em tabelas: Pedidos, Clientes e Produtos.', source: 'elaborada', triA: 2.2, triB: 0.9, triC: 0.14,
  },
  {
    id: 'EXP-BD-003', microarea: 'Banco de Dados', macroarea: 'Desenvolvimento', element: 'Transações e ACID - Compreensão', difficulty: 'médio',
    statement: 'Em um sistema bancário, uma transferência entre contas envolve: debitar da conta origem E creditar na conta destino. Se o servidor falhar após o débito mas antes do crédito, qual propriedade ACID garante que ambas as operações sejam revertidas?\n\nA) Atomicidade\nB) Consistência\nC) Isolamento\nD) Durabilidade\nE) Integridade',
    alternatives: [{ letter: 'A', text: 'Atomicidade' }, { letter: 'B', text: 'Consistência' }, { letter: 'C', text: 'Isolamento' }, { letter: 'D', text: 'Durabilidade' }, { letter: 'E', text: 'Integridade' }],
    correctAnswer: 'A', explanation: 'Atomicidade garante que uma transação é "tudo ou nada" — ou todas as operações são concluídas com sucesso, ou nenhuma é. Se houver falha, a transação é revertida (rollback) pelo sistema, garantindo que o débito seja desfeito.', source: 'elaborada', triA: 1.5, triB: -0.2, triC: 0.24,
  },
  {
    id: 'EXP-BD-004', microarea: 'Banco de Dados', macroarea: 'Desenvolvimento', element: 'JOINs - Aplicação', difficulty: 'médio',
    statement: 'Para listar TODOS os departamentos, incluindo aqueles sem nenhum funcionário, e os funcionários de cada departamento, qual tipo de JOIN deve ser utilizado?\n\nA) INNER JOIN\nB) LEFT JOIN (com departamentos à esquerda)\nC) RIGHT JOIN\nD) CROSS JOIN\nE) SELF JOIN',
    alternatives: [{ letter: 'A', text: 'INNER JOIN' }, { letter: 'B', text: 'LEFT JOIN (com departamentos à esquerda)' }, { letter: 'C', text: 'RIGHT JOIN' }, { letter: 'D', text: 'CROSS JOIN' }, { letter: 'E', text: 'SELF JOIN' }],
    correctAnswer: 'B', explanation: 'LEFT JOIN preserva todos os registros da tabela à esquerda (departamentos), mesmo que não haja correspondência na tabela à direita (funcionários). Departamentos sem funcionários aparecerão com NULL nas colunas de funcionários. INNER JOIN excluiria esses departamentos.', source: 'elaborada', triA: 1.6, triB: 0.0, triC: 0.22,
  },
  {
    id: 'EXP-BD-005', microarea: 'Banco de Dados', macroarea: 'Desenvolvimento', element: 'Índices - Compreensão', difficulty: 'médio',
    statement: 'Sobre índices em banco de dados, qual afirmação está correta?\n\nA) Índices sempre melhoram o desempenho de todas as consultas\nB) Índices aumentam o consumo de memória e tornam INSERT/UPDATE/DELETE mais lentos\nC) Um índice é inútil para buscas em colunas frequentemente filtradas no WHERE\nD) Índices eliminam a necessidade de normalização\nE) Bancos de dados criam índices automaticamente para todas as colunas',
    alternatives: [{ letter: 'A', text: 'Índices sempre melhoram o desempenho de todas as consultas' }, { letter: 'B', text: 'Índices aumentam o consumo de memória e tornam INSERT/UPDATE/DELETE mais lentos' }, { letter: 'C', text: 'Um índice é inútil para buscas em colunas frequentemente filtradas no WHERE' }, { letter: 'D', text: 'Índices eliminam a necessidade de normalização' }, { letter: 'E', text: 'Bancos de dados criam índices automaticamente para todas as colunas' }],
    correctAnswer: 'B', explanation: 'Índices aceleram leituras (SELECT) mas desaceleram escritas pois cada INSERT/UPDATE/DELETE requer atualização dos índices. Otimizar índices é um trade-off entre velocidade de leitura e escrita, além de consumir espaço de armazenamento.', source: 'elaborada', triA: 1.7, triB: 0.2, triC: 0.20,
  },
  {
    id: 'EXP-BD-006', microarea: 'Banco de Dados', macroarea: 'Desenvolvimento', element: 'NoSQL - Identificação', difficulty: 'fácil',
    statement: 'Para armazenar dados de um sistema de redes sociais onde cada usuário tem documentos com estrutura variável (uns com campo "telefone", outros sem; uns com lista de "interesses", outros com "certificações"), qual tipo de banco de dados é mais adequado?\n\nA) Relacional (SQL) com tabelas normalizadas\nB) Documento (ex: MongoDB) com schema flexível\nC) Colunar (ex: Cassandra) para análise temporal\nD) Grafos (ex: Neo4j) para relacionamentos\nE) Chave-valor (ex: Redis) para cache',
    alternatives: [{ letter: 'A', text: 'Relacional (SQL) com tabelas normalizadas' }, { letter: 'B', text: 'Documento (ex: MongoDB) com schema flexível' }, { letter: 'C', text: 'Colunar (ex: Cassandra) para análise temporal' }, { letter: 'D', text: 'Grafos (ex: Neo4j) para relacionamentos' }, { letter: 'E', text: 'Chave-valor (ex: Redis) para cache' }],
    correctAnswer: 'B', explanation: 'Bancos de dados orientados a documentos (como MongoDB) armazenam dados em formato JSON-like com schema flexível. Cada documento pode ter campos diferentes, ideal para perfis de usuários com atributos variáveis. Em bancos relacionais, isso exigiria muitas tabelas ou colunas NULL.', source: 'elaborada', triA: 1.3, triB: -0.5, triC: 0.25,
  },
  {
    id: 'EXP-BD-007', microarea: 'Banco de Dados', macroarea: 'Desenvolvimento', element: 'Integridade referencial - Compreensão', difficulty: 'fácil',
    statement: 'O que acontece ao tentar excluir um registro de uma tabela pai que possui registros filhos em uma tabela com chave estrangeira configurada com ON DELETE RESTRICT?\n\nA) O registro é excluído e os filhos ficam órfãos\nB) A exclusão é bloqueada até que todos os filhos sejam removidos\nC) Os filhos são automaticamente excluídos em cascata\nD) A chave estrangeira dos filhos é automaticamente definida como NULL\nE) O banco cria uma cópia dos filhos antes da exclusão',
    alternatives: [{ letter: 'A', text: 'O registro é excluído e os filhos ficam órfãos' }, { letter: 'B', text: 'A exclusão é bloqueada até que todos os filhos sejam removidos' }, { letter: 'C', text: 'Os filhos são automaticamente excluídos em cascata' }, { letter: 'D', text: 'A chave estrangeira dos filhos é automaticamente definida como NULL' }, { letter: 'E', text: 'O banco cria uma cópia dos filhos antes da exclusão' }],
    correctAnswer: 'B', explanation: 'ON DELETE RESTRICT impede a exclusão do registro pai se existirem filhos referenciando-o. O SGBD retorna um erro. Para exclusão automática de filhos, usa-se CASCADE; para definir FK como NULL, usa-se SET NULL.', source: 'elaborada', triA: 1.4, triB: -0.7, triC: 0.26,
  },
  {
    id: 'EXP-BD-008', microarea: 'Banco de Dados', macroarea: 'Desenvolvimento', element: 'Views e subconsultas - Aplicação', difficulty: 'médio',
    statement: 'Uma view (visão) em SQL é definida como uma consulta armazenada. Qual é a principal vantagem de usar views?\n\nA) Melhorar significativamente o desempenho de consultas complexas\nB) Simplificar consultas complexas, fornecer segurança de dados e reutilizar lógica de negócio\nC) Eliminar a necessidade de índices no banco de dados\nD) Permitir a modificação da estrutura de tabelas sem impacto nas aplicações\nE) Reduzir o tamanho físico do banco de dados',
    alternatives: [{ letter: 'A', text: 'Melhorar significativamente o desempenho de consultas complexas' }, { letter: 'B', text: 'Simplificar consultas complexas, fornecer segurança de dados e reutilizar lógica de negócio' }, { letter: 'C', text: 'Eliminar a necessidade de índices no banco de dados' }, { letter: 'D', text: 'Permitir a modificação da estrutura de tabelas sem impacto nas aplicações' }, { letter: 'E', text: 'Reduzir o tamanho físico do banco de dados' }],
    correctAnswer: 'B', explanation: 'Views simplificam consultas complexas encapsulando-as em objetos nomeados, permitem controle de acesso (segurança colunar/row-level) e garantem consistência lógica. Porém, não melhoram desempenho (podem até degradá-lo) e não reduzem espaço físico.', source: 'elaborada', triA: 1.5, triB: -0.1, triC: 0.23,
  },

  // ===================== ENGENHARIA DE SOFTWARE (8) =====================
  {
    id: 'EXP-ES-001', microarea: 'Engenharia de Software', macroarea: 'Desenvolvimento', element: 'Metodologias ágeis - Compreensão', difficulty: 'fácil',
    statement: 'No framework Scrum, qual é a principal responsabilidade do Product Owner?\n\nA) Gerenciar o processo Scrum e remover impedimentos do time\nB) Garantir que o Product Backlog esteja visível, transparente e claro para todos\nC) Codificar as funcionalidades mais complexas do sprint\nD) Conduzir as Daily Scrums diariamente\nE) Realizar testes de aceitação do usuário',
    alternatives: [{ letter: 'A', text: 'Gerenciar o processo Scrum e remover impedimentos do time' }, { letter: 'B', text: 'Garantir que o Product Backlog esteja visível, transparente e claro para todos' }, { letter: 'C', text: 'Codificar as funcionalidades mais complexas do sprint' }, { letter: 'D', text: 'Conduzir as Daily Scrums diariamente' }, { letter: 'E', text: 'Realizar testes de aceitação do usuário' }],
    correctAnswer: 'B', explanation: 'O Product Owner é responsável por maximizar o valor do produto gerenciando o Product Backlog — priorizando itens, garantindo transparência e alinhamento com os stakeholders. O Scrum Master gerencia o processo (A) e a equipe codifica (C).', source: 'elaborada', triA: 1.2, triB: -1.0, triC: 0.28,
  },
  {
    id: 'EXP-ES-002', microarea: 'Engenharia de Software', macroarea: 'Desenvolvimento', element: 'Testes de software - Aplicação', difficulty: 'médio',
    statement: 'Qual tipo de teste verifica o comportamento do sistema como um todo, sem conhecimento da estrutura interna do código?\n\nA) Teste de unidade\nB) Teste de integração\nC) Teste de caixa preta (funcional)\nD) Teste de mutação\nE) Teste de regressão',
    alternatives: [{ letter: 'A', text: 'Teste de unidade' }, { letter: 'B', text: 'Teste de integração' }, { letter: 'C', text: 'Teste de caixa preta (funcional)' }, { letter: 'D', text: 'Teste de mutação' }, { letter: 'E', text: 'Teste de regressão' }],
    correctAnswer: 'C', explanation: 'Teste de caixa preta (funcional) avalia o sistema com base em suas especificações externas, sem acessar o código interno. Foca nos inputs e outputs esperados, verificando se o sistema atende aos requisitos funcionais.', source: 'elaborada', triA: 1.3, triB: -0.4, triC: 0.25,
  },
  {
    id: 'EXP-ES-003', microarea: 'Engenharia de Software', macroarea: 'Desenvolvimento', element: 'CI/CD e DevOps - Identificação', difficulty: 'médio',
    statement: 'Em uma pipeline de CI/CD, o estágio de Continuous Integration (Integração Contínua) é responsável por:\n\nA) Fazer deploy automático em produção a cada commit\nB) Compilar, executar testes automatizados e verificar a qualidade a cada mudança de código\nC) Gerenciar a infraestrutura de servidores em nuvem\nD) Coletar métricas de performance dos usuários finais\nE) Negociar requisitos com os stakeholders',
    alternatives: [{ letter: 'A', text: 'Fazer deploy automático em produção a cada commit' }, { letter: 'B', text: 'Compilar, executar testes automatizados e verificar a qualidade a cada mudança de código' }, { letter: 'C', text: 'Gerenciar a infraestrutura de servidores em nuvem' }, { letter: 'D', text: 'Coletar métricas de performance dos usuários finais' }, { letter: 'E', text: 'Negociar requisitos com os stakeholders' }],
    correctAnswer: 'B', explanation: 'CI automatiza o processo de build, testes e análise estática a cada commit, detectando problemas cedo. O CD (Continuous Delivery/Deployment) cuida do deploy. CI foca na integração e validação; CD foca na entrega e implantação.', source: 'elaborada', triA: 1.6, triB: 0.1, triC: 0.22,
  },
  {
    id: 'EXP-ES-004', microarea: 'Engenharia de Software', macroarea: 'Desenvolvimento', element: 'Versionamento (Git) - Aplicação', difficulty: 'fácil',
    statement: 'No Git, qual comando cria uma nova branch e imediatamente muda para ela?\n\nA) git branch nova-branch && git checkout nova-branch\nB) git checkout -b nova-branch\nC) git merge nova-branch\nD) git push nova-branch\nE) git clone nova-branch',
    alternatives: [{ letter: 'A', text: 'git branch nova-branch && git checkout nova-branch' }, { letter: 'B', text: 'git checkout -b nova-branch' }, { letter: 'C', text: 'git merge nova-branch' }, { letter: 'D', text: 'git push nova-branch' }, { letter: 'E', text: 'git clone nova-branch' }],
    correctAnswer: 'B', explanation: 'git checkout -b nova-branch cria e muda para a nova branch em um único comando. A alternativa A faz a mesma coisa em dois comandos. A partir do Git 2.23, também pode-se usar git switch -c nova-branch.', source: 'elaborada', triA: 1.0, triB: -1.4, triC: 0.30,
  },
  {
    id: 'EXP-ES-005', microarea: 'Engenharia de Software', macroarea: 'Desenvolvimento', element: 'Requisitos - Compreensão', difficulty: 'médio',
    statement: 'A técnica de elicitação de requisitos que utiliza observação direta dos usuários em seu ambiente de trabalho para entender como eles realmente utilizam o sistema é chamada de:\n\nA) Entrevista estruturada\nB) Prototipagem\nC) Observação participativa (etnografia)\nD) Análise de dokumentação existente\nE) Questionário fechado',
    alternatives: [{ letter: 'A', text: 'Entrevista estruturada' }, { letter: 'B', text: 'Prototipagem' }, { letter: 'C', text: 'Observação participativa (etnografia)' }, { letter: 'D', text: 'Análise de documentação existente' }, { letter: 'E', text: 'Questionário fechado' }],
    correctAnswer: 'C', explanation: 'A observação participativa (ou etnografia) envolve o analista acompanhando os usuários em seu dia a dia, observando como interagem com o sistema e identificando necessidades que eles mesmos podem não verbalizar. É particularmente útil quando os usuários não conseguem expressar seus requisitos claramente.', source: 'elaborada', triA: 1.5, triB: 0.0, triC: 0.23,
  },
  {
    id: 'EXP-ES-006', microarea: 'Engenharia de Software', macroarea: 'Desenvolvimento', element: 'Ciclo de vida do software - Identificação', difficulty: 'fácil',
    statement: 'No modelo cascata (Waterfall) de ciclo de vida, a fase de manutenção ocorre:\n\nA) Antes do desenvolvimento\nB) Durante o design\nC) Após a entrega e implantação do software\nD) Simultaneamente com os testes\nE) Antes da análise de requisitos',
    alternatives: [{ letter: 'A', text: 'Antes do desenvolvimento' }, { letter: 'B', text: 'Durante o design' }, { letter: 'C', text: 'Após a entrega e implantação do software' }, { letter: 'D', text: 'Simultaneamente com os testes' }, { letter: 'E', text: 'Antes da análise de requisitos' }],
    correctAnswer: 'C', explanation: 'No modelo cascata, as fases são sequenciais: requisitos → design → implementação → testes → implantação → manutenção. A manutenção ocorre após a entrega, incluindo correção de bugs, melhorias e adaptações.', source: 'elaborada', triA: 1.1, triB: -1.2, triC: 0.28,
  },
  {
    id: 'EXP-ES-007', microarea: 'Engenharia de Software', macroarea: 'Desenvolvimento', element: 'Qualidade de software - Compreensão', difficulty: 'médio',
    statement: 'A métrica de software "cobertura de testes" (test coverage) mede:\n\nA) O número total de testes executados\nB) A porcentagem de linhas de código executadas pelos testes automatizados\nC) O tempo médio de execução dos testes\nD) O número de bugs encontrados por teste\nE) A satisfação do usuário com os testes',
    alternatives: [{ letter: 'A', text: 'O número total de testes executados' }, { letter: 'B', text: 'A porcentagem de linhas de código executadas pelos testes automatizados' }, { letter: 'C', text: 'O tempo médio de execução dos testes' }, { letter: 'D', text: 'O número de bugs encontrados por teste' }, { letter: 'E', text: 'A satisfação do usuário com os testes' }],
    correctAnswer: 'B', explanation: 'Cobertura de testes mede a porcentagem do código-fonte que é executada pelos testes. 100% de cobertura significa que todas as linhas foram executadas, mas não garante que todas as funcionalidades foram testadas corretamente (qualidade vs. quantidade).', source: 'elaborada', triA: 1.4, triB: -0.2, triC: 0.24,
  },
  {
    id: 'EXP-ES-008', microarea: 'Engenharia de Software', macroarea: 'Desenvolvimento', element: 'Modelagem UML - Aplicação', difficulty: 'difícil',
    statement: 'Em um diagrama de casos de uso UML, a relação «include» entre dois casos de uso indica que:\n\nA) O caso de uso base é uma variação opcional do incluído\nB) O caso de uso incluído é obrigatório e sempre executado como parte do base\nC) O caso de uso base herda características do incluído\nD) Ambos os casos de uso são executados simultaneamente\nE) O caso incluído substitui o base em determinadas condições',
    alternatives: [{ letter: 'A', text: 'O caso de uso base é uma variação opcional do incluído' }, { letter: 'B', text: 'O caso de uso incluído é obrigatório e sempre executado como parte do base' }, { letter: 'C', text: 'O caso de uso base herda características do incluído' }, { letter: 'D', text: 'Ambos os casos de uso são executados simultaneamente' }, { letter: 'E', text: 'O caso incluído substitui o base em determinadas condições' }],
    correctAnswer: 'B', explanation: '«include» indica que o comportamento do caso incluído é obrigatoriamente inserido no fluxo do caso base (ex: "Autenticar" sempre incluído em "Realizar Compra"). «extend» é para comportamentos opcionais/condicionais.', source: 'elaborada', triA: 2.0, triB: 0.5, triC: 0.16,
  },

  // ===================== SISTEMAS OPERACIONAIS (5) =====================
  {
    id: 'EXP-SO-001', microarea: 'Sistemas Operacionais', macroarea: 'Desenvolvimento', element: 'Escalonamento - Aplicação', difficulty: 'médio',
    statement: 'No escalonamento Round Robin com quantum de 4 unidades de tempo, qual é a ordem de execução para os processos P1(10), P2(4), P3(6) (valores entre parênteses = tempo de burst)?\n\nA) P1(10) → P2(4) → P3(6)\nB) P1(4) → P2(4) → P3(4) → P1(4) → P3(2) → P1(2)\nC) P1(4) → P2(4) → P1(4) → P3(4) → P1(2) → P3(2)\nD) P1(4) → P2(4) → P3(4) → P1(4) → P3(2)\nE) P1(10) → P2(4) → P3(6) (sem preempção)',
    alternatives: [{ letter: 'A', text: 'P1(10) → P2(4) → P3(6)' }, { letter: 'B', text: 'P1(4) → P2(4) → P3(4) → P1(4) → P3(2) → P1(2)' }, { letter: 'C', text: 'P1(4) → P2(4) → P1(4) → P3(4) → P1(2) → P3(2)' }, { letter: 'D', text: 'P1(4) → P2(4) → P3(4) → P1(4) → P3(2)' }, { letter: 'E', text: 'P1(10) → P2(4) → P3(6) (sem preempção)' }],
    correctAnswer: 'C', explanation: 'Round Robin executa cada processo por 4 unidades e volta ao início da fila: P1(4,resta6), P2(4,resta0→termina), P1(4,resta2), P3(4,resta2), P1(2,termina), P3(2,termina). P2 termina no primeiro round com exatamente 4 unidades.', source: 'elaborada', triA: 1.9, triB: 0.3, triC: 0.18,
  },
  {
    id: 'EXP-SO-002', microarea: 'Sistemas Operacionais', macroarea: 'Desenvolvimento', element: 'Deadlock - Compreensão', difficulty: 'médio',
    statement: 'Para que ocorra um deadlock, quais quatro condições devem ser satisfeitas simultaneamente?\n\nA) Preempção, exclusão mútua, espera circular, retenção e espera\nB) Exclusão mútua, retenção e espera, não-preempção, espera circular\nC) Compartilhamento, preempção, espera finita, retenção e espera\nD) Starvation, exclusão mútua, preempção, espera circular\nE) Prioridade, preempção, espera circular, não-preempção',
    alternatives: [{ letter: 'A', text: 'Preempção, exclusão mútua, espera circular, retenção e espera' }, { letter: 'B', text: 'Exclusão mútua, retenção e espera, não-preempção, espera circular' }, { letter: 'C', text: 'Compartilhamento, preempção, espera finita, retenção e espera' }, { letter: 'D', text: 'Starvation, exclusão mútua, preempção, espera circular' }, { letter: 'E', text: 'Prioridade, preempção, espera circular, não-preempção' }],
    correctAnswer: 'B', explanation: 'As 4 condições necessárias para deadlock são: (1) Exclusão mútua — recursos não compartilháveis, (2) Retenção e espera — processo segura recursos enquanto espera outros, (3) Não-preempção — recursos não podem ser tomados à força, (4) Espera circular — ciclo de processos cada um esperando o próximo.', source: 'elaborada', triA: 1.7, triB: 0.2, triC: 0.20,
  },
  {
    id: 'EXP-SO-003', microarea: 'Sistemas Operacionais', macroarea: 'Desenvolvimento', element: 'Gerenciamento de memória - Compreensão', difficulty: 'médio',
    statement: 'O conceito de memória virtual permite que um processo acesse mais memória do que fisicamente disponível. Isso é possível porque:\n\nA) Os dados são comprimidos automaticamente pelo processador\nB) Partes do processo são transferidas entre a memória RAM e o disco (swap), dando a ilusão de memória contínua\nC) O processador possui memória cache suficiente para todos os processos\nD) Cada processo tem acesso exclusivo à memória física\nE) O sistema operacional elimina processos que usam muita memória',
    alternatives: [{ letter: 'A', text: 'Os dados são comprimidos automaticamente pelo processador' }, { letter: 'B', text: 'Partes do processo são transferidas entre a memória RAM e o disco (swap), dando a ilusão de memória contínua' }, { letter: 'C', text: 'O processador possui memória cache suficiente para todos os processos' }, { letter: 'D', text: 'Cada processo tem acesso exclusivo à memória física' }, { letter: 'E', text: 'O sistema operacional elimina processos que usam muita memória' }],
    correctAnswer: 'B', explanation: 'Memória virtual usa paginação para mapear endereços virtuais para físicos. Páginas não utilizadas vão para o disco (swap); quando acessadas, voltam para a RAM (page fault). Isso permite que a soma da memória virtual de todos os processos exceda a RAM física.', source: 'elaborada', triA: 1.5, triB: -0.1, triC: 0.23,
  },
  {
    id: 'EXP-SO-004', microarea: 'Sistemas Operacionais', macroarea: 'Desenvolvimento', element: 'Processos e threads - Compreensão', difficulty: 'fácil',
    statement: 'Qual é a principal diferença entre um processo e uma thread (linha de execução)?\n\nA) Processos são mais leves que threads\nB) Threads de um mesmo processo compartilham o mesmo espaço de memória, enquanto processos têm espaços independentes\nC) Processos não podem se comunicar entre si\nD) Threads não podem executar concorrentemente\nE) Não há diferença significativa entre eles',
    alternatives: [{ letter: 'A', text: 'Processos são mais leves que threads' }, { letter: 'B', text: 'Threads de um mesmo processo compartilham o mesmo espaço de memória, enquanto processos têm espaços independentes' }, { letter: 'C', text: 'Processos não podem se comunicar entre si' }, { letter: 'D', text: 'Threads não podem executar concorrentemente' }, { letter: 'E', text: 'Não há diferença significativa entre eles' }],
    correctAnswer: 'B', explanation: 'Threads são "linhas de execução" dentro de um processo e compartilham código, dados e recursos (arquivos abertos). Processos são independentes, cada um com seu próprio espaço de endereçamento. Threads são mais leves para criar e destruir.', source: 'elaborada', triA: 1.2, triB: -0.8, triC: 0.28,
  },
  {
    id: 'EXP-SO-005', microarea: 'Sistemas Operacionais', macroarea: 'Desenvolvimento', element: 'Sincronização - Aplicação', difficulty: 'difícil',
    statement: 'O problema dos produtores-consumidores pode ser resolvido eficientemente usando semáforos. Para uma situação com N posições no buffer, quais semáforos são necessários?\n\nA) Um semáforo mutex para acesso exclusivo ao buffer\nB) Dois semáforos: um para espaços vazios (inicializado em N) e outro para itens disponíveis (inicializado em 0)\nC) Três semáforos: mutex, empty e full\nD) Apenas um semáforo inicializado em N\nE) N semáforos, um para cada posição do buffer',
    alternatives: [{ letter: 'A', text: 'Um semáforo mutex para acesso exclusivo ao buffer' }, { letter: 'B', text: 'Dois semáforos: um para espaços vazios (inicializado em N) e outro para itens disponíveis (inicializado em 0)' }, { letter: 'C', text: 'Três semáforos: mutex, empty e full' }, { letter: 'D', text: 'Apenas um semáforo inicializado em N' }, { letter: 'E', text: 'N semáforos, um para cada posição do buffer' }],
    correctAnswer: 'C', explanation: 'A solução clássica usa três semáforos: mutex (inicializado em 1) para acesso exclusivo ao buffer, empty (inicializado em N) para contar espaços livres, e full (inicializado em 0) para contar itens disponíveis. O produtor faz wait(empty), wait(mutex), produz, signal(mutex), signal(full).', source: 'elaborada', triA: 2.1, triB: 0.8, triC: 0.14,
  },

  // ===================== REDES (8) =====================
  {
    id: 'EXP-RED-001', microarea: 'Redes de Computadores', macroarea: 'Desenvolvimento', element: 'Modelo OSI e TCP/IP - Compreensão', difficulty: 'fácil',
    statement: 'No modelo OSI, qual camada é responsável por endereçamento lógico (IP) e roteamento de pacotes entre redes diferentes?\n\nA) Camada Física\nB) Camada de Enlace\nC) Camada de Rede\nD) Camada de Transporte\nE) Camada de Aplicação',
    alternatives: [{ letter: 'A', text: 'Camada Física' }, { letter: 'B', text: 'Camada de Enlace' }, { letter: 'C', text: 'Camada de Rede' }, { letter: 'D', text: 'Camada de Transporte' }, { letter: 'E', text: 'Camada de Aplicação' }],
    correctAnswer: 'C', explanation: 'A camada de Rede (Camada 3) é responsável pelo endereçamento lógico (endereços IP) e roteamento entre redes. O principal protocolo desta camada é o IP (Internet Protocol). Enlace cuida de endereçamento físico (MAC), Transporte de portas.', source: 'elaborada', triA: 1.1, triB: -1.3, triC: 0.30,
  },
  {
    id: 'EXP-RED-002', microarea: 'Redes de Computadores', macroarea: 'Desenvolvimento', element: 'Protocolos de transporte - Compreensão', difficulty: 'médio',
    statement: 'Uma aplicação de videoconferência requer transmissão em tempo real, aceitando algumas perdas de pacotes mas não tolerando atrasos. Qual protocolo de transporte é mais adequado?\n\nA) TCP — garante entrega e ordenação de pacotes\nB) UDP — é mais rápido, sem garantia de entrega, adequado para streaming\nC) ICMP — usado para diagnósticos de rede\nD) FTP — otimizado para transferência de arquivos\nE) SMTP — otimizado para envio de emails',
    alternatives: [{ letter: 'A', text: 'TCP — garante entrega e ordenação de pacotes' }, { letter: 'B', text: 'UDP — é mais rápido, sem garantia de entrega, adequado para streaming' }, { letter: 'C', text: 'ICMP — usado para diagnósticos de rede' }, { letter: 'D', text: 'FTP — otimizado para transferência de arquivos' }, { letter: 'E', text: 'SMTP — otimizado para envio de emails' }],
    correctAnswer: 'B', explanation: 'UDP não estabelece conexão nem garante entrega, sendo mais rápido que TCP. Para streaming em tempo real, é preferível perder alguns quadros (quadros antigos são inúteis) a esperar retransmissões que causariam atraso inaceitável.', source: 'elaborada', triA: 1.5, triB: -0.3, triC: 0.25,
  },
  {
    id: 'EXP-RED-003', microarea: 'Redes de Computadores', macroarea: 'Desenvolvimento', element: 'Endereçamento IP - Aplicação', difficulty: 'médio',
    statement: 'Dada a máscara de sub-rede 255.255.255.192 (/26), quantos endereços hosts válidos existem em cada sub-rede?\n\nA) 30\nB) 62\nC) 64\nD) 126\nE) 254',
    alternatives: [{ letter: 'A', text: '30' }, { letter: 'B', text: '62' }, { letter: 'C', text: '64' }, { letter: 'D', text: '126' }, { letter: 'E', text: '254' }],
    correctAnswer: 'B', explanation: 'Máscara /26 significa 26 bits para rede e 6 bits para host. Total de endereços por sub-rede = 2⁶ = 64. Subtraindo endereço de rede e broadcast: 64 - 2 = 62 hosts válidos.', source: 'elaborada', triA: 1.8, triB: 0.2, triC: 0.20,
  },
  {
    id: 'EXP-RED-004', microarea: 'Redes de Computadores', macroarea: 'Desenvolvimento', element: 'Protocolos de aplicação - Compreensão', difficulty: 'fácil',
    statement: 'Quando você digita www.google.com no navegador, qual é o primeiro passo do processo de resolução de nome?\n\nA) O navegador envia uma requisição HTTP diretamente ao servidor web do Google\nB) O navegador consulta o servidor DNS para converter o nome de domínio em endereço IP\nC) O navegador estabelece uma conexão TCP com o endereço www.google.com\nD) O navegador envia um pacote ARP para descobrir o endereço MAC do Google\nE) O navegador consulta o servidor DHCP para obter o endereço IP',
    alternatives: [{ letter: 'A', text: 'O navegador envia uma requisição HTTP diretamente ao servidor web do Google' }, { letter: 'B', text: 'O navegador consulta o servidor DNS para converter o nome de domínio em endereço IP' }, { letter: 'C', text: 'O navegador estabelece uma conexão TCP com o endereço www.google.com' }, { letter: 'D', text: 'O navegador envia um pacote ARP para descobrir o endereço MAC do Google' }, { letter: 'E', text: 'O navegador consulta o servidor DHCP para obter o endereço IP' }],
    correctAnswer: 'B', explanation: 'A resolução DNS é o primeiro passo — converter o nome de domínio (www.google.com) em um endereço IP. O browser consulta o DNS resolver configurado, que pode verificar cache local, consultar DNS hierárquico (.com → google → www).', source: 'elaborada', triA: 1.2, triB: -1.0, triC: 0.28,
  },
  {
    id: 'EXP-RED-005', microarea: 'Redes de Computadores', macroarea: 'Desenvolvimento', element: 'Firewalls - Compreensão', difficulty: 'médio',
    statement: 'Um firewall do tipo "stateful inspection" é diferente de um "packet filter" porque:\n\nA) Examina apenas o endereço IP de origem e destino\nB) Mantém o estado das conexões e pode tomar decisões baseadas no contexto da comunicação\nC) Bloqueia todo o tráfego de entrada por padrão\nD) Funciona apenas na camada de aplicação\nE) Não requer configuração para funcionar',
    alternatives: [{ letter: 'A', text: 'Examina apenas o endereço IP de origem e destino' }, { letter: 'B', text: 'Mantém o estado das conexões e pode tomar decisões baseadas no contexto da comunicação' }, { letter: 'C', text: 'Bloqueia todo o tráfego de entrada por padrão' }, { letter: 'D', text: 'Funciona apenas na camada de aplicação' }, { letter: 'E', text: 'Não requer configuração para funcionar' }],
    correctAnswer: 'B', explanation: 'Firewalls stateful acompanham o estado das conexões (SYN, ESTABLISHED, FIN), permitindo tomadas de decisão mais inteligentes. Um pacote filter examina cada pacote isoladamente, sem contexto de conexão anterior, o que é mais limitado.', source: 'elaborada', triA: 1.6, triB: 0.1, triC: 0.22,
  },
  {
    id: 'EXP-RED-006', microarea: 'Redes de Computadores', macroarea: 'Desenvolvimento', element: 'Sub-redes - Aplicação', difficulty: 'difícil',
    statement: 'Uma empresa recebeu o bloco de endereços 192.168.1.0/24 e precisa criar 8 sub-redes. Qual será a nova máscara de sub-rede?\n\nA) 255.255.255.0\nB) 255.255.255.128\nC) 255.255.255.192\nD) 255.255.255.224\nE) 255.255.255.240',
    alternatives: [{ letter: 'A', text: '255.255.255.0' }, { letter: 'B', text: '255.255.255.128' }, { letter: 'C', text: '255.255.255.192' }, { letter: 'D', text: '255.255.255.224' }, { letter: 'E', text: '255.255.255.240' }],
    correctAnswer: 'D', explanation: 'Para 8 sub-redes, precisa-se de 3 bits (2³ = 8). A nova máscara é /24 + 3 = /27 = 255.255.255.224. Cada sub-rede terá 2⁵ - 2 = 30 hosts válidos.', source: 'elaborada', triA: 2.0, triB: 0.6, triC: 0.16,
  },
  {
    id: 'EXP-RED-007', microarea: 'Redes de Computadores', macroarea: 'Desenvolvimento', element: 'Roteamento - Compreensão', difficulty: 'médio',
    statement: 'Qual protocolo de roteamento é classificado como "distance-vector" e usa o número de saltos (hops) como métrica?\n\nA) OSPF\nB) BGP\nC) RIP\nD) IS-IS\nE) EIGRP',
    alternatives: [{ letter: 'A', text: 'OSPF' }, { letter: 'B', text: 'BGP' }, { letter: 'C', text: 'RIP' }, { letter: 'D', text: 'IS-IS' }, { letter: 'E', text: 'EIGRP' }],
    correctAnswer: 'C', explanation: 'RIP (Routing Information Protocol) é um protocolo distance-vector que usa hop count como métrica, com limite de 15 saltos. OSPF é link-state, BGP é path-vector, IS-IS é link-state. RIP é simples mas limitado para redes grandes.', source: 'elaborada', triA: 1.5, triB: -0.2, triC: 0.24,
  },
  {
    id: 'EXP-RED-008', microarea: 'Redes de Computadores', macroarea: 'Desenvolvimento', element: 'Switching e VLANs - Compreensão', difficulty: 'médio',
    statement: 'Uma VLAN (Virtual LAN) segmenta uma rede física em redes lógicas. Qual é a principal vantagem?\n\nA) Aumenta a velocidade física dos links\nB) Isolamento de tráfego, segurança e redução de domínios de broadcast\nC) Elimina a necessidade de roteadores\nD) Aumenta o número máximo de dispositivos conectados\nE) Reduz o consumo de energia dos switches',
    alternatives: [{ letter: 'A', text: 'Aumenta a velocidade física dos links' }, { letter: 'B', text: 'Isolamento de tráfego, segurança e redução de domínios de broadcast' }, { letter: 'C', text: 'Elimina a necessidade de roteadores' }, { letter: 'D', text: 'Aumenta o número máximo de dispositivos conectados' }, { letter: 'E', text: 'Reduz o consumo de energia dos switches' }],
    correctAnswer: 'B', explanation: 'VLANs criam segmentos lógicos independentes, isolando o tráfego entre eles. Cada VLAN é um domínio de broadcast separado, melhorando segurança e desempenho. Dispositivos de VLANs diferentes precisam de um roteador para comunicar-se (inter-VLAN routing).', source: 'elaborada', triA: 1.6, triB: 0.0, triC: 0.22,
  },

  // ===================== SISTEMAS DISTRIBUÍDOS (3) =====================
  {
    id: 'EXP-SD-001', microarea: 'Sistemas Distribuídos', macroarea: 'Desenvolvimento', element: 'Teorema CAP - Compreensão', difficulty: 'médio',
    statement: 'O teorema CAP afirma que um sistema distribuído pode garantir simultaneamente no máximo duas de três propriedades: Consistência (C), Disponibilidade (A) e Tolerância a Partição (P). Um banco de dados distribuído que prioriza disponibilidade e tolerância a partições (AP) sacrifica:\n\nA) A tolerância a partições\nB) A disponibilidade\nC) A consistência — leituras podem retornar dados desatualizados\nD) O particionamento dos dados\nE) A capacidade de armazenamento',
    alternatives: [{ letter: 'A', text: 'A tolerância a partições' }, { letter: 'B', text: 'A disponibilidade' }, { letter: 'C', text: 'A consistência — leituras podem retornar dados desatualizados' }, { letter: 'D', text: 'O particionamento dos dados' }, { letter: 'E', text: 'A capacidade de armazenamento' }],
    correctAnswer: 'C', explanation: 'Sistemas AP (como Cassandra em configuração padrão) priorizam disponibilidade e tolerância a falhas de rede. O preço é a consistência eventual: leituras podem retornar dados antigos até que as réplicas se sincronizem. Exemplos: DNS, sistemas de cache distribuído.', source: 'elaborada', triA: 1.7, triB: 0.2, triC: 0.20,
  },
  {
    id: 'EXP-SD-002', microarea: 'Sistemas Distribuídos', macroarea: 'Desenvolvimento', element: 'Microserviços - Identificação', difficulty: 'médio',
    statement: 'Qual NÃO é uma vantagem da arquitetura de microserviços em relação à arquitetura monolítica?\n\nA) Cada serviço pode ser desenvolvido, implantado e escalado independentemente\nB) Melhor isolamento de falhas — a queda de um serviço não derruba os demais\nC) Maior simplicidade na comunicação entre módulos, sem necessidade de APIs\nD) Permite o uso de tecnologias diferentes para cada serviço\nE) Facilita a adoção de práticas de CI/CD por equipe',
    alternatives: [{ letter: 'A', text: 'Cada serviço pode ser desenvolvido, implantado e escalado independentemente' }, { letter: 'B', text: 'Melhor isolamento de falhas — a queda de um serviço não derruba os demais' }, { letter: 'C', text: 'Maior simplicidade na comunicação entre módulos, sem necessidade de APIs' }, { letter: 'D', text: 'Permite o uso de tecnologias diferentes para cada serviço' }, { letter: 'E', text: 'Facilita a adoção de práticas de CI/CD por equipe' }],
    correctAnswer: 'C', explanation: 'Microserviços NÃO simplificam a comunicação — pelo contrário, introduzem complexidade na comunicação entre serviços (APIs REST/gRPC, message queues, service discovery). No monolito, a comunicação é via chamadas de função local, muito mais simples.', source: 'elaborada', triA: 1.5, triB: 0.0, triC: 0.23,
  },
  {
    id: 'EXP-SD-003', microarea: 'Sistemas Distribuídos', macroarea: 'Desenvolvimento', element: 'Balanceamento de carga - Compreensão', difficulty: 'fácil',
    statement: 'Um load balancer distribui requisições entre múltiplos servidores. Qual algoritmo de balanceamento escolhe o servidor com menos conexões ativas?\n\nA) Round Robin\nB) Least Connections\nC) IP Hash\nD) Random\nE) Weighted Round Robin',
    alternatives: [{ letter: 'A', text: 'Round Robin' }, { letter: 'B', text: 'Least Connections' }, { letter: 'C', text: 'IP Hash' }, { letter: 'D', text: 'Random' }, { letter: 'E', text: 'Weighted Round Robin' }],
    correctAnswer: 'B', explanation: 'Least Connections direciona cada nova requisição para o servidor com menos conexões ativas. É ideal quando os servidores têm capacidades diferentes ou as requisições variam em tempo de processamento, evitando sobrecarga de um servidor mais lento.', source: 'elaborada', triA: 1.2, triB: -0.6, triC: 0.26,
  },

  // ===================== CRIPTOGRAFIA (5) =====================
  {
    id: 'EXP-CRI-001', microarea: 'Criptografia', macroarea: 'Segurança/IA', element: 'Criptografia simétrica vs assimétrica - Compreensão', difficulty: 'médio',
    statement: 'Qual é a principal diferença entre criptografia simétrica e assimétrica?\n\nA) Simétrica usa uma chave; assimétrica usa duas chaves (pública e privada)\nB) Simétrica é mais lenta que assimétrica\nC) Assimétrica não oferece confidencialidade\nD) Simétrica requer certificados digitais\nE) Não há diferença prática entre elas',
    alternatives: [{ letter: 'A', text: 'Simétrica usa uma chave; assimétrica usa duas chaves (pública e privada)' }, { letter: 'B', text: 'Simétrica é mais lenta que assimétrica' }, { letter: 'C', text: 'Assimétrica não oferece confidencialidade' }, { letter: 'D', text: 'Simétrica requer certificados digitais' }, { letter: 'E', text: 'Não há diferença prática entre elas' }],
    correctAnswer: 'A', explanation: 'Criptografia simétrica usa a mesma chave para cifrar e decifrar (ex: AES). Assimétrica usa um par de chaves: a pública cifra e a privada decifra (ex: RSA). Assimétrica é mais lenta (~1000x) mas resolve o problema de distribuição de chaves. Na prática, combina-se ambas: assimétrica para trocar uma chave de sessão, simétrica para os dados.', source: 'elaborada', triA: 1.5, triB: -0.3, triC: 0.24,
  },
  {
    id: 'EXP-CRI-002', microarea: 'Criptografia', macroarea: 'Segurança/IA', element: 'Funções hash - Aplicação', difficulty: 'fácil',
    statement: 'Em um sistema de senhas, os hashes SHA-256 são usados para armazenar senhas porque:\n\nA) SHA-256 é reversível — permite recuperar a senha original\nB) SHA-256 é uma função de mão única: é fácil calcular o hash mas computacionalmente inviável recuperar a senha\nC) SHA-256 é mais rápido que AES\nD) SHA-256 usa criptografia assimétrica\nE) SHA-256 não requer chave secreta',
    alternatives: [{ letter: 'A', text: 'SHA-256 é reversível — permite recuperar a senha original' }, { letter: 'B', text: 'SHA-256 é uma função de mão única: é fácil calcular o hash mas computacionalmente inviável recuperar a senha' }, { letter: 'C', text: 'SHA-256 é mais rápido que AES' }, { letter: 'D', text: 'SHA-256 usa criptografia assimétrica' }, { letter: 'E', text: 'SHA-256 não requer chave secreta' }],
    correctAnswer: 'B', explanation: 'Funções hash são de mão única (one-way): dado um input, produzem um output fixo (256 bits para SHA-256), mas dado o output, é inviável encontrar o input. Armazenar o hash (não a senha) protege contra vazamentos de banco de dados.', source: 'elaborada', triA: 1.3, triB: -0.7, triC: 0.26,
  },
  {
    id: 'EXP-CRI-003', microarea: 'Criptografia', macroarea: 'Segurança/IA', element: 'SSL/TLS - Compreensão', difficulty: 'médio',
    statement: 'Durante o handshake TLS 1.2, qual é a principal função do certificado digital do servidor?\n\nA) Armazenar a chave de sessão criptografada\nB) Autenticar a identidade do servidor e fornecer sua chave pública ao cliente\nC) Criptografar toda a comunicação subsequente\nD) Verificar a senha do usuário\nE) Armazenar o histórico de navegação',
    alternatives: [{ letter: 'A', text: 'Armazenar a chave de sessão criptografada' }, { letter: 'B', text: 'Autenticar a identidade do servidor e fornecer sua chave pública ao cliente' }, { letter: 'C', text: 'Criptografar toda a comunicação subsequente' }, { letter: 'D', text: 'Verificar a senha do usuário' }, { letter: 'E', text: 'Armazenar o histórico de navegação' }],
    correctAnswer: 'B', explanation: 'O certificado digital contém a chave pública do servidor e é assinado por uma Autoridade Certificadora (CA). O cliente verifica a cadeia de certificados até uma CA raiz confiável, garantindo que está se comunicando com o servidor legítimo (autenticação). Após o handshake, a comunicação é cifrada com criptografia simétrica usando uma chave de sessão negociada.', source: 'elaborada', triA: 1.7, triB: 0.1, triC: 0.22,
  },
  {
    id: 'EXP-CRI-004', microarea: 'Criptografia', macroarea: 'Segurança/IA', element: 'Assinatura digital - Aplicação', difficulty: 'médio',
    statement: 'Uma assinatura digital garante:\n\nA) Confidencialidade da mensagem — apenas o destinatário pode ler\nB) Autenticidade do remetente e integridade da mensagem (não foi alterada)\nC) Compressão dos dados transmitidos\nD) Aumento da velocidade de transmissão\nE) Anonimato total do remetente',
    alternatives: [{ letter: 'A', text: 'Confidencialidade da mensagem — apenas o destinatário pode ler' }, { letter: 'B', text: 'Autenticidade do remetente e integridade da mensagem (não foi alterada)' }, { letter: 'C', text: 'Compressão dos dados transmitidos' }, { letter: 'D', text: 'Aumento da velocidade de transmissão' }, { letter: 'E', text: 'Anonimato total do remetente' }],
    correctAnswer: 'B', explanation: 'A assinatura digital é criada com a chave PRIVADA do remetente e verificada com sua chave PÚBLICA. Isso garante: (1) autenticidade — só quem tem a chave privada pode assinar, (2) integridade — qualquer alteração invalida a assinatura, (3) não-repúdio — o remetente não pode negar que assinou. Não garante confidencialidade.', source: 'elaborada', triA: 1.6, triB: 0.0, triC: 0.23,
  },
  {
    id: 'EXP-CRI-005', microarea: 'Criptografia', macroarea: 'Segurança/IA', element: 'Segurança web - Identificação', difficulty: 'médio',
    statement: 'Um ataque de "Man-in-the-Middle" (MITM) permite que um atacante:\n\nA) Interceptar e possivelmente alterar a comunicação entre duas partes sem que elas percebam\nB) Destruir os dados armazenados no servidor\nC) Desligar o servidor web remotamente\nD) Acessar o banco de dados diretamente\nE) Criar uma cópia exata do servidor web',
    alternatives: [{ letter: 'A', text: 'Interceptar e possivelmente alterar a comunicação entre duas partes sem que elas percebam' }, { letter: 'B', text: 'Destruir os dados armazenados no servidor' }, { letter: 'C', text: 'Desligar o servidor web remotamente' }, { letter: 'D', text: 'Acessar o banco de dados diretamente' }, { letter: 'E', text: 'Criar uma cópia exata do servidor web' }],
    correctAnswer: 'A', explanation: 'No MITM, o atacante se posiciona entre cliente e servidor, interceptando (e possivelmente modificando) a comunicação. É prevenido pelo uso de HTTPS/TLS, que autentica o servidor e cifra a comunicação, impossibilitando a interceptação.', source: 'elaborada', triA: 1.5, triB: -0.1, triC: 0.24,
  },

  // ===================== INTELIGÊNCIA ARTIFICIAL (5) =====================
  {
    id: 'EXP-IA-001', microarea: 'Inteligência Artificial', macroarea: 'Segurança/IA', element: 'Aprendizado de máquina - Compreensão', difficulty: 'médio',
    statement: 'Em aprendizado de máquina, a diferença fundamental entre aprendizado supervisionado e não supervisionado é:\n\nA) Supervisionado é mais rápido que não supervisionado\nB) Supervisionado usa dados rotulados (com saída esperada); não supervisionado descobre padrões em dados sem rótulos\nC) Não supervisionado só funciona com dados numéricos\nD) Supervisionado não requer conjunto de treinamento\nE) Não há diferença prática entre eles',
    alternatives: [{ letter: 'A', text: 'Supervisionado é mais rápido que não supervisionado' }, { letter: 'B', text: 'Supervisionado usa dados rotulados (com saída esperada); não supervisionado descobre padrões em dados sem rótulos' }, { letter: 'C', text: 'Não supervisionado só funciona com dados numéricos' }, { letter: 'D', text: 'Supervisionado não requer conjunto de treinamento' }, { letter: 'E', text: 'Não há diferença prática entre eles' }],
    correctAnswer: 'B', explanation: 'No aprendizado supervisionado, os dados de treino incluem pares (input, output) — ex: fotos rotuladas como "gato" ou "cachorro". No não supervisionado, o modelo recebe apenas inputs e deve descobrir estrutura/padrões — ex: agrupar clientes por comportamento (clustering).', source: 'elaborada', triA: 1.4, triB: -0.2, triC: 0.24,
  },
  {
    id: 'EXP-IA-002', microarea: 'Inteligência Artificial', macroarea: 'Segurança/IA', element: 'Redes neurais - Compreensão', difficulty: 'difícil',
    statement: 'O processo de backpropagation em redes neurais é usado para:\n\nA) Propagar dados da entrada para a saída (forward pass)\nB) Calcular o gradiente do erro em relação a cada peso e ajustar os pesos para minimizar o erro\nC) Inicializar os pesos da rede aleatoriamente\nD) Selecionar a arquitetura ideal da rede\nE) Normalizar os dados de entrada',
    alternatives: [{ letter: 'A', text: 'Propagar dados da entrada para a saída (forward pass)' }, { letter: 'B', text: 'Calcular o gradiente do erro em relação a cada peso e ajustar os pesos para minimizar o erro' }, { letter: 'C', text: 'Inicializar os pesos da rede aleatoriamente' }, { letter: 'D', text: 'Selecionar a arquitetura ideal da rede' }, { letter: 'E', text: 'Normalizar os dados de entrada' }],
    correctAnswer: 'B', explanation: 'Backpropagation calcula ∂E/∂w (derivada parcial do erro em relação a cada peso) usando a regra da cadeia, propagando o erro de trás para frente. Os pesos são então ajustados na direção que reduz o erro (gradiente descendente). Este é o algoritmo central de treinamento de redes neurais.', source: 'elaborada', triA: 2.1, triB: 0.7, triC: 0.15,
  },
  {
    id: 'EXP-IA-003', microarea: 'Inteligência Artificial', macroarea: 'Segurança/IA', element: 'Árvores de decisão - Aplicação', difficulty: 'fácil',
    statement: 'Em uma árvore de decisão para classificar emails como "spam" ou "não spam", os nós internos representam:\n\nA) As classificações finais (spam/não spam)\nB) Testes em atributos (ex: "contém palavra \'grátis\'?")\nC) O número total de exemplos de treinamento\nD) A taxa de acerto do modelo\nE) Os pesos sinápticos da rede',
    alternatives: [{ letter: 'A', text: 'As classificações finais (spam/não spam)' }, { letter: 'B', text: 'Testes em atributos (ex: "contém palavra \'grátis\'?")' }, { letter: 'C', text: 'O número total de exemplos de treinamento' }, { letter: 'D', text: 'A taxa de acerto do modelo' }, { letter: 'E', text: 'Os pesos sinápticos da rede' }],
    correctAnswer: 'B', explanation: 'Em uma árvore de decisão, cada nó interno testa um atributo (ex: "contém palavra \'grátis\'?"), cada ramo é uma resposta possível (sim/não), e as folhas são as classificações finais. O modelo é construído selecionando os atributos que melhor separam as classes.', source: 'elaborada', triA: 1.1, triB: -1.0, triC: 0.28,
  },
  {
    id: 'EXP-IA-004', microarea: 'Inteligência Artificial', macroarea: 'Segurança/IA', element: 'NLP - Compreensão', difficulty: 'médio',
    statement: 'No processamento de linguagem natural (NLP), a técnica de "word embedding" (como Word2Vec) transforma palavras em:\n\nA) Números aleatórios para criptografia\nB) Vetores numéricos densos que capturam relações semânticas entre palavras\nC) Códigos Morse\nD) Árvores sintáticas\nE) Regras gramaticais formais',
    alternatives: [{ letter: 'A', text: 'Números aleatórios para criptografia' }, { letter: 'B', text: 'Vetores numéricos densos que capturam relações semânticas entre palavras' }, { letter: 'C', text: 'Códigos Morse' }, { letter: 'D', text: 'Árvores sintáticas' }, { letter: 'E', text: 'Regras gramaticais formais' }],
    correctAnswer: 'B', explanation: 'Word embeddings mapeiam palavras para vetores de dimensão fixa (ex: 300 dimensões) onde palavras semanticamente similares ficam próximas no espaço vetorial. Por exemplo, vetor("rei") - vetor("homem") + vetor("mulher") ≈ vetor("rainha"), capturando relações semânticas.', source: 'elaborada', triA: 1.7, triB: 0.2, triC: 0.20,
  },
  {
    id: 'EXP-IA-005', microarea: 'Inteligência Artificial', macroarea: 'Segurança/IA', element: 'Ética em IA - Compreensão', difficulty: 'médio',
    statement: 'O conceito de "viés algorítmico" (algorithmic bias) em IA refere-se a:\n\nA) Erros de cálculo matemático nos modelos\nB) Sistemas que produzem resultados discriminatórios por terem sido treinados com dados enviesados\nC) Preferência natural da IA por algoritmos mais simples\nD) Diferença de performance entre linguagens de programação\nE) Tendência de redes neurais a esquecer informações antigas',
    alternatives: [{ letter: 'A', text: 'Erros de cálculo matemático nos modelos' }, { letter: 'B', text: 'Sistemas que produzem resultados discriminatórios por terem sido treinados com dados enviesados' }, { letter: 'C', text: 'Preferência natural da IA por algoritmos mais simples' }, { letter: 'D', text: 'Diferença de performance entre linguagens de programação' }, { letter: 'E', text: 'Tendência de redes neurais a esquecer informações antigas' }],
    correctAnswer: 'B', explanation: 'Viés algorítmico ocorre quando modelos reproduzem ou amplificam preconceitos presentes nos dados de treinamento. Exemplo: um sistema de recrutamento treinado com dados de contratações históricas pode discriminar mulheres se os dados refletem um viés de gênero passado.', source: 'elaborada', triA: 1.5, triB: 0.0, triC: 0.23,
  },

  // ===================== CIÊNCIA DE DADOS (3) =====================
  {
    id: 'EXP-CD-001', microarea: 'Ciência de Dados', macroarea: 'Segurança/IA', element: 'Estatística descritiva - Aplicação', difficulty: 'fácil',
    statement: 'O conjunto de dados {2, 5, 5, 7, 8, 10, 12} tem média 7 e mediana 7. Se substituirmos o valor 12 por 100, o que acontece com a média e a mediana?\n\nA) Ambas aumentam significativamente\nB) A média aumenta significativamente, a mediana aumenta pouco\nC) A mediana aumenta significativamente, a média aumenta pouco\nD) Ambas permanecem iguais\nE) Ambas diminuem',
    alternatives: [{ letter: 'A', text: 'Ambas aumentam significativamente' }, { letter: 'B', text: 'A média aumenta significativamente, a mediana aumenta pouco' }, { letter: 'C', text: 'A mediana aumenta significativamente, a média aumenta pouco' }, { letter: 'D', text: 'Ambas permanecem iguais' }, { letter: 'E', text: 'Ambas diminuem' }],
    correctAnswer: 'B', explanation: 'Nova média = (2+5+5+7+8+10+100)/7 = 137/7 ≈ 19.6 (antes 7). Mediana é o 4º valor ordenado: {2,5,5,7,8,10,100} → mediana = 7 (igual). A média é sensível a outliers (valores extremos), a mediana é resistente. Isso ilustra por que a mediana é melhor para dados com outliers.', source: 'elaborada', triA: 1.2, triB: -0.8, triC: 0.27,
  },
  {
    id: 'EXP-CD-002', microarea: 'Ciência de Dados', macroarea: 'Segurança/IA', element: 'Regressão - Compreensão', difficulty: 'médio',
    statement: 'Uma empresa quer prever o preço de imóveis com base na área (m²). O modelo de regressão linear encontrado é: preço = 5000 + 3500 × área. Para um apartamento de 80m², o preço previsto é:\n\nA) R$ 280.000\nB) R$ 285.000\nC) R$ 350.000\nD) R$ 400.000\nE) R$ 205.000',
    alternatives: [{ letter: 'A', text: 'R$ 280.000' }, { letter: 'B', text: 'R$ 285.000' }, { letter: 'C', text: 'R$ 350.000' }, { letter: 'D', text: 'R$ 400.000' }, { letter: 'E', text: 'R$ 205.000' }],
    correctAnswer: 'B', explanation: 'Preço = 5000 + 3500 × 80 = 5000 + 280.000 = 285.000. O intercepto (5000) é o valor base (terreno mínimo), e o coeficiente (3500) representa o valor por m². Para cada m² adicional, o preço aumenta R$ 3.500.', source: 'elaborada', triA: 1.4, triB: -0.3, triC: 0.25,
  },
  {
    id: 'EXP-CD-003', microarea: 'Ciência de Dados', macroarea: 'Segurança/IA', element: 'Visualização de dados - Identificação', difficulty: 'fácil',
    statement: 'Para visualizar a distribuição de idades de 1000 clientes de uma loja, o tipo de gráfico mais adequado é:\n\nA) Gráfico de pizza\nB) Gráfico de barras (histograma)\nC) Gráfico de linhas\nD) Gráfico de dispersão\nE) Gráfico de área empilhada',
    alternatives: [{ letter: 'A', text: 'Gráfico de pizza' }, { letter: 'B', text: 'Gráfico de barras (histograma)' }, { letter: 'C', text: 'Gráfico de linhas' }, { letter: 'D', text: 'Gráfico de dispersão' }, { letter: 'E', text: 'Gráfico de área empilhada' }],
    correctAnswer: 'B', explanation: 'O histograma (gráfico de barras para variável contínua) é ideal para mostrar a distribuição de uma variável numérica (idade), agrupando dados em faixas (intervalos). Pizza serve para composição, linhas para tendências temporais, dispersão para correlação entre duas variáveis.', source: 'elaborada', triA: 1.1, triB: -1.0, triC: 0.30,
  },

  // ===================== ÉTICA PROFISSIONAL (3) =====================
  {
    id: 'EXP-ETI-001', microarea: 'Ética Profissional', macroarea: 'Segurança/IA', element: 'LGPD - Compreensão', difficulty: 'médio',
    statement: 'A LGPD (Lei Geral de Proteção de Dados) estabelece que o tratamento de dados pessoais deve ser baseado em uma de suas bases legais. Qual das alternativas NÃO é uma base legal prevista na LGPD?\n\nA) Consentimento do titular\nB) Execução de contrato\nC) Obtenção de lucro pela empresa\nD) Cumprimento de obrigação legal\nE) Legítimo interesse do controlador',
    alternatives: [{ letter: 'A', text: 'Consentimento do titular' }, { letter: 'B', text: 'Execução de contrato' }, { letter: 'C', text: 'Obtenção de lucro pela empresa' }, { letter: 'D', text: 'Cumprimento de obrigação legal' }, { letter: 'E', text: 'Legítimo interesse do controlador' }],
    correctAnswer: 'C', explanation: 'A LGPD prevê 10 bases legais (art. 7º), incluindo: consentimento, obrigação legal, execução de contrato, exercício regular de direitos, proteção da vida, interesse legítimo, saúde, tutela, pesquisa e exercício regular do poder público. "Obtenção de lucro" NÃO é uma base legal por si só.', source: 'elaborada', triA: 1.6, triB: 0.1, triC: 0.22,
  },
  {
    id: 'EXP-ETI-002', microarea: 'Ética Profissional', macroarea: 'Segurança/IA', element: 'Privacidade - Compreensão', difficulty: 'médio',
    statement: 'O princípio de "Privacy by Design" (Privacidade desde o Design) estabelece que:\n\nA) A privacidade deve ser considerada apenas após o lançamento do produto\nB) A privacidade deve ser incorporada no design do sistema desde o início do projeto\nC) A privacidade é responsabilidade exclusiva do usuário\nD) Dados pessoais devem ser sempre armazenados em texto claro\nE) O acesso a dados pessoais não precisa ser controlado',
    alternatives: [{ letter: 'A', text: 'A privacidade deve ser considerada apenas após o lançamento do produto' }, { letter: 'B', text: 'A privacidade deve ser incorporada no design do sistema desde o início do projeto' }, { letter: 'C', text: 'A privacidade é responsabilidade exclusiva do usuário' }, { letter: 'D', text: 'Dados pessoais devem ser sempre armazenados em texto claro' }, { letter: 'E', text: 'O acesso a dados pessoais não precisa ser controlado' }],
    correctAnswer: 'B', explanation: 'Privacy by Design (proposto por Ann Cavoukian) estabelece 7 princípios fundamentais: proativo não reativo, privacidade como padrão, privacidade embutida no design, funcionalidade completa (soma positivo), segurança pelo ciclo de vida, visibilidade/transparência e respeito pela privacidade do usuário.', source: 'elaborada', triA: 1.5, triB: -0.1, triC: 0.23,
  },
  {
    id: 'EXP-ETI-003', microarea: 'Ética Profissional', macroarea: 'Segurança/IA', element: 'Código de ética - Identificação', difficulty: 'fácil',
    statement: 'De acordo com o Código de Ética do profissional de TI, o profissional que descobre uma vulnerabilidade de segurança em um sistema do cliente deve:\n\nA) Explorar a vulnerabilidade para demonstrar suas habilidades\nB) Divulgar a vulnerabilidade publicamente imediatamente\nC) Informar o cliente de forma responsável e confidencial, sugerindo correções\nD) Ignorar a vulnerabilidade pois não é sua responsabilidade\nE) Vender a informação sobre a vulnerabilidade',
    alternatives: [{ letter: 'A', text: 'Explorar a vulnerabilidade para demonstrar suas habilidades' }, { letter: 'B', text: 'Divulgar a vulnerabilidade publicamente imediatamente' }, { letter: 'C', text: 'Informar o cliente de forma responsável e confidencial, sugerindo correções' }, { letter: 'D', text: 'Ignorar a vulnerabilidade pois não é sua responsabilidade' }, { letter: 'E', text: 'Vender a informação sobre a vulnerabilidade' }],
    correctAnswer: 'C', explanation: 'O profissional de TI tem o dever ético de agir com responsabilidade e sigilo. Descobrir vulnerabilidades impõe a obrigação de informar o responsável de forma confidencial, permitindo que a correção seja feita antes da possível divulgação pública (responsible disclosure).', source: 'elaborada', triA: 1.2, triB: -0.6, triC: 0.28,
  },

  // ===================== LEGISLAÇÃO (3) =====================
  {
    id: 'EXP-LEG-001', microarea: 'Legislação', macroarea: 'Segurança/IA', element: 'Marco Civil da Internet - Compreensão', difficulty: 'médio',
    statement: 'O Marco Civil da Internet (Lei 12.965/2014) estabelece, entre outros princípios:\n\nA) Que provedores de internet devem fornecer dados pessoais dos usuários ao governo sem necessidade de ordem judicial\nB) A proteção da privacidade e dos dados pessoais como direitos fundamentais na internet\nC) Que o acesso à internet deve ser restrito apenas para fins comerciais\nD) Que conteúdo online não pode ser moderado por plataformas\nE) Que provedores não são responsáveis por conteúdo de terceiros sob nenhuma circunstância',
    alternatives: [{ letter: 'A', text: 'Que provedores de internet devem fornecer dados pessoais dos usuários ao governo sem necessidade de ordem judicial' }, { letter: 'B', text: 'A proteção da privacidade e dos dados pessoais como direitos fundamentais na internet' }, { letter: 'C', text: 'Que o acesso à internet deve ser restrito apenas para fins comerciais' }, { letter: 'D', text: 'Que conteúdo online não pode ser moderado por plataformas' }, { letter: 'E', text: 'Que provedores não são responsáveis por conteúdo de terceiros sob nenhuma circunstância' }],
    correctAnswer: 'B', explanation: 'O Marco Civil da Internet é a "constituição da internet" brasileira, estabelecendo princípios como: liberdade de expressão, privacidade, proteção de dados, neutralidade de rede, preservação da natureza participativa da internet. Também define as responsabilidades de provedores (judicialização vs. notificação).', source: 'elaborada', triA: 1.5, triB: -0.1, triC: 0.24,
  },
  {
    id: 'EXP-LEG-002', microarea: 'Legislação', macroarea: 'Segurança/IA', element: 'Lei de Software - Identificação', difficulty: 'fácil',
    statement: 'A Lei de Software (Lei 9.609/98) regulamenta a proteção de propriedade intelectual de programas de computador, considerando-os como:\n\nA) Bens físicos tangíveis\nB) Obras literárias, protegidas pelo direito autoral\nC) Patentes industriais com validade de 20 anos\nD) Domínio público após a publicação\nE) Segredos industriais sem proteção legal',
    alternatives: [{ letter: 'A', text: 'Bens físicos tangíveis' }, { letter: 'B', text: 'Obras literárias, protegidas pelo direito autoral' }, { letter: 'C', text: 'Patentes industriais com validade de 20 anos' }, { letter: 'D', text: 'Domínio público após a publicação' }, { letter: 'E', text: 'Segredos industriais sem proteção legal' }],
    correctAnswer: 'B', explanation: 'A Lei 9.609/98 equipara programas de computador a obras literárias, protegendo-os pelo direito autoral por 50 anos (vida do autor + 70 anos). O titular dos direitos exclusivos pode autorizar ou proibir reprodução, comercialização e modificação do software.', source: 'elaborada', triA: 1.1, triB: -0.8, triC: 0.28,
  },
  {
    id: 'EXP-LEG-003', microarea: 'Legislação', macroarea: 'Segurança/IA', element: 'Crimes cibernéticos - Identificação', difficulty: 'médio',
    statement: 'A Lei 12.737/2012 (Lei Carolina Dieckmann) tipifica como crime:\n\nA) A compra de softwares piratas\nB) A invasão de dispositivo informático alheio para obter, adulterar ou destruir dados sem autorização\nC) O uso de internet em horário comercial\nD) O compartilhamento de senhas entre colegas de trabalho\nE) O acesso a redes Wi-Fi públicas',
    alternatives: [{ letter: 'A', text: 'A compra de softwares piratas' }, { letter: 'B', text: 'A invasão de dispositivo informático alheio para obter, adulterar ou destruir dados sem autorização' }, { letter: 'C', text: 'O uso de internet em horário comercial' }, { letter: 'D', text: 'O compartilhamento de senhas entre colegas de trabalho' }, { letter: 'E', text: 'O acesso a redes Wi-Fi públicas' }],
    correctAnswer: 'B', explanation: 'A Lei 12.737/2012 criminaliza a invasão de dispositivo informático (art. 154-A do Código Penal): "invadir dispositivo informático alheio, mediante violação indevida de mecanismo de segurança e com o fim de obter, adulterar ou destruir dados ou informações sem autorização expressa ou tácita do titular". Pena: detenção de 3 meses a 1 ano.', source: 'elaborada', triA: 1.6, triB: 0.0, triC: 0.22,
  },
];
