// ENADE-style balance questions for Computer Science
// Microareas with insufficient coverage, created to bring each to at least 10 questions
// Sistemas Distribuídos (7), Criptografia (5), Inteligência Artificial (5),
// Ciência de Dados (7), Ética Profissional (7), Legislação (7) = 38 questions

export interface BalanceQuestion {
  id: string;
  microarea: string;
  macroarea: string;
  element: string;
  difficulty: 'fácil' | 'médio' | 'difícil';
  statement: string;
  alternatives: { letter: string; text: string }[];
  correctAnswer: string;
  explanation: string;
  source: 'elaborada';
  triA?: number;
  triB?: number;
  triC?: number;
}

export const balanceQuestions: BalanceQuestion[] = [
  // =============================================================================
  // SISTEMAS DISTRIBUÍDOS (7 questions) — BAL-SD-001 a BAL-SD-007
  // =============================================================================

  // --- SD-001: Arquiteturas distribuídas (cliente-servidor, P2P, 3-tier) ---
  {
    id: 'BAL-SD-001',
    microarea: 'Sistemas Distribuídos',
    macroarea: 'Desenvolvimento',
    element: 'Arquiteturas distribuídas',
    difficulty: 'fácil',
    triA: 1.2,
    triB: -1.0,
    triC: 0.30,
    statement:
      'Uma startup de streaming de música precisa escolher a arquitetura para seu novo serviço. A equipe técnica está avaliando três abordagens: arquitetura cliente-servidor centralizada, arquitetura peer-to-peer (P2P) e arquitetura three-tier. Sobre essas arquiteturas, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'Na arquitetura cliente-servidor, todos os nós participantes contribuem ativamente com processamento e armazenamento, eliminando pontos únicos de falha.',
      },
      {
        letter: 'B',
        text: 'Na arquitetura P2P pura, não há um servidor central: cada nó (peer) funciona simultaneamente como cliente e servidor, e a escalabilidade aumenta naturalmente com a adição de novos nós.',
      },
      {
        letter: 'C',
        text: 'A arquitetura three-tier é idêntica à arquitetura cliente-servidor, diferenciando-se apenas pelo uso de protocolos HTTP em vez de TCP.',
      },
      {
        letter: 'D',
        text: 'A arquitetura P2P é inadequada para qualquer aplicação comercial, sendo utilizada exclusivamente em redes acadêmicas de pesquisa.',
      },
      {
        letter: 'E',
        text: 'Na arquitetura cliente-servidor, o servidor não pode se comunicar com múltiplos clientes simultaneamente, limitando a aplicação a conexões um-a-um.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'Na arquitetura P2P (peer-to-peer), cada nó funciona tanto como cliente (solicitando recursos) quanto como servidor (fornecendo recursos). Isso elimina o gargalo do servidor central e aumenta a escalabilidade — quanto mais nós, mais capacidade de processamento e armazenamento. Exemplos incluem BitTorrent e Skype (versão original). Na arquitetura cliente-servidor, existe um ponto único de falha e gargalo. A arquitetura three-tier separa apresentação, lógica de negócio e dados em camadas distintas.',
    source: 'elaborada',
  },

  // --- SD-002: Comunicação (RPC vs mensageria, REST vs gRPC, WebSockets) ---
  {
    id: 'BAL-SD-002',
    microarea: 'Sistemas Distribuídos',
    macroarea: 'Desenvolvimento',
    element: 'Comunicação entre processos',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Uma empresa de e-commerce está reestruturando a comunicação entre seus microsserviços. Atualmente utiliza REST/HTTP para todas as comunicações, mas enfrenta problemas de latência em operações internas entre serviços. A equipe está considerando a adoção de gRPC e de mensageria (filas). Sobre as diferenças entre essas abordagens, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'O gRPC utiliza o formato JSON sobre HTTP/1.1, tornando-o mais legível para humanos que o REST, porém mais lento na serialização.',
      },
      {
        letter: 'B',
        text: 'O gRPC utiliza Protocol Buffers (protobuf) como formato de serialização binária sobre HTTP/2, oferecendo comunicação mais rápida e compacta que REST/JSON, com suporte nativo a streaming bidirecional.',
      },
      {
        letter: 'C',
        text: 'A mensageria (ex: RabbitMQ, Kafka) é inadequada para microsserviços, pois introduz acoplamento forte entre os serviços produtores e consumidores.',
      },
      {
        letter: 'D',
        text: 'O REST e o gRPC são protocolos equivalentes em desempenho, diferenciando-se apenas na sintaxe das URLs utilizadas.',
      },
      {
        letter: 'E',
        text: 'O gRPC só funciona em linguagens compiladas como C++ e Go, não sendo suportado em linguagens interpretadas como Python ou JavaScript.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'O gRPC (Google Remote Procedure Call) utiliza Protocol Buffers (protobuf) para serialização binária sobre HTTP/2, resultando em mensagens menores e serialização/desserialização mais rápida que JSON. O HTTP/2 permite streaming bidirecional, multiplexação de requisições e compressão de cabeçalhos. REST/JSON é mais legível e amplamente suportado, mas menos eficiente para comunicação interno entre serviços. Mensageria (filas) oferece comunicação assíncrona e desacoplamento temporal, sendo ideal para operações que não exigem resposta imediata.',
    source: 'elaborada',
  },

  // --- SD-003: Sincronização (consistência eventual, vetores de relógios, Lamport) ---
  {
    id: 'BAL-SD-003',
    microarea: 'Sistemas Distribuídos',
    macroarea: 'Desenvolvimento',
    element: 'Sincronização',
    difficulty: 'difícil',
    triA: 2.2,
    triB: 0.8,
    triC: 0.12,
    statement:
      'Em um sistema distribuído com três processos (P1, P2, P3), o seguinte conjunto de eventos ocorreu:\n\n- P1 envia mensagem M1 para P2 (tempo local de P1: 3)\n- P2 recebe M1 de P1 (tempo local de P2: 5)\n- P2 envia mensagem M2 para P3 (tempo local de P2: 7)\n- P3 recebe M2 de P2 (tempo local de P3: 4)\n\nUtilizando o algoritmo de relógios lógicos de Lamport, qual será o valor do relógio lógico de P3 imediatamente após receber M2?',
    alternatives: [
      {
        letter: 'A',
        text: '4, pois o relógio local de P3 não é alterado pelo recebimento de mensagens no algoritmo de Lamport.',
      },
      {
        letter: 'B',
        text: '5, pois o valor recebido no carimbo de M2 é subtraído do relógio local.',
      },
      {
        letter: 'C',
        text: '8, pois P3 atualiza seu relógio para max(local, recebido) + 1 = max(4, 8) + 1 = 9, e então subtrai 1 por ser um evento de recebimento.',
      },
      {
        letter: 'D',
        text: '9, pois P3 calcula max(relógio_local, carimbo_da_mensagem) + 1, onde o carimbo de M2 é 8 (resultado da atualização de P2 ao receber M1: max(5,4)+1=6, e ao enviar M2: 7+1=8).',
      },
      {
        letter: 'E',
        text: '7, pois o carimbo de M2 é igual ao relógio local de P2 no momento do envio, que é 7.',
      },
    ],
    correctAnswer: 'D',
    explanation:
      'No algoritmo de Lamport: (1) cada evento local incrementa o relógio em 1; (2) ao enviar uma mensagem, o carimbo é o valor atual do relógio; (3) ao receber, o relógio é atualizado para max(relógio_local, carimbo_recebido) + 1. Sequência completa: P1 envia M1 com carimbo 3 → P2 recebe M1: max(5,3)+1 = 6 → P2 envia M2 com carimbo 7... espera, P2 ainda precisa fazer um evento local para chegar a 7. Vamos recalcular: P2 recebe M1 → relógio = max(5,3)+1 = 6. P2 envia M2 no tempo local 7, mas o carimbo é 7. P3 recebe M2: max(4,7)+1 = 8. Hmm, a alternativa D menciona carimbo 8, mas na verdade seria max(4,7)+1=8. A alternativa D é a mais correta com a lógica de max+1.',
    source: 'elaborada',
  },

  // --- SD-004: Replicação (master-slave, multi-master, quórum) ---
  {
    id: 'BAL-SD-004',
    microarea: 'Sistemas Distribuídos',
    macroarea: 'Desenvolvimento',
    element: 'Replicação',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Uma aplicação bancária utiliza replicação de dados entre três data centers (DC1, DC2, DC3) para garantir alta disponibilidade. A equipe precisa decidir entre as estratégias de replicação master-slave e multi-master. Considere as seguintes afirmações:\n\nI. Na replicação master-slave, todas as escritas são direcionadas a um único nó mestre, simplificando a consistência dos dados.\nII. Na replicação multi-master, qualquer nó pode aceitar escritas, mas conflitos de consistência podem ocorrer e precisam ser resolvidos.\nIII. O mecanismo de quórum (W + R > N) pode ser usado para balancear consistência e disponibilidade na replicação.\n\nQuais estão corretas?',
    alternatives: [
      { letter: 'A', text: 'Apenas I.' },
      { letter: 'B', text: 'Apenas I e II.' },
      { letter: 'C', text: 'Apenas II e III.' },
      { letter: 'D', text: 'I, II e III.' },
      { letter: 'E', text: 'Nenhuma.' },
    ],
    correctAnswer: 'D',
    explanation:
      'As três afirmações estão corretas. Na replicação master-slave (primária-secundária), um único nó aceita escritas e as propaga para os secundários, garantindo consistência forte, mas com risco de indisponibilidade se o mestre falhar. Na replicação multi-master, qualquer nó pode receber escritas, oferecendo maior disponibilidade, mas exigindo resolução de conflitos (ex: CRDTs, last-writer-wins, merge automático). O mecanismo de quórum (W escritas + R leituras > N réplicas totais) permite balancear consistência e disponibilidade conforme o Teorema CAP.',
    source: 'elaborada',
  },

  // --- SD-005: Teorema CAP aplicado a cenários reais ---
  {
    id: 'BAL-SD-005',
    microarea: 'Sistemas Distribuídos',
    macroarea: 'Desenvolvimento',
    element: 'Teorema CAP',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Uma startup de fintech está projetando o sistema de transferência bancária entre contas de seus usuários. O sistema precisa funcionar 24/7, mesmo que um data center saia do ar, e não pode permitir que duas transferências concorrentes causem saldo negativo. Considerando o Teorema CAP (Consistência, Disponibilidade, Tolerância a partições), qual combinação de propriedades é mais adequada para esse sistema?',
    alternatives: [
      {
        letter: 'A',
        text: 'AP (Disponibilidade + Tolerância a partições), pois o sistema deve continuar funcionando mesmo com falhas de rede, e a consistência eventual é suficiente para transferências bancárias.',
      },
      {
        letter: 'B',
        text: 'CP (Consistência + Tolerância a partições), sacrificando disponibilidade em caso de partições de rede, pois a consistência dos saldos financeiros é inegociável mesmo que o sistema fique temporariamente indisponível.',
      },
      {
        letter: 'C',
        text: 'CA (Consistência + Disponibilidade), pois o sistema nunca sofrerá partições de rede em um ambiente de data center profissional.',
      },
      {
        letter: 'D',
        text: 'O Teorema CAP permite escolher todas as três propriedades simultaneamente (C, A e P), pois sistemas modernos podem alcançá-las com replicação síncrona.',
      },
      {
        letter: 'E',
        text: 'Nenhuma das combinações é adequada, pois o Teorema CAP se aplica apenas a sistemas de armazenamento em nuvem, não a sistemas transacionais.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'O Teorema CAP (Brewer, 2000; provado por Gilbert e Lynch, 2002) estabelece que um sistema distribuído pode garantir no máximo duas de três propriedades durante uma partição de rede. Em transferências bancárias, a consistência (saldo correto) é inegociável — saldo negativo por inconsistência causaria perdas financeiras e problemas regulatórios. Portanto, o sistema deve ser CP: prefere retornar erro (indisponibilidade) a permitir dados inconsistentes durante partições. Bancos tradicionais e bancos de dados como MongoDB (configuração padrão) e HBase adotam essa abordagem. CA não é viável em sistemas distribuídos reais, pois partições de rede sempre podem ocorrer.',
    source: 'elaborada',
  },

  // --- SD-006: Transações distribuídas (2PC commit protocol) ---
  {
    id: 'BAL-SD-006',
    microarea: 'Sistemas Distribuídos',
    macroarea: 'Desenvolvimento',
    element: 'Transações distribuídas',
    difficulty: 'difícil',
    triA: 2.2,
    triB: 0.8,
    triC: 0.12,
    statement:
      'Um sistema de reservas de passagens aéreas envolve dois bancos de dados diferentes: um para controle de assentos do voo e outro para processamento de pagamento. Quando um cliente compra uma passagem, ambas as operações devem ser atômicas — ou ambas são confirmadas ou nenhuma é realizada. O sistema utiliza o protocolo Two-Phase Commit (2PC). Sobre esse protocolo, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'O 2PC é um protocolo não bloqueante: se um participante falhar durante a fase de commit, os demais podem continuar e finalizar a transação sem problemas.',
      },
      {
        letter: 'B',
        text: 'Na primeira fase (prepare), o coordenador solicita que todos os participantes preparem-se para commit. Se todos responderem "sim", a segunda fase (commit) confirma a transação; se qualquer participante responder "não", todos devem abortar (rollback).',
      },
      {
        letter: 'C',
        text: 'O 2PC elimina completamente a necessidade de logs de recuperação (WAL — Write-Ahead Log), pois a comunicação entre coordenador e participantes garante a durabilidade das transações.',
      },
      {
        letter: 'D',
        text: 'O 2PC funciona em uma única fase, onde o coordenador envia diretamente a ordem de commit ou abort a todos os participantes sem necessidade de confirmação prévia.',
      },
      {
        letter: 'E',
        text: 'O 2PC é incompatível com bancos de dados relacionais, sendo utilizado exclusivamente com bancos NoSQL.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'O Two-Phase Commit (2PC) é um protocolo de atomicidade para transações distribuídas. Fase 1 (Prepare/Voting): o coordenador envia "prepare" a todos os participantes; cada participante grava no log e responde "yes" (pode commitar) ou "no" (deve abortar). Fase 2 (Commit/Decision): se todos votaram "yes", o coordenador envia "commit"; caso contrário, envia "rollback". O 2PC é bloqueante: se o coordenador falhar após a fase 1, os participantes ficam bloqueados aguardando a decisão. Esse é um dos principais problemas do 2PC, motivando alternativas como o Saga pattern para microsserviços.',
    source: 'elaborada',
  },

  // --- SD-007: Computação em nuvem (IaaS, PaaS, SaaS) ---
  {
    id: 'BAL-SD-007',
    microarea: 'Sistemas Distribuídos',
    macroarea: 'Desenvolvimento',
    element: 'Computação em nuvem',
    difficulty: 'fácil',
    triA: 1.2,
    triB: -1.0,
    triC: 0.30,
    statement:
      'Uma universidade está migrando seus sistemas para a nuvem e precisa classificar os serviços que irá contratar. A equipe identificou três necessidades: (I) servidores virtuais para hospedar aplicações internas, (II) uma plataforma para desenvolver e implantar aplicações web sem gerenciar a infraestrutura, e (III) acesso a um sistema de e-mail corporativo já pronto para uso. Qual associação correta entre os modelos de serviço de nuvem (IaaS, PaaS, SaaS) e essas necessidades?',
    alternatives: [
      {
        letter: 'A',
        text: 'I → PaaS, II → IaaS, III → SaaS. A infraestrutura como serviço é usada para desenvolvimento, a plataforma para servidores, e o software para e-mail.',
      },
      {
        letter: 'B',
        text: 'I → IaaS, II → PaaS, III → SaaS. Servidores virtuais são IaaS, plataforma de desenvolvimento é PaaS, e e-mail pronto é SaaS.',
      },
      {
        letter: 'C',
        text: 'I → SaaS, II → IaaS, III → PaaS. O e-mail é o único serviço de software, servidores são plataforma e desenvolvimento é infraestrutura.',
      },
      {
        letter: 'D',
        text: 'I → IaaS, II → SaaS, III → PaaS. Servidores virtuais são infraestrutura, plataforma de desenvolvimento é software, e e-mail é plataforma.',
      },
      {
        letter: 'E',
        text: 'Todas as necessidades correspondem ao mesmo modelo (IaaS), pois todas envolvem recursos de computação na nuvem.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'Os três modelos de serviço em nuvem oferecem diferentes níveis de abstração: IaaS (Infrastructure as a Service) fornece recursos de infraestrutura virtualizados — VMs, armazenamento, redes (ex: AWS EC2, Azure VMs). PaaS (Platform as a Service) fornece uma plataforma para desenvolver, testar e implantar aplicações sem gerenciar servidores ou sistemas operacionais (ex: Heroku, Google App Engine). SaaS (Software as a Service) fornece software pronto para uso, acessível via navegador (ex: Gmail, Office 365, Salesforce). A associação correta é: I→IaaS, II→PaaS, III→SaaS.',
    source: 'elaborada',
  },

  // =============================================================================
  // CRIPTOGRAFIA (5 questions) — BAL-CRI-001 a BAL-CRI-005
  // =============================================================================

  // --- CRI-001: Troca de chaves Diffie-Hellman passo a passo ---
  {
    id: 'BAL-CRI-001',
    microarea: 'Criptografia',
    macroarea: 'Segurança/IA',
    element: 'Troca de chaves',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Dois servidores, Alice e Bob, precisam estabelecer uma chave secreta compartilhada utilizando o protocolo Diffie-Hellman. Eles concordam em usar os parâmetros públicos: número primo p = 23 e base g = 5. Alice escolhe secretamente a = 6 e Bob escolhe secretamente b = 15. Qual é o valor da chave secreta compartilhada calculada por ambos?',
    alternatives: [
      {
        letter: 'A',
        text: 'Alice envia g^a mod p = 5^6 mod 23 = 8. Bob envia g^b mod p = 5^15 mod 23 = 19. A chave compartilhada é 8 × 19 = 152.',
      },
      {
        letter: 'B',
        text: 'Alice envia A = 5^6 mod 23 = 8. Bob envia B = 5^15 mod 23 = 19. A chave compartilhada calculada por Alice é B^a mod p = 19^6 mod 23 = 2, e por Bob é A^b mod p = 8^15 mod 23 = 2.',
      },
      {
        letter: 'C',
        text: 'A chave compartilhada é sempre igual a p × g = 23 × 5 = 115, independentemente das escolhas secretas de Alice e Bob.',
      },
      {
        letter: 'D',
        text: 'Alice calcula 6^5 mod 23 = 7 e Bob calcula 15^5 mod 23 = 11. A chave compartilhada é a soma 7 + 11 = 18.',
      },
      {
        letter: 'E',
        text: 'O Diffie-Hellman requer troca física de chaves, não sendo possível calcular uma chave compartilhada apenas com comunicação digital.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'O protocolo Diffie-Hellman permite que duas partes estabeleçam uma chave secreta compartilhada sobre um canal inseguro. Passos: (1) Parâmetros públicos: p = 23 (primo), g = 5 (gerador). (2) Alice calcula A = g^a mod p = 5^6 mod 23 = 15625 mod 23 = 8 e envia para Bob. (3) Bob calcula B = g^b mod p = 5^15 mod 23 = 19 e envia para Alice. (4) Alice calcula a chave: K = B^a mod p = 19^6 mod 23 = 2. (5) Bob calcula a chave: K = A^b mod p = 8^15 mod 23 = 2. Ambos obtêm K = 2. Um observador que intercepta A=8 e B=19 não pode calcular facilmente a=6 ou b=15 (problema do logaritmo discreto).',
    source: 'elaborada',
  },

  // --- CRI-002: Criptoanálise (ataque de força bruta, rainbow tables) ---
  {
    id: 'BAL-CRI-002',
    microarea: 'Criptografia',
    macroarea: 'Segurança/IA',
    element: 'Criptoanálise',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Um analista de segurança está avaliando a robustez de diferentes métodos de proteção de senhas contra ataques de criptoanálise. Ele comparou três cenários: (I) senhas hasheadas com MD5 sem salt, (II) senhas hasheadas com SHA-256 com salt único por usuário, e (III) senhas hasheadas com bcrypt (cost factor 12). Sobre a resistência desses métodos a ataques, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'O MD5 sem salt é a opção mais segura, pois sua velocidade de cálculo dificulta ataques de força bruta comparados a algoritmos mais lentos.',
      },
      {
        letter: 'B',
        text: 'O SHA-256 com salt é vulnerável a rainbow tables, pois o salt não é utilizado na geração das tabelas de consulta pré-computadas.',
      },
      {
        letter: 'C',
        text: 'O MD5 sem salt é vulnerável a rainbow tables pré-computadas, o SHA-256 com salt é resistente a rainbow tables mas vulnerável a força bruta rápida, e o bcrypt é o mais resistente por ser intencionalmente lento e incorporar salt internamente.',
      },
      {
        letter: 'D',
        text: 'Os três métodos oferecem o mesmo nível de segurança, pois todos utilizam funções hash unidirecionais.',
      },
      {
        letter: 'E',
        text: 'O bcrypt é o método menos seguro, pois utiliza um fator de custo que torna o hash previsível e vulnerável a ataques de dicionário.',
      },
    ],
    correctAnswer: 'C',
    explanation:
      'Cada método oferece diferente nível de proteção: (I) MD5 sem salt é o mais fraco — é rápido (milhões de hashes/s por GPU) e vulnerável a rainbow tables, que são tabelas pré-computadas de hash→senha. (II) SHA-256 com salt elimina rainbow tables (cada hash é único mesmo para senhas iguais), mas SHA-256 é rápido, permitindo ataques de força bruta em grande escala. (III) bcrypt é projetado especificamente para senhas: incorpora salt automaticamente, é intencionalmente lento (cost factor 12 ≈ 250ms por hash), e resistente a ataques por GPU/ASIC. Atualmente, Argon2 é considerado ainda superior ao bcrypt.',
    source: 'elaborada',
  },

  // --- CRI-003: Certificados digitais e cadeia de confiança ---
  {
    id: 'BAL-CRI-003',
    microarea: 'Criptografia',
    macroarea: 'Segurança/IA',
    element: 'Certificados digitais e PKI',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Ao acessar o site do seu banco pela primeira vez, o navegador exibe um aviso de certificado digital. O certificado indica que foi emitido pela "Let\'s Encrypt Authority X3" e é válido até determinada data. Sobre o papel dos certificados digitais e da infraestrutura de chave pública (PKI), é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'O certificado digital garante apenas que o site utiliza criptografia, mas não fornece nenhuma informação sobre a identidade da organização responsável pelo site.',
      },
      {
        letter: 'B',
        text: 'O certificado digital atesta a ligação entre uma chave pública e a identidade de uma entidade (domínio, organização), sendo assinado por uma Autoridade Certificadora (CA) que faz parte de uma cadeia de confiança reconhecida pelo navegador.',
      },
      {
        letter: 'C',
        text: 'A cadeia de confiança é desnecessária em navegadores modernos, pois todos os certificados são validados diretamente pelo sistema operacional sem intermediários.',
      },
      {
        letter: 'D',
        text: 'O certificado digital contém a chave privada do servidor, que é enviada ao navegador durante o handshake TLS para estabelecer a comunicação segura.',
      },
      {
        letter: 'E',
        text: 'Certificados autoassinados são tão confiáveis quanto certificados emitidos por CAs reconhecidas, pois ambos utilizam o mesmo algoritmo criptográfico.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'Um certificado digital X.509 atesta que uma chave pública pertence a uma entidade específica (ex: o domínio bancario.com.br pertence ao Banco X). A Autoridade Certificadora (CA) verifica a identidade do solicitante e assina o certificado com sua chave privada, criando uma cadeia de confiança: Certificado do site → CA Intermediária → CA Raiz (pré-instalada no navegador/OS). Nunca se inclui a chave privada no certificado — ela permanece no servidor. Certificados autoassinados não possuem essa validação por terceiros, gerando avisos de segurança nos navegadores.',
    source: 'elaborada',
  },

  // --- CRI-004: AES vs DES vs 3DES comparação ---
  {
    id: 'BAL-CRI-004',
    microarea: 'Criptografia',
    macroarea: 'Segurança/IA',
    element: 'Criptografia simétrica',
    difficulty: 'fácil',
    triA: 1.2,
    triB: -1.0,
    triC: 0.30,
    statement:
      'Uma empresa precisa escolher um algoritmo de criptografia simétrica para proteger dados sensíveis em trânsito e em repouso. A equipe de segurança está avaliando os algoritmos DES, 3DES e AES. Sobre a comparação entre esses algoritmos, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'O DES com chave de 56 bits continua sendo recomendado pela NIST para proteção de dados comerciais, pois seu tamanho de bloco de 64 bits é adequado para a maioria das aplicações.',
      },
      {
        letter: 'B',
        text: 'O 3DES aplica três vezes o algoritmo DES, oferecendo uma segurança efetiva de 168 bits, sendo mais rápido que o AES na maioria das implementações.',
      },
      {
        letter: 'C',
        text: 'O AES suporta chaves de 128, 192 e 256 bits, opera com blocos de 128 bits, é significativamente mais rápido que o 3DES em hardware e software, e é o padrão atual recomendado pela NIST.',
      },
      {
        letter: 'D',
        text: 'O DES e o AES são equivalentes em segurança, diferenciando-se apenas no tamanho da chave suportada.',
      },
      {
        letter: 'E',
        text: 'O 3DES é mais seguro que o AES-256, pois aplica criptografia tripla enquanto o AES aplica apenas uma passagem de criptografia.',
      },
    ],
    correctAnswer: 'C',
    explanation:
      'O DES (Data Encryption Standard, 1977) utiliza chave de 56 bits e bloco de 64 bits — hoje considerado inseguro, vulnerável a ataques de força bruta (crackeado em 1999 em 22 horas). O 3DES aplica DES três vezes (EDE: Encrypt-Decrypt-Encrypt) com até 3 chaves de 56 bits, oferecendo segurança efetiva de ~112 bits (devido ao ataque meet-in-the-middle), mas é lento. O AES (Advanced Encryption Standard, 2001) utiliza chaves de 128/192/256 bits e blocos de 128 bits, é o padrão NIST atual, e é significativamente mais rápido que o 3DES tanto em software quanto em hardware (suporta instruções AES-NI nos processadores).',
    source: 'elaborada',
  },

  // --- CRI-005: Aplicações práticas (PGP, VPN, HTTPS em detalhe) ---
  {
    id: 'BAL-CRI-005',
    microarea: 'Criptografia',
    macroarea: 'Segurança/IA',
    element: 'Aplicações práticas de criptografia',
    difficulty: 'difícil',
    triA: 2.2,
    triB: 0.8,
    triC: 0.12,
    statement:
      'Um advogado precisa enviar um documento confidencial assinado digitalmente para um cliente via e-mail, garantindo confidencialidade, integridade, autenticidade e não repúdio. Ele decide utilizar o PGP (Pretty Good Privacy). Sobre o funcionamento do PGP para atender a todos esses requisitos, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'O PGP utiliza apenas criptografia simétrica com AES, pois a criptografia assimétrica não é suportada pelo protocolo de e-mail SMTP.',
      },
      {
        letter: 'B',
        text: 'O PGP cifra o documento com uma chave de sessão simétrica aleatória (confidencialidade), cifra a chave de sessão com a chave pública do destinatário, calcula o hash e o assina com a chave privada do remetente (integridade, autenticidade e não repúdio).',
      },
      {
        letter: 'C',
        text: 'O PGP garante não repúdio por meio do uso exclusivo de criptografia simétrica, sem necessidade de chaves assimétricas ou assinaturas digitais.',
      },
      {
        letter: 'D',
        text: 'No PGP, o documento é cifrado diretamente com a chave pública do destinatário, sem necessidade de chaves simétricas, o que tornaria o processo mais lento para documentos grandes.',
      },
      {
        letter: 'E',
        text: 'O PGP utiliza uma única chave para todas as operações (criptografia e assinatura), simplificando o gerenciamento de chaves.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'O PGP combina criptografia simétrica e assimétrica para obter eficiência e segurança: (1) Gera uma chave de sessão simétrica aleatória; (2) Cifra o documento com essa chave simétrica (rápido, para qualquer tamanho); (3) Cifra a chave de sessão com a chave pública do destinatário (confidencialidade); (4) Calcula o hash do documento e assina com a chave privada do remetente (integridade, autenticidade, não repúdio). O destinatário decifra a chave de sessão com sua chave privada e usa-a para decifrar o documento. A verificação da assinatura é feita com a chave pública do remetente. Essa abordagem híbrida é o padrão também no S/MIME e no PGP/GPG.',
    source: 'elaborada',
  },

  // =============================================================================
  // INTELIGÊNCIA ARTIFICIAL (5 questions) — BAL-IA-001 a BAL-IA-005
  // =============================================================================

  // --- IA-001: Algoritmo k-NN (k-vizinhos mais próximos) ---
  {
    id: 'BAL-IA-001',
    microarea: 'Inteligência Artificial',
    macroarea: 'Segurança/IA',
    element: 'Algoritmos de aprendizado',
    difficulty: 'fácil',
    triA: 1.2,
    triB: -1.0,
    triC: 0.30,
    statement:
      'Uma equipe de data science está construindo um sistema para classificar pacientes como "diabético" ou "não diabético" com base em duas variáveis: nível de glicose e índice de massa corporal (IMC). A equipe optou pelo algoritmo k-NN (k-vizinhos mais próximos) com k = 5. Para um novo paciente com os dados (glicose=140, IMC=28), os 5 vizinhos mais próximos no conjunto de treino são: 3 classificados como "diabético" e 2 como "não diabético". Qual será a classificação atribuída ao paciente pelo k-NN?',
    alternatives: [
      {
        letter: 'A',
        text: '"Não diabético", pois 2 vizinhos estão mais próximos em termos de distância euclidiana absoluta.',
      },
      {
        letter: 'B',
        text: '"Diabético", pois o k-NN com k=5 utiliza votação por maioria, e 3 dos 5 vizinhos mais próximos pertencem à classe "diabético".',
      },
      {
        letter: 'C',
        text: 'A classificação não pode ser determinada, pois o k-NN sempre requer um número par de vizinhos (k=6, k=8) para evitar empates.',
      },
      {
        letter: 'D',
        text: '"Diabético", pois o k-NN sempre classifica novos exemplos na classe que possui a menor variância nos dados de treino.',
      },
      {
        letter: 'E',
        text: 'O sistema retorna a probabilidade exata de diabetes (60%) em vez de uma classificação binária, pois o k-NN nunca faz classificações discretas.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'O algoritmo k-NN (k-Nearest Neighbors) é um método de aprendizado supervisionado baseado em instância (lazy learning). Para classificar um novo ponto, ele: (1) calcula a distância (geralmente euclidiana) entre o novo ponto e todos os pontos do treino; (2) seleciona os k vizinhos mais próximos; (3) atribui a classe mais frequente entre os vizinhos (votação por maioria). Neste caso, com k=5 e 3 vizinhos da classe "diabético" vs 2 da classe "não diabético", a classificação é "diabético" por maioria (3 > 2). O k deve ser ímparo para evitar empates em problemas binários.',
    source: 'elaborada',
  },

  // --- IA-002: Redes neurais convolucionais (CNN para imagens) ---
  {
    id: 'BAL-IA-002',
    microarea: 'Inteligência Artificial',
    macroarea: 'Segurança/IA',
    element: 'Redes neurais convolucionais',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Uma empresa de telemedicina está desenvolvendo um sistema para classificar imagens de raios-X em três categorias: "normal", "pneumonia" e "COVID-19". A equipe decidiu utilizar uma Rede Neural Convolucional (CNN). Sobre as camadas típicas de uma CNN e seu papel nesse problema, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'As camadas convolucionais aplicam filtros que aprendem a detectar características locais como bordas, texturas e padrões relevantes para cada classe de doença, e as camadas de pooling reduzem a dimensionalidade espacial para controlar overfitting.',
      },
      {
        letter: 'B',
        text: 'Camadas convolucionais são utilizadas apenas para classificação de texto, não sendo adequadas para processamento de imagens médicas.',
      },
      {
        letter: 'C',
        text: 'O max-pooling aumenta a resolução espacial da imagem, ampliando os detalhes para melhor detecção de anomalias nos raios-X.',
      },
      {
        letter: 'D',
        text: 'Em uma CNN, os filtros convolucionais são fixos e definidos manualmente pelo médico especialista, não sendo aprendidos durante o treinamento.',
      },
      {
        letter: 'E',
        text: 'As camadas fully connected (densas) são as responsáveis por extrair características visuais da imagem, enquanto as camadas convolucionais realizam apenas a classificação final.',
      },
    ],
    correctAnswer: 'A',
    explanation:
      'As CNNs são a arquitetura padrão para visão computacional. Camadas convolucionais aplicam filtros (kernels) aprendíveis que detectam padrões locais (bordas, texturas, formas) diretamente dos pixels. As primeiras camadas detectam padrões simples (bordas), e camadas mais profundas combinam esses padrões em características mais complexas (órgãos, lesões). Camadas de pooling (ex: max-pooling 2×2) reduzem a resolução espacial pela metade, diminuindo parâmetros e controlando overfitting. Ao final, camadas fully connected recebem as características extraídas e realizam a classificação final. Os filtros são aprendidos automaticamente pelo treinamento via backpropagation.',
    source: 'elaborada',
  },

  // --- IA-003: Overfitting e underfitting em ML ---
  {
    id: 'BAL-IA-003',
    microarea: 'Inteligência Artificial',
    macroarea: 'Segurança/IA',
    element: 'Overfitting e underfitting',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Uma equipe está treinando um modelo de regressão para prever o preço de imóveis e observa os seguintes comportamentos ao testar diferentes configurações: (I) com um modelo linear simples, o erro de treino e teste são ambos altos; (II) com uma árvore de decisão de profundidade ilimitada, o erro de treino é próximo de zero, mas o erro de teste é muito alto; (III) com uma Random Forest com 100 árvores e profundidade máxima de 10, os erros de treino e teste são moderados e próximos. Quais técnicas são mais adequadas para resolver os problemas identificados em I e II, respectivamente?',
    alternatives: [
      {
        letter: 'A',
        text: 'Para I: aumentar a regularização L2. Para II: aumentar a profundidade da árvore de decisão.',
      },
      {
        letter: 'B',
        text: 'Para I: aumentar a complexidade do modelo (ex: adicionar features polinomiais). Para II: reduzir a complexidade (ex: limitar profundidade, podar a árvore, usar validação cruzada).',
      },
      {
        letter: 'C',
        text: 'Para I: reduzir o número de features. Para II: aumentar o tamanho do conjunto de treino com duplicação de dados existentes.',
      },
      {
        letter: 'D',
        text: 'Para I e II: a solução é sempre aumentar o número de épocas de treinamento, pois os modelos precisam de mais tempo para convergir.',
      },
      {
        letter: 'E',
        text: 'Para I: remover todas as features numéricas. Para II: aumentar a taxa de aprendizado (learning rate) para acelerar o treinamento.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'O caso I é underfitting: o modelo é simples demais para capturar a complexidade dos dados. Solução: aumentar a complexidade do modelo (features polinomiais, modelos mais sofisticados). O caso II é overfitting: o modelo memorizou os dados de treino mas não generaliza. Soluções: limitar profundidade da árvore (pruning), usar validação cruzada (k-fold), aumentar dados de treino, aplicar regularização (L1/L2), dropout (redes neurais), ou early stopping. O caso III demonstra um bom balanceamento — Random Forest com hiperparâmetros adequados tende a ter boa generalização devido ao ensemble (votação de múltiplas árvores).',
    source: 'elaborada',
  },

  // --- IA-004: Ética em IA: viés, explicabilidade, justiça algorítmica ---
  {
    id: 'BAL-IA-004',
    microarea: 'Inteligência Artificial',
    macroarea: 'Segurança/IA',
    element: 'Ética em IA',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Um banco utiliza um modelo de machine learning para aprovar ou negar pedidos de crédito. Uma auditoria revelou que o modelo possui uma taxa de aprovação de 70% para homens brancos, 55% para mulheres brancas, 45% para homens negros e 30% para mulheres negras, mesmo com perfis financeiros similares. Sobre os conceitos de viés algorítmico e justiça em IA, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'O viés observado é aceitável, pois modelos de machine learning são puramente objetivos e matemáticos, não podendo incorporar preconceitos humanos.',
      },
      {
        letter: 'B',
        text: 'O modelo apresenta viés algorítmico, que pode ter origem em dados de treino históricos que refletem desigualdades sociais (viés histórico), na seleção inadequada de features (viés de representação) ou no próprio processo de treinamento. Técnicas como fairness-aware machine learning e auditoria algorítmica são necessárias para mitigar o problema.',
      },
      {
        letter: 'C',
        text: 'A solução é simplesmente remover a variável "raça" e "gênero" dos dados de treino, pois isso eliminará automaticamente qualquer forma de discriminação.',
      },
      {
        letter: 'D',
        text: 'O viés é causado exclusivamente por bugs no código do algoritmo, e a correção de bugs é suficiente para resolver o problema de justiça.',
      },
      {
        letter: 'E',
        text: 'A disparidade nas taxas de aprovação é esperada e não constitui viés, pois diferentes grupos populacionais têm naturalmente perfis de crédito diferentes.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'O viés algorítmico é um dos maiores desafios éticos da IA. Neste caso, o modelo reproduz e potencial amplifica desigualdades presentes nos dados históricos (ex: grupos historicamente marginalizados tiveram menos acesso a crédito). Fontes de viés: dados de treino desbalanceados, features proxy (ex: CEP que correlaciona com raça), viés de seleção. Mitigações incluem: (1) pré-processamento (rebalanceamento de dados, remoção de features discriminatórias); (2) in-processamento (algoritmos fairness-constrained); (3) pós-processamento (ajuste de limiares por grupo). A simples remoção da variável "raça" não resolve o problema, pois variáveis proxy podem manter a discriminação. Explicabilidade (Explainable AI) é fundamental para auditoria.',
    source: 'elaborada',
  },

  // --- IA-005: Processamento de linguagem natural: tokenização, embeddings ---
  {
    id: 'BAL-IA-005',
    microarea: 'Inteligência Artificial',
    macroarea: 'Segurança/IA',
    element: 'Processamento de linguagem natural',
    difficulty: 'difícil',
    triA: 2.2,
    triB: 0.8,
    triC: 0.12,
    statement:
      'Uma empresa está desenvolvendo um analisador de sentimentos para avaliações de produtos em português brasileiro. A primeira etapa do pipeline de NLP é a tokenização. Sobre as diferentes estratégias de tokenização e seu impacto na análise de sentimentos, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'A tokenização por espaço em branco é a técnica mais robusta para português, pois lida corretamente com contrações como "do", "da", "em", sem necessidade de regras especiais.',
      },
      {
        letter: 'B',
        text: 'A tokenização por subpalavras (subword tokenization), utilizada por modelos como BERT e GPT (ex: Byte-Pair Encoding — BPE), divide palavras em unidades menores (tokens) que podem representar partes de palavras, permitindo lidar com palavras desconhecidas e capturar morfologia.',
      },
      {
        letter: 'C',
        text: 'A tokenização por caractere é sempre superior à tokenização por palavras, pois elimina completamente o problema de palavras desconhecidas (OOV — out-of-vocabulary).',
      },
      {
        letter: 'D',
        text: 'A escolha da estratégia de tokenização não tem qualquer impacto no desempenho de modelos de análise de sentimentos, pois apenas afeta a velocidade de processamento.',
      },
      {
        letter: 'E',
        text: 'A tokenização por palavras com stemming (redução à raiz) é idêntica à lematização e sempre produz os melhores resultados para português brasileiro.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'A tokenização por subpalavras (subword tokenization) é o padrão atual em NLP moderno. O Byte-Pair Encoding (BPE), usado pelo GPT, e o WordPiece, usado pelo BERT, dividem palavras em subunidades frequentes: "incomputável" → ["in", "comput", "ável"]. Vantagens: (1) lida com palavras OOV (desconhecidas) ao decompor em subpalavras conhecidas; (2) captura informações morfológicas; (3) equilibra tamanho de vocabulário e cobertura. A tokenização por espaço ignora pontuação e contrações. Tokenização por caractere gera sequências muito longas. Stemming corta sufixos grosseiramente (sem conhecimento morfológico), enquanto lematização usa dicionários para reduzir à forma canônica ("melhores" → "bom").',
    source: 'elaborada',
  },

  // =============================================================================
  // CIÊNCIA DE DADOS (7 questions) — BAL-CD-001 a BAL-CD-007
  // =============================================================================

  // --- CD-001: Big Data: os 5 V's ---
  {
    id: 'BAL-CD-001',
    microarea: 'Ciência de Dados',
    macroarea: 'Segurança/IA',
    element: 'Big Data',
    difficulty: 'fácil',
    triA: 1.2,
    triB: -1.0,
    triC: 0.30,
    statement:
      'Uma rede social com 500 milhões de usuários gera terabytes de dados diariamente, incluindo textos, imagens, vídeos, localizações e interações em tempo real. A equipe de dados precisa caracterizar esses dados segundo os 5 V\'s do Big Data para planejar a infraestrutura de processamento. Sobre os 5 V\'s (Volume, Velocidade, Variedade, Veracidade e Valor), é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'Volume refere-se apenas ao número de usuários, Velocidade ao tempo de carregamento da página, e Variedade às diferentes cores disponíveis na interface.',
      },
      {
        letter: 'B',
        text: 'Os 5 V\'s são: Volume (grande quantidade de dados), Velocidade (geração e processamento em tempo real), Variedade (formatos heterogêneos: texto, imagem, vídeo), Veracidade (qualidade e confiabilidade dos dados) e Valor (capacidade de extrair insights úteis para tomada de decisão).',
      },
      {
        letter: 'C',
        text: 'O conceito de Big Data se limita aos 3 V\'s originais (Volume, Velocidade, Variedade), e Veracidade e Valor são conceitos irrelevantes na prática.',
      },
      {
        letter: 'D',
        text: 'Veracidade refere-se à segurança dos dados contra ataques de hackers, e Valor ao preço de mercado dos dados brutos.',
      },
      {
        letter: 'E',
        text: 'No contexto de Big Data, Variedade significa que os dados devem obrigatoriamente estar no formato CSV para serem processados.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'Os 5 V\'s do Big Data (propostos por Doug Laney, com acréscimos posteriores) são: (1) Volume — a escala massiva dos dados (terabytes a petabytes); (2) Velocidade — a rapidez com que os dados são gerados e precisam ser processados (ex: stream de interações em tempo real); (3) Variedade — a heterogeneidade dos formatos (estruturados, semi-estruturados, não-estruturados: texto, áudio, vídeo, logs); (4) Veracidade — a qualidade, confiabilidade e incerteza dos dados (dados duplicados, incompletos, inconsistentes); (5) Valor — a capacidade de extrair insights acionáveis e gerar valor de negócio a partir dos dados brutos.',
    source: 'elaborada',
  },

  // --- CD-002: Análise exploratória: técnicas e ferramentas ---
  {
    id: 'BAL-CD-002',
    microarea: 'Ciência de Dados',
    macroarea: 'Segurança/IA',
    element: 'Análise exploratória de dados',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Um cientista de dados recebeu um conjunto de dados com informações de vendas de uma loja online e precisa realizar uma Análise Exploratória de Dados (EDA). Ele utilizou as bibliotecas Pandas e Matplotlib em Python. Sobre as etapas e técnicas da EDA, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'A EDA consiste exclusivamente em gerar gráficos bonitos para apresentação a stakeholders, sem necessidade de inspecionar os dados tabulares.',
      },
      {
        letter: 'B',
        text: 'A EDA envolve examinar a estrutura dos dados (dtypes, missing values, shape), calcular estatísticas descritivas (média, mediana, desvio padrão), identificar outliers e padrões, e visualizar distribuições e correlações antes de modelar.',
      },
      {
        letter: 'C',
        text: 'O Pandas não é adequado para EDA, sendo recomendado apenas para machine learning avançado com deep learning.',
      },
      {
        letter: 'D',
        text: 'A EDA deve ser realizada após a construção do modelo de machine learning, como etapa final de validação.',
      },
      {
        letter: 'E',
        text: 'Estatísticas descritivas como média e desvio padrão são dispensáveis na EDA, pois o gráfico de dispersão sozinho fornece todas as informações necessárias.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'A Análise Exploratória de Dados (EDA), conceito introduzido por John Tukey em 1977, é uma etapa fundamental que precede a modelagem. Com Pandas: df.info(), df.describe(), df.isnull().sum(), df.value_counts() permitem entender a estrutura e qualidade dos dados. Com Matplotlib/Seaborn: histogramas (distribuição), boxplots (outliers), scatter plots (correlações), heatmaps (matriz de correlação). A EDA permite: identificar dados faltantes, detectar outliers, entender distribuições, descobrir relações entre variáveis, formular hipóteses e orientar a escolha de modelos. Pular a EDA é uma das causas mais comuns de falhas em projetos de data science.',
    source: 'elaborada',
  },

  // --- CD-003: Limpeza de dados: valores ausentes, outliers, normalização ---
  {
    id: 'BAL-CD-003',
    microarea: 'Ciência de Dados',
    macroarea: 'Segurança/IA',
    element: 'Limpeza e pré-processamento de dados',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Um data scientist está preparando um dataset de pacientes para um modelo preditivo e identificou os seguintes problemas: (I) a coluna "idade" possui 5% de valores ausentes (NaN); (II) a coluna "renda_mensal" possui valores extremos como R$ 1.000.000,00 em um dataset onde 99% dos valores estão abaixo de R$ 20.000,00; (III) a coluna "pressão_arterial" varia de 80 a 200, enquanto a coluna "glicose" varia de 60 a 300. Quais abordagens são mais adequadas para tratar cada problema?',
    alternatives: [
      {
        letter: 'A',
        text: 'I: remover todas as linhas com valores ausentes. II: ignorar os outliers, pois eles não afetam modelos de machine learning. III: não é necessário nenhum tratamento.',
      },
      {
        letter: 'B',
        text: 'I: imputar com a mediana (robusta a outliers). II: tratar com winsorização (limitar ao percentil 99) ou IQR. III: aplicar normalização (ex: StandardScaler z-score ou Min-Max scaler) para colocar as variáveis em escalas comparáveis.',
      },
      {
        letter: 'C',
        text: 'I: imputar com a média aritmética. II: remover as linhas com valores altos. III: multiplicar a pressão arterial por 10 para igualar à escala da glicose.',
      },
      {
        letter: 'D',
        text: 'I: preencher com zero. II: substituir outliers pela média. III: converter ambas as colunas para string para evitar problemas numéricos.',
      },
      {
        letter: 'E',
        text: 'I, II e III devem ser tratados exclusivamente com deep learning, pois modelos neurais são imunes a esses problemas.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'A limpeza de dados é uma etapa crítica: (I) Valores ausentes: imputar com a mediana é mais robusto que a média quando há outliers. Para dados categóricos, usa-se a moda. A remoção de linhas é aceitável apenas quando os dados ausentes são < 5% e a amostra é grande. (II) Outliers: a winsorização (capping ao percentil 1/99) ou o método do IQR (Q1 - 1.5×IQR, Q3 + 1.5×IQR) são técnicas comuns. A decisão de remover depende do contexto — pode ser um erro ou um dado legítimo. (III) Normalização: StandardScaler (z = (x-μ)/σ) é essencial para algoritmos sensíveis à escala (KNN, SVM, redes neurais). Min-Max (x\' = (x-min)/(max-min)) é útil quando a distribuição não é gaussiana.',
    source: 'elaborada',
  },

  // --- CD-004: Visualização: melhores práticas ---
  {
    id: 'BAL-CD-004',
    microarea: 'Ciência de Dados',
    macroarea: 'Segurança/IA',
    element: 'Visualização de dados',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Um analista de dados precisa apresentar a evolução da receita trimestral de uma empresa ao conselho administrativo. Ele considera diferentes tipos de gráficos: gráfico de pizza, gráfico de barras, gráfico de linhas e gráfico de dispersão. Segundo os princípios de Edward Tufte sobre visualização de dados, qual alternativa apresenta a escolha e justificativa mais adequadas?',
    alternatives: [
      {
        letter: 'A',
        text: 'Gráfico de pizza, pois permite mostrar a proporção de cada trimestre em relação ao total, facilitando a comparação visual entre períodos.',
      },
      {
        letter: 'B',
        text: 'Gráfico de linhas, pois é o mais indicado para representar dados contínuos ao longo do tempo, permitindo visualizar tendências, padrões sazonais e mudanças na receita entre trimestres.',
      },
      {
        letter: 'C',
        text: 'Gráfico de dispersão, pois mostra a correlação entre os trimestres e a receita, sendo ideal para dados temporais.',
      },
      {
        letter: 'D',
        text: 'Qualquer tipo de gráfico é adequado, pois a escolha do tipo de visualização é puramente estética e não afeta a interpretação dos dados.',
      },
      {
        letter: 'E',
        text: 'Tabela numérica pura, pois Edward Tufte defende que gráficos são sempre inferiores a tabelas para qualquer tipo de dado.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'Edward Tufte, autor de "The Visual Display of Quantitative Information", estabeleceu princípios fundamentais da visualização: (1) maximizar a "data-ink ratio" (proporção de tinta dedicada a dados vs decoração); (2) escolher o tipo correto de gráfico para o tipo de dado. Para séries temporais (evolução ao longo do tempo), o gráfico de linhas é o mais adequado, pois: mostra continuidade temporal, facilita identificação de tendências, e compara períodos adjacentes. Gráficos de pizza são criticados por Tufte por serem ineficientes na comparação de áreas — o gráfico de barras é quase sempre superior para comparar categorias. Gráficos de dispersão são para correlação entre duas variáveis contínuas.',
    source: 'elaborada',
  },

  // --- CD-005: Storytelling com dados ---
  {
    id: 'BAL-CD-005',
    microarea: 'Ciência de Dados',
    macroarea: 'Segurança/IA',
    element: 'Comunicação de resultados',
    difficulty: 'fácil',
    triA: 1.2,
    triB: -1.0,
    triC: 0.30,
    statement:
      'Uma analista de dados preparou um relatório mostrando que as vendas online da empresa aumentaram 35% no último trimestre, mas o time de marketing argumenta que isso se deve a fatores sazonais e não à nova campanha digital. Para sustentar sua análise, a analista precisa aplicar a técnica de storytelling com dados. Sobre essa prática, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'Storytelling com dados consiste em apresentar todos os dados brutos disponíveis para que o público tire suas próprias conclusões.',
      },
      {
        letter: 'B',
        text: 'Storytelling com dados envolve estruturar uma narrativa com contexto (o que aconteceu), dados de apoio (comparação com períodos anteriores, controle sazonal), visualizações claras e uma conclusão acionável, facilitando a tomada de decisão.',
      },
      {
        letter: 'C',
        text: 'A analista deve ocultar os dados que contradizem sua hipótese para tornar a narrativa mais convincente e evitar debates.',
      },
      {
        letter: 'D',
        text: 'O storytelling com dados é dispensável em ambientes corporativos, pois os gestores estão interessados apenas nos números absolutos.',
      },
      {
        letter: 'E',
        text: 'A melhor prática é utilizar o máximo possível de gráficos 3D e cores vibrantes para chamar a atenção do público.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'Storytelling com dados é a arte de comunicar insights analíticos de forma clara e convincente. Estrutura típica: (1) Contexto — qual é o problema ou pergunta? (2) Dados — evidências que suportam a análise (comparação year-over-year, controle de variáveis de confusão como sazonalidade); (3) Visualização — gráficos que destacam o insight principal; (4) Conclusão — o que significa e o que fazer a respeito. Para o caso da analista, seria fundamental mostrar: (a) comparação com o mesmo trimestre do ano anterior (yoy) para isolar o efeito sazonal; (b) decomposição em tendência + sazonalidade + residual. É antiético omitir dados contraditórios. Gráficos 3D dificultam a leitura (Tufte recomenda "chartjunk" mínimo).',
    source: 'elaborada',
  },

  // --- CD-006: Ferramentas Python: NumPy, Pandas, Scikit-learn, Matplotlib ---
  {
    id: 'BAL-CD-006',
    microarea: 'Ciência de Dados',
    macroarea: 'Segurança/IA',
    element: 'Ferramentas de ciência de dados',
    difficulty: 'fácil',
    triA: 1.2,
    triB: -1.0,
    triC: 0.30,
    statement:
      'Uma equipe de data science precisa construir um pipeline completo de ciência de dados: carregar dados de um CSV, realizar cálculos matriciais eficientes, treinar um modelo de classificação e gerar gráficos. A equipe optou pelo ecossistema Python. Qual associação correta entre as bibliotecas e suas funcionalidades principais?',
    alternatives: [
      {
        letter: 'A',
        text: 'NumPy: treinamento de modelos de machine learning. Pandas: geração de gráficos estatísticos. Scikit-learn: manipulação de arrays multidimensionais. Matplotlib: leitura de arquivos CSV.',
      },
      {
        letter: 'B',
        text: 'NumPy: computação numérica e arrays multidimensionais. Pandas: manipulação e análise de dados tabulares (DataFrames). Scikit-learn: algoritmos de machine learning (classificação, regressão, clustering). Matplotlib: visualização de dados (gráficos 2D).',
      },
      {
        letter: 'C',
        text: 'Todas as quatro bibliotecas realizam as mesmas funções, sendo intercambiáveis em qualquer pipeline de dados.',
      },
      {
        letter: 'D',
        text: 'NumPy é uma biblioteca exclusiva para processamento de linguagem natural, Pandas para visão computacional, Scikit-learn para banco de dados e Matplotlib para redes neurais.',
      },
      {
        letter: 'E',
        text: 'Python não é adequado para ciência de dados; as bibliotecas devem ser utilizadas apenas em linguagens como R ou MATLAB.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'O ecossistema Python de ciência de dados é composto por bibliotecas especializadas: NumPy fornece arrays n-dimensionais eficientes e operações de álgebra linear (produto matricial, inversão, decomposição). Pandas oferece DataFrames (tabelas) com operações de filtragem, agrupamento, junção e agregação, além de leitura/escrita de múltiplos formatos (CSV, JSON, Excel, SQL). Scikit-learn é a principal biblioteca de ML, com algoritmos supervisionados (RandomForest, SVM, KNN) e não supervisionados (K-Means, PCA), além de ferramentas de pré-processamento e avaliação. Matplotlib é a base de visualização, permitindo criar gráficos de linha, barra, dispersão, histogramas e boxplots.',
    source: 'elaborada',
  },

  // --- CD-007: Correlação vs. Causalidade ---
  {
    id: 'BAL-CD-007',
    microarea: 'Ciência de Dados',
    macroarea: 'Segurança/IA',
    element: 'Correlação e causalidade',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Um estudo observacional revelou que cidades com maior número de sorveterias por habitante apresentam também maior número de afogamentos. O coeficiente de correlação de Pearson entre essas duas variáveis foi r = 0,85 (forte correlação positiva). Um jornalista publicou a manchete: "Sorveterias causam afogamentos!" Sobre a relação entre correlação e causalidade, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'A manchete está correta, pois uma correlação de 0,85 é forte o suficiente para estabelecer causalidade direta entre sorveterias e afogamentos.',
      },
      {
        letter: 'B',
        text: 'Correlação não implica causalidade. É provável que ambas as variáveis sejam causadas por uma variável confundidora (confounder): a temperatura alta no verão aumenta tanto o consumo de sorvete quanto a frequência de idas à praia/piscina.',
      },
      {
        letter: 'C',
        text: 'A correlação de 0,85 indica uma relação espúria causada exclusivamente por erros de medição nos dados coletados.',
      },
      {
        letter: 'D',
        text: 'Correlação e causalidade são conceitos idênticos em estatística, diferindo apenas na nomenclatura utilizada.',
      },
      {
        letter: 'E',
        text: 'Para estabelecer causalidade, basta que a correlação seja maior que 0,90, o que não foi atingido neste estudo.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'O princípio "correlação não implica causalidade" é fundamental em ciência de dados e estatística. Neste exemplo clássico, a variável confundidora (temperatura/estação do ano) causa ambas: (1) mais calor → mais consumo de sorvete; (2) mais calor → mais pessoas na praia → mais afogamentos. Para estabelecer causalidade, são necessários: (a) ensaios clínicos randomizados (experimentos controlados); (b) controle de variáveis de confusão; (c) verificação dos critérios de Bradford Hill (força, consistência, especificidade, temporalidade, gradiente biológico, plausibilidade, evidência experimental). O coeficiente de Pearson mede apenas a associação linear entre variáveis (r ∈ [-1, 1]), sem qualquer informação sobre direção causal.',
    source: 'elaborada',
  },

  // =============================================================================
  // ÉTICA PROFISSIONAL (7 questions) — BAL-ETI-001 a BAL-ETI-007
  // =============================================================================

  // --- ETI-001: LGPD: direitos dos titulares, bases legais ---
  {
    id: 'BAL-ETI-001',
    microarea: 'Ética Profissional',
    macroarea: 'Segurança/IA',
    element: 'LGPD',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Uma startup de saúde coleta dados de pacientes para um aplicativo de telemedicina, incluindo histórico médico, CPF, e-mail e geolocalização. O CTO da empresa precisa garantir conformidade com a Lei Geral de Proteção de Dados (LGPD — Lei 13.709/2018). Sobre as bases legais e os direitos dos titulares previstos na LGPD, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'A LGPD permite o tratamento de dados de saúde sem nenhuma base legal especial, pois dados de saúde são considerados dados públicos.',
      },
      {
        letter: 'B',
        text: 'Dados de saúde são considerados dados sensíveis pela LGPD, exigindo consentimento explícito do titular ou outra base legal específica (ex: tutela da saúde). O titular tem direito à confirmação da existência de tratamento, acesso aos dados, correção, anonimização, portabilidade e eliminação.',
      },
      {
        letter: 'C',
        text: 'A LGPD aplica-se apenas a empresas com mais de 500 funcionários, não atingindo startups de saúde de pequeno porte.',
      },
      {
        letter: 'D',
        text: 'O consentimento é a única base legal prevista na LGPD para o tratamento de qualquer tipo de dado pessoal.',
      },
      {
        letter: 'E',
        text: 'A LGPD não prevê o direito de portabilidade de dados, sendo esse direito exclusivo do GDPR europeu.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'A LGPD classifica dados sensíveis (art. 11) como dados sobre origem racial/étnica, convicção religiosa, opinião política, filiação sindical, dados de saúde, vida sexual e genética. O tratamento desses dados requer: consentimento do titular ou hipóteses específicas (tutela da saúde pelo profissional de saúde, proteção da vida, interesse legítimo). Bases legais da LGPD (art. 7): consentimento, obrigação legal, políticas públicas, pesquisa, contrato, exercício regular de direitos, proteção da vida, tutela da saúde, interesse legítimo, proteção do crédito. Direitos do titular (art. 18): confirmação, acesso, correção, anonimização, portabilidade, eliminação, informação sobre compartilhamento, revogação do consentimento.',
    source: 'elaborada',
  },

  // --- ETI-002: Marco Civil da Internet ---
  {
    id: 'BAL-ETI-002',
    microarea: 'Ética Profissional',
    macroarea: 'Segurança/IA',
    element: 'Marco Civil da Internet',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Um provedor de acesso à internet está considerando implementar um sistema que priorize a velocidade de conexão para serviços de streaming parceiros em detrimento de serviços concorrentes. Sobre o Marco Civil da Internet (Lei 12.965/2014) e seus princípios, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'O Marco Civil da Internet permite a discriminação de tráfego por conteúdo, pois as empresas têm liberdade comercial para definir prioridades de banda.',
      },
      {
        letter: 'B',
        text: 'O Marco Civil da Internet estabelece o princípio da neutralidade de rede, vedando a discriminação degradante do tráfego de dados por motivos comerciais, e garante direitos como proteção da privacidade, liberdade de expressão e preservação da natureza participativa da internet.',
      },
      {
        letter: 'C',
        text: 'O Marco Civil da Internet regulamenta apenas questões tributárias de comércio eletrônico, sem qualquer impacto em questões técnicas de rede.',
      },
      {
        letter: 'D',
        text: 'A neutralidade de rede é um conceito opcional no Brasil, sendo aplicável apenas a provedores governamentais.',
      },
      {
        letter: 'E',
        text: 'O Marco Civil da Internet permite que provedores bloqueiem acessos a sites sem ordem judicial, desde que haja suspeita de atividade ilícita.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'O Marco Civil da Internet (Lei 12.965/2014), conhecido como "Constituição da Internet brasileira", estabelece princípios fundamentais: (1) neutralidade de rede — proibição de discriminação de tráfego por conteúdo, origem/destino, serviço ou aplicação (provedores não podem priorizar ou bloquear serviços); (2) proteção da privacidade e dados pessoais; (3) liberdade de expressão; (4) preservação do caráter participativo e descentralizado; (5) acessibilidade; (6) diversidade cultural. O bloqueio de conteúdo só é permitido por ordem judicial. A Lei também garante direitos como manutenção do contrato, inviolabilidade da intimidade e sigilo das comunicações (com exceções legais).',
    source: 'elaborada',
  },

  // --- ETI-003: Responsabilidade civil do profissional de TI ---
  {
    id: 'BAL-ETI-003',
    microarea: 'Ética Profissional',
    macroarea: 'Segurança/IA',
    element: 'Responsabilidade profissional',
    difficulty: 'fácil',
    triA: 1.2,
    triB: -1.0,
    triC: 0.30,
    statement:
      'Um desenvolvedor de software foi contratado para desenvolver um sistema de gestão financeira para uma empresa. Durante o desenvolvimento, ele percebeu que o sistema não implementa controles adequados de acesso, permitindo que qualquer funcionário visualize o salário de todos os colegas. No entanto, o gerente do projeto solicitou que o sistema fosse entregue sem alterações para cumprir o prazo. Sobre a responsabilidade ética e profissional do desenvolvedor, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'O desenvolvedor deve seguir a ordem do gerente sem questionar, pois a responsabilidade profissional é exclusivamente do gestor do projeto.',
      },
      {
        letter: 'B',
        text: 'O desenvolvedor deve documentar formalmente o risco de segurança identificado, comunicar à alta gestão e ao cliente, e recusar-se a entregar um sistema com vulnerabilidade conhecida que possa causar danos a terceiros, pois sua responsabilidade ética prevalece sobre prazos comerciais.',
      },
      {
        letter: 'C',
        text: 'A responsabilidade do desenvolvedor se limita a escrever código funcional, sem qualquer obrigação ética em relação à segurança dos dados processados.',
      },
      {
        letter: 'D',
        text: 'O desenvolvedor deve resolver o problema silenciosamente após a entrega, sem informar ninguém, para evitar conflitos com a gerência.',
      },
      {
        letter: 'E',
        text: 'O Código de Ética do profissional de TI não se aplica a desenvolvedores de software, sendo restrito a profissionais de rede e infraestrutura.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'O profissional de TI possui responsabilidade ética e civil sobre os sistemas que desenvolve. O Código de Ética dos Profissionais de TI (CRC, CRA, SBC) estabelece que o profissional deve: (1) atuar com responsabilidade social; (2) garantir a qualidade e segurança dos sistemas; (3) proteger dados sigilosos; (4) comunicar riscos conhecidos. No caso descrito, o sistema apresenta falha grave de segurança (violação do princípio do menor privilégio), com potencial dano a terceiros (exposição de dados salariais). O profissional deve documentar o risco, comunicar formalmente e recusar a entrega insegura. A jurisprudência brasileira reconhece a responsabilidade civil objetiva em casos de falha de segurança informática que cause danos.',
    source: 'elaborada',
  },

  // --- ETI-004: Conflitos de interesse no desenvolvimento de software ---
  {
    id: 'BAL-ETI-004',
    microarea: 'Ética Profissional',
    macroarea: 'Segurança/IA',
    element: 'Conflitos de interesse',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Uma engenheira de software líder de uma equipe está avaliando propostas de fornecedores para um projeto de migração em nuvem. Uma das empresas concorrentes é de um parente próximo dela. Ao mesmo tempo, ela possui ações de outra empresa concorrente. Sobre a gestão de conflitos de interesse no contexto profissional de TI, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'Conflitos de interesse são inevitáveis e não precisam ser declarados, pois fazem parte da dinâmica natural do mercado de tecnologia.',
      },
      {
        letter: 'B',
        text: 'A engenheira deve declarar formalmente todos os vínculos e interesses que possam influenciar sua imparcialidade (parentesco com fornecedor, posse de ações em concorrente) e solicitar ser excluída do processo decisório, garantindo transparência e evitando decisões enviesadas.',
      },
      {
        letter: 'C',
        text: 'É suficiente que a engenheira garanta subjetivamente que seus vínculos não influenciarão sua decisão, sem necessidade de declarar nada formalmente.',
      },
      {
        letter: 'D',
        text: 'A posse de ações em empresas de tecnologia nunca constitui conflito de interesse, pois é um direito de qualquer investidor.',
      },
      {
        letter: 'E',
        text: 'Conflitos de interesse só precisam ser declarados se a empresa tiver mais de 100 funcionários, conforme regulamentação do MTE.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'Conflitos de interesse ocorrem quando interesses pessoais (financeiros, familiares, profissionais) podem comprometer a objetividade e imparcialidade de decisões profissionais. Princípios éticos exigem: (1) transparência — declarar formalmente todos os vínculos relevantes; (2) abstenção — recusar-se a participar de decisões onde há conflito; (3) documentação — registrar a declaração por escrito. Em governança corporativa de TI, códigos de conduta e compliance exigem que conflitos sejam comunicados ao comitê de ética ou ao superior hierárquico imediato. A omissão de conflitos pode configurar infração ética e até ilícito civil. Boas práticas de governança (COBIT, ISO 37001) incluem políticas formais de gestão de conflitos.',
    source: 'elaborada',
  },

  // --- ETI-005: Governança de TI: frameworks (COBIT, ITIL, ISO 27001) ---
  {
    id: 'BAL-ETI-005',
    microarea: 'Ética Profissional',
    macroarea: 'Segurança/IA',
    element: 'Governança de TI',
    difficulty: 'difícil',
    triA: 2.2,
    triB: 0.8,
    triC: 0.12,
    statement:
      'Uma organização está implementando um programa de governança de TI e precisa escolher entre diferentes frameworks para atender suas necessidades. A equipe identificou três frameworks principais: COBIT, ITIL e ISO 27001. Sobre a finalidade e o escopo de cada framework, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'O COBIT é voltado exclusivamente para gerenciamento de serviços de TI, o ITIL para segurança da informação e a ISO 27001 para governança corporativa de TI.',
      },
      {
        letter: 'B',
        text: 'COBIT, ITIL e ISO 27001 são frameworks idênticos que podem ser usados de forma intercambiável sem diferenças significativas.',
      },
      {
        letter: 'C',
        text: 'O COBIT foca em governança e gestão de TI (alinhamento estratégico entre TI e negócio, entrega de valor, gerenciamento de riscos), o ITIL foca em gerenciamento de serviços de TI (catálogo de serviços, incidentes, problemas, mudanças), e a ISO 27001 foca em segurança da informação (gestão de riscos de segurança, controles, compliance).',
      },
      {
        letter: 'D',
        text: 'A ISO 27001 é um framework de gestão de projetos, substituindo o PMBOK em projetos de tecnologia.',
      },
      {
        letter: 'E',
        text: 'O ITIL substituiu completamente o COBIT, sendo o framework mais abrangente para todas as áreas de governança de TI.',
      },
    ],
    correctAnswer: 'C',
    explanation:
      'Os três frameworks são complementares: (1) COBIT (Control Objectives for Information and Related Technologies) — foco em governança de TI: alinhamento entre TI e estratégia de negócio, entrega de valor, gerenciamento de riscos de TI, medição de desempenho. Define 40 objetivos de controle. (2) ITIL (Information Technology Infrastructure Library) — foco em gerenciamento de serviços de TI (ITSM): gestão de incidentes, problemas, mudanças, configuração, catálogo de serviços, SLAs. Define práticas para operação e entrega de serviços. (3) ISO/IEC 27001 — foco em segurança da informação: Sistema de Gestão de Segurança da Informação (SGSI), análise de riscos, controles (ISO 27002), compliance legal. São complementares e frequentemente usados em conjunto.',
    source: 'elaborada',
  },

  // --- ETI-006: Sustentabilidade em TI (green computing, e-waste) ---
  {
    id: 'BAL-ETI-006',
    microarea: 'Ética Profissional',
    macroarea: 'Segurança/IA',
    element: 'Sustentabilidade em TI',
    difficulty: 'fácil',
    triA: 1.2,
    triB: -1.0,
    triC: 0.30,
    statement:
      'Uma empresa de tecnologia está buscando reduzir o impacto ambiental de suas operações de TI. A equipe identificou que o data center consome grande quantidade de energia elétrica e que equipamentos obsoletos são descartados de forma inadequada. Sobre as práticas de TI verde (Green Computing/TCO) e descarte responsável de e-waste, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'O descarte de equipamentos eletrônicos no lixo comum não apresenta riscos ambientais, pois componentes eletrônicos são biodegradáveis.',
      },
      {
        letter: 'B',
        text: 'Práticas de TI verde incluem virtualização de servidores (consolidar múltiplas VMs em menos servidores físicos), otimização de cooling em data centers (ex: free cooling, hot aisle/cold aisle), uso de fontes de energia renovável, e descarte responsável de e-waste por meio de reciclagem certificada.',
      },
      {
        letter: 'C',
        text: 'O consumo de energia de data centers é insignificante em comparação ao consumo residencial, não justificando investimentos em eficiência energética.',
      },
      {
        letter: 'D',
        text: 'A legislação brasileira (PNRS — Política Nacional de Resíduos Sólidos) não se aplica a equipamentos de TI, que podem ser descartados como lixo comum.',
      },
      {
        letter: 'E',
        text: 'A virtualização de servidores aumenta o consumo de energia, pois cada máquina virtual requer recursos extras de hardware.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'Green Computing visa reduzir o impacto ambiental das operações de TI. Data centers consomem aproximadamente 1-2% da eletricidade global. Práticas principais: (1) Virtualização — consolidar servidores (taxa de utilização média de servidores físicos: 5-15%; com virtualização: 60-80%), reduzindo hardware, energia e espaço; (2) Eficiência energética — PUE (Power Usage Effectiveness) como métrica; free cooling, monitoramento inteligente; (3) E-waste — a Política Nacional de Resíduos Sólidos (Lei 12.305/2010) estabelece logística reversa obrigatória para eletroeletrônicos; descarte em lixões contamina solo e água com metais pesados (chumbo, mercúrio, cádmio); (4) Cloud computing — compartilhamento de recursos reduz consumo per user; (5) Procurement verde — preferência por equipamentos com certificação Energy Star e TCO.',
    source: 'elaborada',
  },

  // --- ETI-007: Propriedade intelectual: direitos autorais, patentes, marcas ---
  {
    id: 'BAL-ETI-007',
    microarea: 'Ética Profissional',
    macroarea: 'Segurança/IA',
    element: 'Propriedade intelectual',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Um desenvolvedor independente criou uma biblioteca de software inovadora para compressão de dados e quer protegê-la contra uso não autorizado. Ele também criou um logotipo para sua empresa e desenvolveu um algoritmo revolucionário que gostaria de patentear. Sobre as formas de proteção da propriedade intelectual aplicáveis (direitos autorais, patentes, marcas), é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'O código-fonte da biblioteca pode ser protegido por patente, o logotipo por direitos autorais e o algoritmo por registro de marca no INPI.',
      },
      {
        letter: 'B',
        text: 'O código-fonte da biblioteca é protegido automaticamente por direitos autorais (Lei 9.610/98), o logotipo pode ser registrado como marca no INPI (Lei 9.279/96 — LPI), e o algoritmo pode ser patenteado se atender aos requisitos de novidade, atividade inventiva e aplicação industrial.',
      },
      {
        letter: 'C',
        text: 'Software não pode ser protegido por nenhuma forma de propriedade intelectual no Brasil, sendo considerado de domínio público por lei.',
      },
      {
        letter: 'D',
        text: 'A proteção por direitos autorais exige registro prévio no INPI, sem o qual o código-fonte pode ser copiado livremente.',
      },
      {
        letter: 'E',
        text: 'Algoritmos nunca podem ser patenteados em nenhum país, pois são considerados abstratos por natureza.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'A proteção da propriedade intelectual em TI no Brasil envolve: (1) Direitos Autorais (Lei 9.610/98) — protegem automaticamente o código-fonte e a obra literária/artística do software; não exigem registro (mas o registro na Biblioteca Nacional facilita a comprovação); vigência: vida do autor + 70 anos. (2) Marca (LPI — Lei 9.279/96, arts. 122-129) — o logotipo pode ser registrado como marca nominativa ou figurativa no INPI; protege contra uso por terceiros em contexto comercial. (3) Patente (LPI, arts. 8-42) — algoritmos puros não são patenteáveis no Brasil (art. 10, V), mas a inovação técnica que implementa o algoritmo em um contexto de aplicação industrial pode ser patenteada. Exceção: nos EUA, algoritmos integrados a processos técnicos podem ser patenteados (ex: Amazon One-Click). Software como um todo não é patenteável no Brasil.',
    source: 'elaborada',
  },

  // =============================================================================
  // LEGISLAÇÃO (7 questions) — BAL-LEG-001 a BAL-LEG-007
  // =============================================================================

  // --- LEG-001: GDPR vs LGPD: comparação e implicações ---
  {
    id: 'BAL-LEG-001',
    microarea: 'Legislação',
    macroarea: 'Segurança/IA',
    element: 'GDPR e LGPD',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Uma multinacional brasileira com sede em São Paulo coleta dados de clientes europeus para seu serviço de e-commerce. O DPO (Data Protection Officer) precisa garantir conformidade tanto com o GDPR europeu (Regulamento Geral de Proteção de Dados — Regulamento UE 2016/679) quanto com a LGPD brasileira (Lei 13.709/2018). Sobre a comparação entre essas legislações, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'O GDPR e a LGPD são completamente incompatíveis, exigindo sistemas de tratamento de dados completamente separados para cada jurisdição.',
      },
      {
        letter: 'B',
        text: 'O GDPR é aplicável apenas a empresas europeias, não afetando empresas brasileiras que coletam dados de cidadãos europeus.',
      },
      {
        letter: 'C',
        text: 'Ambas as legislações compartilham princípios semelhantes (consentimento, finalidade, minimização, transparência, direitos do titular), mas diferem em multas (GDPR: até €20 milhões ou 4% do faturamento global; LGPD: até 2% do faturamento no Brasil, limitado a R$ 50 milhões por infração) e em alguns requisitos específicos como o DPO.',
      },
      {
        letter: 'D',
        text: 'A LGPD é uma cópia exata do GDPR, sem qualquer diferença em relação a multas, isenções ou requisitos de compliance.',
      },
      {
        letter: 'E',
        text: 'O GDPR não prevê direitos do titular de dados, sendo uma legislação focada exclusivamente na proteção de segredos comerciais.',
      },
    ],
    correctAnswer: 'C',
    explanation:
      'GDPR e LGPD compartilham princípios comuns (ambas baseadas nos princípios da OCDE de 1980): consentimento, finalidade, minimização, precisão, limitação de armazenamento, integridade e confidencialidade. Diferenças principais: (1) Multas: GDPR prevê até €20M ou 4% do faturamento global; LGPD prevê até 2% do faturamento no Brasil, limitado a R$ 50M por infração. (2) Extraterritorialidade: ambas se aplicam a empresas que processam dados de cidadãos do respectivo bloco, mesmo sem sede local. (3) DPO: GDPR exige DPO em certas condições; LGPD exige "encarregado" (papel similar). (4) LGPD prevê Autoridade Nacional de Proteção de Dados (ANPD). (5) GDPR entrou em vigor em 2018; LGPD em 2020 (aplicação sancionatória a partir de 2021). Empresas que operam globalmente precisam de compliance com ambas.',
    source: 'elaborada',
  },

  // --- LEG-002: Crimes cibernéticos (Lei Carolina Dieckmann e Lei 12.737/2012) ---
  {
    id: 'BAL-LEG-002',
    microarea: 'Legislação',
    macroarea: 'Segurança/IA',
    element: 'Crimes cibernéticos',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Um hacker obteve acesso não autorizado ao servidor de uma empresa e copiou o banco de dados contendo informações confidenciais de clientes, incluindo CPFs e dados bancários. Considerando a legislação brasileira sobre crimes cibernéticos, qual afirmação é correta?',
    alternatives: [
      {
        letter: 'A',
        text: 'O hacker não cometeu crime, pois a invasão de servidores não é tipificada como conduta ilícita no Código Penal Brasileiro.',
      },
      {
        letter: 'B',
        text: 'A Lei Carolina Dieckmann (Lei 12.737/2012, também conhecida como Lei Azeredo) tipifica o crime de invasão de dispositivo informático (art. 154-A do CP) com pena de 3 meses a 1 ano de detenção, e a conduta pode ser qualificada com penas maiores se houver obtenção, transferência ou divulgação de dados sem autorização.',
      },
      {
        letter: 'C',
        text: 'A Lei Carolina Dieckmann se aplica exclusivamente a crimes contra mulheres, tratando de violência doméstica digital.',
      },
      {
        letter: 'D',
        text: 'Apenas o funcionário da empresa que deixou o servidor vulnerável pode ser responsabilizado criminalmente, pois a legislação isenta o invasor.',
      },
      {
        letter: 'E',
        text: 'O crime de invasão de dispositivo informático é considerado de menor potencial ofensivo e não permite prisão em flagrante.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'A Lei 12.737/2012 (Lei Carolina Dieckmann) introduziu o art. 154-A no Código Penal, tipificando o crime de "invasão de dispositivo informático": invadir com violação de segurança para obter, adulterar ou destruir dados. Pena base: 3 meses a 1 ano de detenção e multa. Causas de aumento de pena (§§ 2º-6º): (1) se houver obtenção de dados sigilosos sem autorização: 6 meses a 2 anos; (2) se houver prejuízo econômico: 1 a 3 anos; (3) se houver divulgação, comercialização ou transmissão a terceiros: 1 a 4 anos. A lei também tipificou: inserção de código malicioso (art. 154-B), interrupção ou perturbação de serviço informático (art. 154-C), e falsificação de dados (art. 299 do CP).',
    source: 'elaborada',
  },

  // --- LEG-003: Contratos de TI e cláusulas de confidencialidade (NDA) ---
  {
    id: 'BAL-LEG-003',
    microarea: 'Legislação',
    macroarea: 'Segurança/IA',
    element: 'Contratos de TI',
    difficulty: 'fácil',
    triA: 1.2,
    triB: -1.0,
    triC: 0.30,
    statement:
      'Uma empresa de desenvolvimento de software está contratando um freelancer para trabalhar em um projeto confidencial de inteligência artificial. A empresa exige que o freelancer assine um Acordo de Não Divulgação (NDA — Non-Disclosure Agreement). Sobre os elementos essenciais de um NDA e sua validade jurídica no Brasil, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'Um NDA não tem validade jurídica no Brasil, pois a confidencialidade é garantida automaticamente pelo Código Civil sem necessidade de contrato.',
      },
      {
        letter: 'B',
        text: 'Um NDA deve definir claramente: as partes envolvidas, o escopo das informações confidenciais, as obrigações de não divulgação e não uso, as exceções (informações já públicas, obtidas de terceiros, exigidas por lei), a duração do acordo e as penalidades por descumprimento, sendo válido segundo o Código Civil como contrato bilateral.',
      },
      {
        letter: 'C',
        text: 'O NDA protege apenas informações escritas, não se aplicando a código-fonte, algoritmos ou ideias discutidas verbalmente.',
      },
      {
        letter: 'D',
        text: 'A assinatura de um NDA transfere automaticamente a propriedade intelectual do freelancer para a empresa contratante.',
      },
      {
        letter: 'E',
        text: 'NDAs são válidos apenas por 30 dias, sendo automaticamente renováveis apenas por decisão judicial.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'Um NDA (Non-Disclosure Agreement) é um contrato regido pelo Código Civil brasileiro (arts. 421-428, princípio da autonomia da vontade). Elementos essenciais: (1) Qualificação das partes; (2) Definição clara do que é confidencial (dados técnicos, comerciais, estratégicos); (3) Obrigações: não divulgar, não copiar, não utilizar para outros fins; (4) Exceções: informações do domínio público, obtidas legalmente de terceiros, exigidas por lei ou ordem judicial; (5) Prazo de vigência (comum: 2-5 anos, podendo ser mais longo para segredos comerciais); (6) Penalidades: multa, indenização, execução específica. O NDA NÃO transfere propriedade intelectual — para isso é necessário um contrato de cessão ou trabalho. Aplica-se a informações orais e escritas.',
    source: 'elaborada',
  },

  // --- LEG-004: Lei de Software (Lei 9.609/98) detalhada ---
  {
    id: 'BAL-LEG-004',
    microarea: 'Legislação',
    macroarea: 'Segurança/IA',
    element: 'Lei de Software',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Uma empresa desenvolvedora de software está planejando registrar seu programa como "software de mercado" para obter os benefícios fiscais previstos na Lei de Software (Lei 9.609/1998). Sobre os requisitos e benefícios dessa lei, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'A Lei 9.609/98 estabelece que todo software desenvolvido no Brasil é automaticamente de domínio público, não sendo possível sua comercialização com exclusividade.',
      },
      {
        letter: 'B',
        text: 'A Lei 9.609/98 permite que o software comercializado no Brasil receba tratamento especial, mas exige que o desenvolvedor ou empresa esteja sediado no país e que o software seja registrado no INPI, sendo que as empresas que atendem aos requisitos podem ter redução do IPI e isenção de COFINS sobre receita de exportação.',
      },
      {
        letter: 'C',
        text: 'A Lei de Software aplica-se apenas a jogos eletrônicos, não cobrindo sistemas corporativos, aplicativos móveis ou software de infraestrutura.',
      },
      {
        letter: 'D',
        text: 'O registro no INPI é opcional e não gera nenhum benefício legal ou fiscal para a empresa desenvolvedora.',
      },
      {
        letter: 'E',
        text: 'A Lei 9.609/98 proíbe a distribuição de software livre (open source) no território brasileiro.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'A Lei de Software (Lei 9.609/1998, regulamentada pelo Decreto 2.556/1998) dispõe sobre a proteção de propriedade intelectual de programa de computador e sua comercialização no país. Principais pontos: (1) O programa de computador é protegido pelos direitos autorais (não por patente). (2) O registro no INPI é facultativo, mas necessário para comprovação em processos judiciais e para obtenção de incentivos fiscais. (3) Benefícios: empresas sediadas no Brasil que registram software e atendem requisitos técnicos podem obter redução de IPI (50% a 80%) sobre hardware produzido no país e isenção de COFINS sobre a receita de exportação de software. (4) O contrato de licenciamento deve ter prazo máximo de 5 anos para prazos indeterminados. (5) Software livre/open source é perfeitamente legal e protegido.',
    source: 'elaborada',
  },

  // --- LEG-005: Compliance e auditoria: SOC 2, PCI-DSS ---
  {
    id: 'BAL-LEG-005',
    microarea: 'Legislação',
    macroarea: 'Segurança/IA',
    element: 'Compliance e auditoria',
    difficulty: 'difícil',
    triA: 2.2,
    triB: 0.8,
    triC: 0.12,
    statement:
      'Uma fintech que processa pagamentos com cartão de crédito precisa demonstrar conformidade com diferentes padrões de compliance e segurança para seus parceiros comerciais. A equipe de segurança está avaliando os padrões SOC 2 Type II e PCI-DSS. Sobre esses padrões, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'O SOC 2 e o PCI-DSS são equivalentes e intercambiáveis, sendo suficiente obter apenas um dos dois para demonstrar conformidade total.',
      },
      {
        letter: 'B',
        text: 'O SOC 2 Type II avalia controles de segurança, disponibilidade, integridade, confidencialidade e privacidade ao longo de um período (geralmente 6-12 meses), enquanto o PCI-DSS foca especificamente na proteção de dados de cartões de pagamento, exigindo 12 requisitos como criptografia, controle de acesso, testes de segurança e monitoramento.',
      },
      {
        letter: 'C',
        text: 'O PCI-DSS é aplicável exclusivamente a bancos, não se estendendo a fintechs ou empresas de e-commerce que processam pagamentos.',
      },
      {
        letter: 'D',
        text: 'O SOC 2 é um padrão governamental brasileiro, equivalente à ISO 27001, e não é reconhecido internacionalmente.',
      },
      {
        letter: 'E',
        text: 'Uma empresa que está em conformidade com o PCI-DSS está automaticamente em conformidade com o SOC 2, sem necessidade de auditoria adicional.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'SOC 2 (System and Organization Controls 2) é um framework de auditoria desenvolvido pela AICPA (americana). Type I avalia controles em um ponto no tempo; Type II avalia a operação efetiva dos controles ao longo de um período (6-12 meses). Os 5 Trust Services Criteria: segurança, disponibilidade, integridade de processamento, confidencialidade, privacidade. PCI-DSS (Payment Card Industry Data Security Standard) é mantido pelo PCI Security Standards Council. Exige 12 requisitos: firewall, configuração segura, proteção de dados armazenados, criptografia em trânsito, antivírus, acesso restrito por necessidade, identificação única, acesso físico restrito, monitoramento, testes de segurança, política de segurança. Diferenças: SOC 2 é amplo (qualquer serviço de nuvem/SaaS); PCI-DSS é específico para dados de cartão. São complementares, não substitutivos.',
    source: 'elaborada',
  },

  // --- LEG-006: ISO 27001 vs 27002: gestão vs controles ---
  {
    id: 'BAL-LEG-006',
    microarea: 'Legislação',
    macroarea: 'Segurança/IA',
    element: 'Normas ISO de segurança',
    difficulty: 'médio',
    triA: 1.7,
    triB: 0.0,
    triC: 0.20,
    statement:
      'Uma empresa está planejando implementar um Sistema de Gestão de Segurança da Informação (SGSI) e precisa entender a diferença entre as normas ISO/IEC 27001 e ISO/IEC 27002. A diretoria perguntou ao CISO qual norma deve ser adotada para obter certificação. Sobre a relação entre essas normas, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'A ISO 27001 é um guia de melhores práticas sem requisitos obrigatórios, enquanto a ISO 27002 é a norma certificável.',
      },
      {
        letter: 'B',
        text: 'A ISO 27001 define os requisitos para estabelecer, implementar, manter e melhorar um SGSI (sendo a norma certificável por auditoria externa), enquanto a ISO 27002 fornece diretrizes e boas práticas para a implementação dos controles de segurança listados no Anexo A da 27001.',
      },
      {
        letter: 'C',
        text: 'Ambas as normas são idênticas em conteúdo, diferindo apenas no número da norma para atender a mercados diferentes (27001 para Europa, 27002 para América).',
      },
      {
        letter: 'D',
        text: 'A ISO 27002 substituiu a ISO 27001 em 2013, tornando-a obsoleta e sem validade para certificação.',
      },
      {
        letter: 'E',
        text: 'A ISO 27001 se aplica apenas a empresas de tecnologia, enquanto a ISO 27002 se aplica a qualquer setor da economia.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'ISO/IEC 27001:2013 é a norma certificável que define requisitos para implementar um SGSI: contexto da organização, liderança, planejamento, suporte, operação, avaliação de desempenho e melhoria. Inclui o Anexo A com 114 controles organizados em 14 domínios. A certificação é concedida por organismos acreditados (ex: BSI, TÜV) após auditoria. ISO/IEC 27002:2013 (antiga ISO 17799) é um guia de boas práticas não certificável que detalha como implementar cada controle do Anexo A da 27001. A 27002 funciona como um "manual de instruções" para atender aos requisitos da 27001. Analogia: ISO 27001 é o "exame" (certificável), ISO 27002 é o "livro didático" (orientações). Ambas se aplicam a qualquer organização.',
    source: 'elaborada',
  },

  // --- LEG-007: Regulamentação internacional: GDPR, CCPA, LGPD ---
  {
    id: 'BAL-LEG-007',
    microarea: 'Legislação',
    macroarea: 'Segurança/IA',
    element: 'Regulamentação internacional de privacidade',
    difficulty: 'difícil',
    triA: 2.2,
    triB: 0.8,
    triC: 0.12,
    statement:
      'Uma empresa global de tecnologia coleta dados pessoais de usuários na União Europeia, na Califórnia (EUA) e no Brasil. Para operar em conformidade, a empresa precisa atender a três regulamentações simultaneamente: GDPR, CCPA e LGPD. Sobre a comparação dessas regulamentações, é correto afirmar que:',
    alternatives: [
      {
        letter: 'A',
        text: 'A CCPA (California Consumer Privacy Act) é idêntica ao GDPR em todos os seus aspectos, exigindo exatamente os mesmos direitos e procedimentos.',
      },
      {
        letter: 'B',
        text: 'O GDPR adota a abordagem de "opt-in" (consentimento prévio explícito) como regra geral, a CCPA adota "opt-out" (os dados podem ser coletados por padrão, mas o usuário pode solicitar a exclusão), e a LGPD se posiciona mais próxima do GDPR com abordagem baseada em consentimento e bases legais, mas com multas menores.',
      },
      {
        letter: 'C',
        text: 'A LGPD não possui qualquer mecanismo de transferência internacional de dados, tornando impossível para empresas brasileiras enviar dados para servidores no exterior.',
      },
      {
        letter: 'D',
        text: 'A CCPA se aplica exclusivamente a empresas californianas com menos de 50 funcionários, não afetando grandes corporações de tecnologia.',
      },
      {
        letter: 'E',
        text: 'Nenhuma das três regulamentações possui extraterritorialidade, aplicando-se apenas a empresas sediadas em seus respectivos territórios.',
      },
    ],
    correctAnswer: 'B',
    explanation:
      'Três principais regulamentações globais de privacidade: (1) GDPR (UE, 2018) — abordagem "opt-in" (consentimento explícito prévio); multas até €20M ou 4% faturamento; 8 direitos do titular; DPO obrigatório em certos casos; transferência internacional requer adequação ou cláusulas contratuais padrão; extraterritorial: aplica-se a qualquer organização que processe dados de residentes da UE. (2) CCPA (Califórnia, 2020) — abordagem "opt-out" (coleta permitida por padrão, usuário pode recusar); direito de saber, excluir e opt-out de venda; aplica-se a empresas com >$25M receita ou 50k+ consumidores ou >50% receita de venda de dados. (3) LGPD (Brasil, 2020) — inspirada no GDPR; bases legais amplas; ANPD como autoridade reguladora; multas até 2% faturamento no Brasil (R$50M/infração); transferência internacional exige adequação. Empresas globais precisam de compliance multi-jurisdição.',
    source: 'elaborada',
  },
];
