import { NextRequest } from 'next/server';
import { prisma } from '@/lib/db';
import { requireAuth, requireRole, jsonResponse, errorResponse } from '@/lib/auth-middleware';
import { Role, SimuladoType } from '@prisma/client';

export async function GET(request: NextRequest) {
  try {
    requireAuth(request);

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') as SimuladoType | null;
    const active = searchParams.get('active');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const where: Record<string, unknown> = {};
    if (type) where.type = type;
    if (active !== null && active !== undefined) {
      where.active = active === 'true';
    }

    const [simulados, total] = await Promise.all([
      prisma.simulado.findMany({
        where,
        include: {
          _count: {
            select: {
              configs: true,
              responses: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.simulado.count({ where }),
    ]);

    return jsonResponse({
      simulados,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('List simulados error:', error);
    if (error instanceof Error && error.message.includes('Não autenticado')) {
      return errorResponse(error.message, 401);
    }
    return errorResponse('Erro interno do servidor.', 500);
  }
}

export async function POST(request: NextRequest) {
  try {
    requireRole(request, Role.PROFESSOR, Role.MASTER);

    const body = await request.json();
    const { title, description, type, phase, timeLimit, questionCount, active, questionIds } = body;

    if (!title) {
      return errorResponse('O título do simulado é obrigatório.', 400);
    }

    const simulado = await prisma.simulado.create({
      data: {
        title,
        description: description || null,
        type: type || 'LIVRE',
        phase: phase || null,
        timeLimit: timeLimit || null,
        questionCount: questionCount || 10,
        active: active !== undefined ? active : true,
        configs: questionIds?.length
          ? {
              create: questionIds.map((qid: string, idx: number) => ({
                questionId: qid,
                order: idx,
              })),
            }
          : undefined,
      },
      include: { configs: true },
    });

    return jsonResponse({ simulado }, 201);
  } catch (error) {
    console.error('Create simulado error:', error);
    if (error instanceof Error && (error.message.includes('Não autenticado') || error.message.includes('Acesso negado'))) {
      return errorResponse(error.message, error.message.includes('Não autenticado') ? 401 : 403);
    }
    return errorResponse('Erro interno do servidor.', 500);
  }
}
