import { NextRequest } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { jsonResponse, errorResponse } from '@/lib/auth-middleware';

export async function GET() {
  try {
    // Create a fresh PrismaClient to test connection
    const testClient = new PrismaClient({
      datasources: {
        db: {
          url: process.env.DATABASE_URL || 'file:/home/z/my-project/db/custom.db',
        },
      },
    });

    const userCount = await testClient.user.count();
    const elementCount = await testClient.element.count();
    const microareaCount = await testClient.microarea.count();

    await testClient.$disconnect();

    return jsonResponse({
      status: 'ok',
      databaseUrl: process.env.DATABASE_URL || 'file:/home/z/my-project/db/custom.db',
      userCount,
      elementCount,
      microareaCount,
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    return errorResponse(`Database test failed: ${message}`, 500);
  }
}
