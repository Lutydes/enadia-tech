/**
 * Extract balance questions from TS file and output as JSON.
 * Run: npx tsx scripts/extract-balance.ts
 */
import * as fs from 'fs';
import * as path from 'path';

const filePath = path.resolve(__dirname, '..', 'download', 'questions_balance.ts');
const content = fs.readFileSync(filePath, 'utf-8');

// Find the array between [ and ]
const startIdx = content.indexOf('[');
if (startIdx === -1) { console.error('No array found'); process.exit(1); }

// Find the matching closing bracket
let depth = 0;
let endIdx = startIdx;
for (let i = startIdx; i < content.length; i++) {
  if (content[i] === '[') depth++;
  if (content[i] === ']') { depth--; if (depth === 0) { endIdx = i + 1; break; } }
}
if (endIdx === -1) { console.error('No matching bracket'); process.exit(1); }

const arrayStr = content.substring(startIdx, endIdx);

// Convert to valid JSON: replace single quotes, handle identifiers as keys
const jsonStr = arrayStr
  // Fix key identifiers (add quotes around unquoted keys)
  .replace(/(\w+)(?=\s*:)/g, '"$1"')
  // Replace single quotes with double quotes (but not inside already-quoted strings)
  .replace(/'/g, '"')
  // Fix double semicolons from the above replacement
  .replace(/""/g, '"');

let questions;
try {
  questions = JSON.parse(jsonStr);
} catch (err) {
  console.error('JSON parse failed, trying eval approach...');
  // Fallback: use Function constructor
  try {
    questions = new Function('return ' + arrayStr + ';')();
  } catch (err2) {
    console.error('Eval also failed. Aborting.');
    console.error(err2);
    process.exit(1);
  }
}

console.log(`Extracted ${questions.length} questions`);
const outPath = path.resolve(__dirname, '..', 'download', 'balance_questions.json');
fs.writeFileSync(outPath, JSON.stringify(questions, null, 2));
console.log(`Written to ${outPath}`);
