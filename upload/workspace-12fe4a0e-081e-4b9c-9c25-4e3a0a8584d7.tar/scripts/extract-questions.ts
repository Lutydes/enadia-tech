/**
 * Extract all questions from TypeScript source files into a normalized JSON.
 * Run with: npx tsx scripts/extract-questions.ts
 */
import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';

// __dirname equivalent for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '..');

// Import all question banks
import { questionsBatch1 } from '../src/lib/questions_batch1';
import { questionsBatch2 } from '../src/lib/questions_batch2';
import { questionsBatch3 } from '../src/lib/questions_batch3';
import { expandedBank } from '../download/enade_expanded_bank';
import { expandedBankPart2 } from '../download/enade_expanded_bank_part2';

interface NormalizedQuestion {
  id: string;
  microareaName: string;
  macroarea: string;
  element: string;
  difficulty: string;
  statement: string;
  alternatives: { letter: string; text: string }[];
  correctAnswer: string;
  explanation: string;
  source: string;
  triA?: number;
  triB?: number;
  triC?: number;
}

function getTriParams(difficulty: string): { triA: number; triB: number; triC: number } {
  switch (difficulty) {
    case 'fácil': return { triA: 1.2, triB: -1.0, triC: 0.30 };
    case 'médio': return { triA: 1.7, triB: 0.0, triC: 0.20 };
    case 'difícil': return { triA: 2.2, triB: 0.8, triC: 0.12 };
    default: return { triA: 1.7, triB: 0.0, triC: 0.20 };
  }
}

const allQuestions: NormalizedQuestion[] = [];
const seenIds = new Set<string>();

function addQuestion(q: NormalizedQuestion) {
  if (seenIds.has(q.id)) {
    console.log(`  ⚠️  Duplicate ID skipped: ${q.id}`);
    return;
  }
  seenIds.add(q.id);
  allQuestions.push(q);
}

// --- Batch 1 (50 questions) ---
console.log('📦 Processing batch 1...');
for (const q of questionsBatch1) {
  const tri = getTriParams(q.difficulty);
  addQuestion({
    id: q.id,
    microareaName: q.topic,
    macroarea: q.macroarea,
    element: q.element,
    difficulty: q.difficulty,
    statement: q.statement,
    alternatives: q.alternatives,
    correctAnswer: q.correctAnswer,
    explanation: q.explanation,
    source: 'enade-oficial',
    triA: tri.triA,
    triB: tri.triB,
    triC: tri.triC,
  });
}

// --- Batch 2 (50 questions) ---
console.log('📦 Processing batch 2...');
for (const q of questionsBatch2) {
  const tri = getTriParams(q.difficulty);
  addQuestion({
    id: q.id,
    microareaName: q.topic,
    macroarea: q.macroarea,
    element: q.element,
    difficulty: q.difficulty,
    statement: q.statement,
    alternatives: q.alternatives,
    correctAnswer: q.correctAnswer,
    explanation: q.explanation,
    source: 'enade-oficial',
    triA: tri.triA,
    triB: tri.triB,
    triC: tri.triC,
  });
}

// --- Batch 3 (73 questions) ---
console.log('📦 Processing batch 3...');
for (const q of questionsBatch3) {
  const tri = getTriParams(q.difficulty);
  addQuestion({
    id: q.id,
    microareaName: q.topic,
    macroarea: q.macroarea,
    element: q.element,
    difficulty: q.difficulty,
    statement: q.statement,
    alternatives: q.alternatives,
    correctAnswer: q.correctAnswer,
    explanation: q.explanation,
    source: 'enade-oficial',
    triA: tri.triA,
    triB: tri.triB,
    triC: tri.triC,
  });
}

// --- Expanded Bank (35 questions) ---
console.log('📦 Processing expanded bank...');
for (const q of expandedBank) {
  addQuestion({
    id: q.id,
    microareaName: q.microarea,
    macroarea: q.macroarea,
    element: q.element,
    difficulty: q.difficulty,
    statement: q.statement,
    alternatives: q.alternatives,
    correctAnswer: q.correctAnswer,
    explanation: q.explanation,
    source: q.source || 'elaborada',
    triA: q.triA,
    triB: q.triB,
    triC: q.triC,
  });
}

// --- Expanded Bank Part 2 (59 questions) ---
console.log('📦 Processing expanded bank part 2...');
for (const q of expandedBankPart2) {
  addQuestion({
    id: q.id,
    microareaName: q.microarea,
    macroarea: q.macroarea,
    element: q.element,
    difficulty: q.difficulty,
    statement: q.statement,
    alternatives: q.alternatives,
    correctAnswer: q.correctAnswer,
    explanation: q.explanation,
    source: q.source || 'elaborada',
    triA: q.triA,
    triB: q.triB,
    triC: q.triC,
  });
}

// --- Summary ---
const microareaCounts: Record<string, number> = {};
const difficultyCounts: Record<string, number> = {};
for (const q of allQuestions) {
  microareaCounts[q.microareaName] = (microareaCounts[q.microareaName] || 0) + 1;
  difficultyCounts[q.difficulty] = (difficultyCounts[q.difficulty] || 0) + 1;
}

console.log('\n✅ Extraction complete!');
console.log(`   Total unique questions: ${allQuestions.length}`);
console.log('\n   By microarea:');
for (const [ma, count] of Object.entries(microareaCounts).sort((a, b) => b[1] - a[1])) {
  console.log(`     ${ma}: ${count}`);
}
console.log('\n   By difficulty:');
for (const [d, count] of Object.entries(difficultyCounts)) {
  console.log(`     ${d}: ${count}`);
}

// Write to file
const outputPath = path.join(projectRoot, 'download', 'all_questions.json');
fs.writeFileSync(outputPath, JSON.stringify(allQuestions, null, 2));
console.log(`\n💾 Written to: ${outputPath}`);
